import React, { useState, useEffect } from 'react';
import { Home, Compass, BookOpen, BarChart3, User, Shield, HelpCircle, ArrowLeft, Languages } from 'lucide-react';
import { KemetLogo } from './components/KemetLogo';
import { HomeView } from './components/views/HomeView';
import { JourneyView } from './components/views/JourneyView';
import { LibraryView } from './components/views/LibraryView';
import { ResultsView } from './components/views/ResultsView';
import { InstructorView } from './components/views/InstructorView';
import { NileMemory } from './components/activities/NileMemory';
import { RosettaMatch } from './components/activities/RosettaMatch';
import { LostInscription } from './components/activities/LostInscription';
import { PyramidBuilder } from './components/activities/PyramidBuilder';
import { EvidenceExplorer } from './components/activities/EvidenceExplorer';
import { StoryQuest } from './components/activities/StoryQuest';
import { EchoesOfTheNile } from './components/activities/EchoesOfTheNile';
import { SocraticCouncil } from './components/activities/SocraticCouncil';
import { AskThothModal } from './components/AskThothModal';
import { UNIT_1_VOCABULARY } from './data/vocabulary';
import { STORY_VOCABULARY_59 } from './data/storyLexicon';
import { ALL_330_QUESTIONS } from './data/questions';
import { getLocalUserProfile, saveLocalUserProfile, getTeacherApprovals, LocalUserProfile } from './services/storage';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'home' | 'journey' | 'library' | 'results' | 'instructor'>('home');
  const [activeActivity, setActiveActivity] = useState<string | null>(null);
  const [activityParams, setActivityParams] = useState<any>(null);
  const [libraryInitialCategory, setLibraryInitialCategory] = useState<'reading' | 'grammar' | 'listening' | 'writing' | 'vocab' | 'story'>('vocab');
  const [isThothOpen, setIsThothOpen] = useState(false);
  const [userProfile, setUserProfile] = useState<LocalUserProfile>(getLocalUserProfile());
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [isArabicUi, setIsArabicUi] = useState(false);

  // Check unapproved question count
  const approvals = getTeacherApprovals();
  const unapprovedCount = ALL_330_QUESTIONS.filter(q => !approvals[q.id]).length;

  const handleStartActivity = (mode: string, params?: any) => {
    setActiveActivity(mode);
    setActivityParams(params || null);
  };

  const handleExitActivity = () => {
    setActiveActivity(null);
    setActivityParams(null);
  };

  const handleOpenLibraryCategory = (cat: 'reading' | 'grammar' | 'listening' | 'writing' | 'vocab' | 'story') => {
    setLibraryInitialCategory(cat);
    setCurrentTab('library');
    setActiveActivity(null);
  };

  const handleOpenGateway = (gateway: 'vocab' | 'story' | 'challenge') => {
    if (gateway === 'vocab') {
      handleStartActivity('nile-memory', { groupIndex: 0 });
    } else if (gateway === 'story') {
      handleStartActivity('story-quest', { bankId: 'N1' });
    } else if (gateway === 'challenge') {
      setCurrentTab('journey');
      setActiveActivity(null);
    }
  };

  return (
    <div className={`min-h-screen bg-[#F8F5EE] text-[#172A2E] flex flex-col items-center selection:bg-[#B8892D]/20 ${isArabicUi ? 'lang-ar' : ''}`}>
      {/* Responsive Wrapper constrained to portrait mobile widths (360px-430px) on mobile and max-w-lg on desktop */}
      <div className="w-full max-w-md min-h-screen bg-[#FDFBF7] shadow-xl flex flex-col relative border-x border-[#EFE8D6]">
        
        {/* TOP BAR CONTRACT: One row, three zones */}
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 h-14 flex items-center justify-between gap-4">
          {/* Zone 1: Brand Wordmark / Back trigger */}
          <div className="flex items-center gap-2">
            {activeActivity ? (
              <button
                type="button"
                onClick={handleExitActivity}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-700 hover:text-black rounded-full"
                aria-label="Back to navigation"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => { setCurrentTab('home'); setActiveActivity(null); }}
                className="font-display font-extrabold text-base tracking-wider text-[#B8892D] flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <span className="text-xl">𓋹</span> KEMET
              </button>
            )}
          </div>

          {/* Zone 2: Language & Status indicator */}
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-600">
            <button
              type="button"
              onClick={() => setIsArabicUi(!isArabicUi)}
              className="flex items-center gap-1 px-2.5 py-1 bg-[#FFF9EC] border border-[#B8892D]/40 rounded-lg text-slate-800 hover:border-[#B8892D]"
              title="Interface translation toggle"
            >
              <Languages className="w-3.5 h-3.5 text-[#B8892D]" />
              <span>{isArabicUi ? 'AR' : 'EN'}</span>
            </button>
          </div>

          {/* Zone 3: Profile & Staff Trigger */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => { setCurrentTab('instructor'); setActiveActivity(null); }}
              className={`p-2 rounded-xl text-xs font-medium transition-colors ${
                currentTab === 'instructor' ? 'bg-[#172A2E] text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
              title="Instructor Console"
              aria-label="Instructor Console"
            >
              <Shield className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setShowProfileModal(true)}
              className="w-8 h-8 rounded-full bg-[#FFF9EC] border border-[#B8892D] flex items-center justify-center text-[#B8892D] hover:bg-[#B8892D] hover:text-white transition-colors"
              title="User Account & Sync State"
              aria-label="User Account"
            >
              <User className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* MAIN SCROLLABLE CONTENT BODY */}
        <main className="flex-1 px-4 py-4 pb-24 overflow-y-auto">
          {/* Active Learning Mode Container */}
          {activeActivity ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b pb-2">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Active Station: {activeActivity.replace('-', ' ').toUpperCase()}
                </span>
                <button
                  type="button"
                  onClick={handleExitActivity}
                  className="text-xs text-[#008C96] hover:underline font-medium"
                >
                  Exit Activity
                </button>
              </div>

              {activeActivity === 'nile-memory' && (
                <NileMemory
                  vocabularyList={UNIT_1_VOCABULARY}
                  userId={userProfile.uid}
                  onCompleteGroup={handleExitActivity}
                />
              )}

              {activeActivity === 'rosetta-match' && (
                <RosettaMatch
                  vocabularyList={UNIT_1_VOCABULARY}
                  userId={userProfile.uid}
                  onComplete={handleExitActivity}
                />
              )}

              {activeActivity === 'lost-inscription' && (
                <LostInscription
                  vocabularyList={UNIT_1_VOCABULARY}
                  userId={userProfile.uid}
                  onComplete={handleExitActivity}
                />
              )}

              {activeActivity === 'pyramid-builder' && (
                <PyramidBuilder
                  questions={
                    activityParams?.bankId
                      ? ALL_330_QUESTIONS.filter(q => q.bankId === activityParams.bankId)
                      : ALL_330_QUESTIONS.filter(q => ['R1', 'R2', 'P1', 'C1', 'C2', 'D1'].includes(q.bankId))
                  }
                  userId={userProfile.uid}
                  onComplete={handleExitActivity}
                />
              )}

              {activeActivity === 'evidence-explorer' && (
                <EvidenceExplorer
                  questions={ALL_330_QUESTIONS.filter(q => q.bankId === 'S1')}
                  userId={userProfile.uid}
                  onComplete={handleExitActivity}
                />
              )}

              {activeActivity === 'story-quest' && (
                <StoryQuest
                  questions={ALL_330_QUESTIONS.filter(q => q.bankId === 'N1')}
                  userId={userProfile.uid}
                  onComplete={handleExitActivity}
                />
              )}

              {activeActivity === 'echoes-nile' && (
                <EchoesOfTheNile
                  questions={ALL_330_QUESTIONS.filter(q => q.bankId === 'L1')}
                  userId={userProfile.uid}
                  onComplete={handleExitActivity}
                />
              )}

              {activeActivity === 'socratic-council' && (
                <SocraticCouncil
                  questions={ALL_330_QUESTIONS}
                  userId={userProfile.uid}
                  onComplete={handleExitActivity}
                />
              )}
            </div>
          ) : (
            /* Tab Content */
            <>
              {currentTab === 'home' && (
                <HomeView
                  onStartJourney={() => setCurrentTab('journey')}
                  onOpenGateway={handleOpenGateway}
                  onOpenLibraryCategory={handleOpenLibraryCategory}
                  unapprovedCount={unapprovedCount}
                />
              )}

              {currentTab === 'journey' && (
                <JourneyView onStartActivity={handleStartActivity} />
              )}

              {currentTab === 'library' && (
                <LibraryView initialCategory={libraryInitialCategory} />
              )}

              {currentTab === 'results' && (
                <ResultsView />
              )}

              {currentTab === 'instructor' && (
                <InstructorView />
              )}
            </>
          )}
        </main>

        {/* FLOATING "ASK THOTH" BUTTON (Positioned clear of navigation & task) */}
        {!activeActivity && (
          <div className="fixed bottom-20 right-6 z-40">
            <button
              type="button"
              onClick={() => setIsThothOpen(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#008C96] to-[#00A7B3] hover:from-[#007A82] hover:to-[#008C96] text-white rounded-full font-bold text-xs shadow-lg shadow-[#008C96]/30 transition-transform active:scale-95"
              aria-label="Open Ask Thoth Assistant"
            >
              <span className="text-base">𓅃</span>
              <span>Ask Thoth</span>
            </button>
          </div>
        )}

        {/* BOTTOM NAVIGATION (Fixed bottom tab bar, 4 primary destinations) */}
        <nav
          className="fixed bottom-0 left-0 right-0 max-w-md mx-auto z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-cols-4 items-center h-16 pb-safe px-2"
          aria-label="Main Navigation"
        >
          <button
            type="button"
            onClick={() => { setCurrentTab('home'); setActiveActivity(null); }}
            className={`flex flex-col items-center justify-center min-h-[44px] transition-colors ${
              currentTab === 'home' && !activeActivity ? 'text-[#B8892D] font-bold' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] tracking-tight mt-1">Home</span>
          </button>

          <button
            type="button"
            onClick={() => { setCurrentTab('journey'); setActiveActivity(null); }}
            className={`flex flex-col items-center justify-center min-h-[44px] transition-colors ${
              currentTab === 'journey' && !activeActivity ? 'text-[#B8892D] font-bold' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Compass className="w-5 h-5" />
            <span className="text-[10px] tracking-tight mt-1">Journey</span>
          </button>

          <button
            type="button"
            onClick={() => { setCurrentTab('library'); setActiveActivity(null); }}
            className={`flex flex-col items-center justify-center min-h-[44px] transition-colors ${
              currentTab === 'library' && !activeActivity ? 'text-[#B8892D] font-bold' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-5 h-5" />
            <span className="text-[10px] tracking-tight mt-1">Library</span>
          </button>

          <button
            type="button"
            onClick={() => { setCurrentTab('results'); setActiveActivity(null); }}
            className={`flex flex-col items-center justify-center min-h-[44px] transition-colors ${
              currentTab === 'results' && !activeActivity ? 'text-[#B8892D] font-bold' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <BarChart3 className="w-5 h-5" />
            <span className="text-[10px] tracking-tight mt-1">Results</span>
          </button>
        </nav>

        {/* ASK THOTH MODAL */}
        <AskThothModal
          isOpen={isThothOpen}
          onClose={() => setIsThothOpen(false)}
        />

        {/* PROFILE & LOCAL SYNC MODAL */}
        {showProfileModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
            <div className="bg-[#FFF9EC] border-2 border-[#B8892D] rounded-3xl max-w-sm w-full p-5 shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b pb-2">
                <h3 className="font-display font-bold text-base text-slate-900">User Profile</h3>
                <button
                  type="button"
                  onClick={() => setShowProfileModal(false)}
                  className="text-slate-500 hover:text-black text-xs font-semibold"
                >
                  Close
                </button>
              </div>

              <div className="space-y-2 text-xs">
                <div className="bg-white p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-400 font-mono uppercase block">Session Type</span>
                  <div className="font-bold text-slate-900">Anonymous Local Trial</div>
                  <div className="text-[11px] text-amber-800 font-semibold mt-0.5">
                    *Results stored on this device and not yet synced
                  </div>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-400 font-mono uppercase block">Learner UID</span>
                  <div className="font-mono text-slate-700 text-[11px] truncate">{userProfile.uid}</div>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-400 font-mono uppercase block">Configured Email Destination</span>
                  <div className="font-medium text-slate-800 text-[11px]">Kemetthenileflow@gmail.com</div>
                </div>

                <div className="p-2.5 bg-slate-100 rounded-xl text-[10.5px] text-slate-600 leading-snug">
                  To protect secondary-school student privacy and comply with age boundaries, all progress is computed client-side without third-party tracking or generative AI query injection.
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowProfileModal(false)}
                className="w-full py-2.5 bg-[#B8892D] text-white rounded-xl text-xs font-semibold hover:bg-[#A37622]"
              >
                Close Profile
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
