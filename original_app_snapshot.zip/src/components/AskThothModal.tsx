import React, { useState } from 'react';
import { X, HelpCircle, BookOpen, Lightbulb, CheckCircle2, Compass, AlertCircle, ExternalLink } from 'lucide-react';
import { QuestionItem, VocabularyItem } from '../types';
import { GRAMMAR_REFERENCES, READING_PASSAGES } from '../data/references';
import { UNIT_1_VOCABULARY } from '../data/vocabulary';
import { getStoredAttempts, getWordProgress } from '../services/storage';

interface AskThothModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentQuestion?: QuestionItem | null;
  currentVocabulary?: VocabularyItem | null;
  isAssessmentMode?: boolean;
}

export const AskThothModal: React.FC<AskThothModalProps> = ({
  isOpen,
  onClose,
  currentQuestion,
  currentVocabulary,
  isAssessmentMode = false
}) => {
  const [responseTitle, setResponseTitle] = useState<string>('');
  const [responseBody, setResponseBody] = useState<string>('');
  const [externalBotUrl, setExternalBotUrl] = useState<string>('');
  const [showConfig, setShowConfig] = useState<boolean>(false);
  const [customQuestionInput, setCustomQuestionInput] = useState<string>('');

  if (!isOpen) return null;

  const handleExplain = () => {
    setResponseTitle('Thoth\'s Guidance: Concept Explanation');
    if (isAssessmentMode) {
      setResponseBody('In active assessment mode, full answer explanations are reserved until after you submit. Focus on the sentence structure and key words!');
      return;
    }

    if (currentQuestion) {
      if (currentQuestion.relatedGrammarId) {
        const ref = GRAMMAR_REFERENCES.find(g => g.id === currentQuestion.relatedGrammarId);
        if (ref) {
          setResponseBody(`${ref.title}\n\nKey Rule:\n${ref.englishRules[0]}\n\nArabic note: ${ref.arabicRules[0] || ''}`);
          return;
        }
      }
      setResponseBody(`Context: ${currentQuestion.explanation || 'Analyze the grammar structure or vocabulary context carefully.'}`);
    } else if (currentVocabulary) {
      setResponseBody(`"${currentVocabulary.word}" (${currentVocabulary.partOfSpeech}) means: ${currentVocabulary.englishMeaning}.\n\nArabic: ${currentVocabulary.arabicMeaning}\nExample: "${currentVocabulary.example}"`);
    } else {
      setResponseBody('Review the reading passage or grammar reference corresponding to your current station in the Library.');
    }
  };

  const handleHint = () => {
    setResponseTitle('Thoth\'s Guidance: Method Hint');
    if (currentQuestion) {
      if (currentQuestion.bankId === 'R1' || currentQuestion.bankId === 'R2') {
        setResponseBody('Relative Clause check:\n1. Look at the noun directly before the gap.\n2. Is it a person or a thing?\n3. Is the relative word acting as a subject, an object, or showing possession?');
      } else if (currentQuestion.bankId === 'C1' || currentQuestion.bankId === 'C2') {
        setResponseBody('Conditional check:\n1. Find the if-clause verb tense.\n2. Check whether it describes a real future possibility (First), a hypothetical present (Second), or an alternative past (Third).');
      } else if (currentQuestion.bankId === 'P1') {
        setResponseBody('Participle check:\nDoes the subject actively perform the action (-ing) or passively receive it (-ed / past participle)?');
      } else {
        setResponseBody('Look for context clues in the sentence. Beware of absolute words like "always" or "all" when drawing conclusions!');
      }
    } else if (currentVocabulary) {
      setResponseBody(`First letter: "${currentVocabulary.word[0].toUpperCase()}" · Total length: ${currentVocabulary.word.length} letters.\nContext clue: ${currentVocabulary.example.replace(new RegExp(currentVocabulary.word, 'gi'), '_____')}`);
    } else {
      setResponseBody('Break the problem into small steps: identify the main subject and finite verb before deciding on the clause form.');
    }
  };

  const handleShowSource = () => {
    setResponseTitle('Approved Source Reference');
    if (currentQuestion?.relatedPassageId) {
      const p = READING_PASSAGES.find(pass => pass.id === currentQuestion.relatedPassageId);
      if (p) {
        setResponseBody(`Passage ${p.id}: ${p.title}\n\n"${p.paragraphs[0]}"\n\n(View complete text in the Library > Reading tab)`);
        return;
      }
    }
    if (currentQuestion?.relatedGrammarId) {
      const g = GRAMMAR_REFERENCES.find(gr => gr.id === currentQuestion.relatedGrammarId);
      if (g) {
        setResponseBody(`Grammar Reference: ${g.id} (${g.category})\n\n"${g.englishRules.join('\n\n')}"`);
        return;
      }
    }
    setResponseBody('Source material: Kemet Unit 1 Egyptian Curriculum Edition (Recovered authentic content awaiting teacher approval).');
  };

  const handleReviewMistakes = () => {
    setResponseTitle('Mistakes Review');
    const attempts = getStoredAttempts();
    const mistakes = attempts.filter(a => a.objectiveOutcome === 'incorrect');
    if (mistakes.length === 0) {
      setResponseBody('You have zero recorded incorrect objective attempts on this device! Keep up the brilliant focus.');
    } else {
      const recent = mistakes.slice(-4).map(m => `• Item ${m.questionId || m.vocabularyId}: Submitted "${m.submittedResponse}"`).join('\n');
      setResponseBody(`Found ${mistakes.length} items to review:\n\n${recent}\n\nHead to the Journey > Revision Queue to practice them.`);
    }
  };

  const handleWhatToPractise = () => {
    setResponseTitle('Deterministic Recommendation');
    const wordProgress = getWordProgress();
    const attempts = getStoredAttempts();

    const dueWords = UNIT_1_VOCABULARY.filter(v => {
      const prog = wordProgress[v.id];
      return !prog || prog.status === 'New' || prog.status === 'Review due';
    });

    if (dueWords.length > 0) {
      setResponseBody(`Recommendation: Practice Vocabulary Group ${dueWords[0].groupIndex + 1} (${dueWords[0].word}, etc.). You have ${dueWords.length} words awaiting retrieval.`);
    } else {
      const answeredQIds = new Set(attempts.map(a => a.questionId));
      const unattempted = 330 - answeredQIds.size;
      setResponseBody(`Great job! You have explored your vocabulary. Try Challenge Arena next to tackle unattempted questions (${unattempted} remaining).`);
    }
  };

  const handleCustomQuestionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customQuestionInput.trim()) return;
    setResponseTitle('Thoth\'s Direct Response');
    setResponseBody('I do not have an approved answer for this yet. Please consult your instructor or submit this question to the teacher review queue in the classroom.');
    setCustomQuestionInput('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-[#FFF9EC] border-2 border-[#B8892D] rounded-3xl max-w-md w-full p-5 shadow-2xl relative max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#B8892D]/20">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-full bg-[#B8892D]/20 border border-[#B8892D] flex items-center justify-center text-[#B8892D]">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base text-[#172A2E]">Ask Thoth</h3>
              <p className="text-[11px] text-slate-600">Deterministic Curriculum Assistant</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#EFE8D6] hover:bg-[#E5DDC7] flex items-center justify-center text-slate-700 transition-colors"
            aria-label="Close Ask Thoth"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto flex-1 py-4 space-y-4 text-xs">
          {/* Quick Action Buttons */}
          <div>
            <span className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider block mb-2">
              Approved Action Prompts
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleExplain}
                className="flex items-center gap-2 p-2.5 bg-white border border-[#B8892D]/30 hover:border-[#B8892D] rounded-xl text-left font-medium text-slate-800 transition-colors shadow-2xs"
              >
                <BookOpen className="w-4 h-4 text-[#B8892D] shrink-0" />
                <span>Explain this item</span>
              </button>
              <button
                type="button"
                onClick={handleHint}
                className="flex items-center gap-2 p-2.5 bg-white border border-[#B8892D]/30 hover:border-[#B8892D] rounded-xl text-left font-medium text-slate-800 transition-colors shadow-2xs"
              >
                <Lightbulb className="w-4 h-4 text-[#B8892D] shrink-0" />
                <span>Give me a hint</span>
              </button>
              <button
                type="button"
                onClick={handleShowSource}
                className="flex items-center gap-2 p-2.5 bg-white border border-[#B8892D]/30 hover:border-[#B8892D] rounded-xl text-left font-medium text-slate-800 transition-colors shadow-2xs"
              >
                <HelpCircle className="w-4 h-4 text-[#008C96] shrink-0" />
                <span>Show source</span>
              </button>
              <button
                type="button"
                onClick={handleReviewMistakes}
                className="flex items-center gap-2 p-2.5 bg-white border border-[#B8892D]/30 hover:border-[#B8892D] rounded-xl text-left font-medium text-slate-800 transition-colors shadow-2xs"
              >
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Review my mistakes</span>
              </button>
            </div>
            <button
              type="button"
              onClick={handleWhatToPractise}
              className="w-full mt-2 flex items-center justify-center gap-2 p-2 bg-[#008C96]/10 hover:bg-[#008C96]/20 border border-[#008C96]/40 rounded-xl font-medium text-[#008C96] transition-colors"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>What should I practise next?</span>
            </button>
          </div>

          {/* Response Display */}
          {responseTitle && (
            <div className="bg-white border border-[#B8892D]/40 rounded-2xl p-3.5 shadow-xs animate-in fade-in duration-200">
              <div className="flex items-center gap-1.5 font-bold text-slate-900 mb-1.5 pb-1 border-b border-slate-100">
                <span className="text-[#B8892D]">✦</span> {responseTitle}
              </div>
              <p className="text-slate-700 whitespace-pre-wrap leading-relaxed text-[12.5px]">
                {responseBody}
              </p>
            </div>
          )}

          {/* Free Text Input with Clear Fallback Notice */}
          <form onSubmit={handleCustomQuestionSubmit} className="pt-2 border-t border-[#B8892D]/20">
            <label htmlFor="thoth-query" className="block text-[11px] font-medium text-slate-600 mb-1.5">
              Ask about a specific term or rule:
            </label>
            <div className="flex gap-2">
              <input
                id="thoth-query"
                type="text"
                value={customQuestionInput}
                onChange={e => setCustomQuestionInput(e.target.value)}
                placeholder="e.g. difference between whose and who's"
                className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-[#B8892D]"
              />
              <button
                type="submit"
                className="px-3.5 py-2 bg-[#172A2E] hover:bg-black text-white text-xs font-semibold rounded-xl"
              >
                Ask
              </button>
            </div>
            <p className="text-[10px] text-slate-500 mt-1">
              Thoth provides approved curriculum guidance only. No generative LLM is queried.
            </p>
          </form>

          {/* External Bot Configuration Slot */}
          <div className="pt-2 text-[11px] text-slate-600">
            <button
              type="button"
              onClick={() => setShowConfig(!showConfig)}
              className="text-[#008C96] hover:underline flex items-center gap-1 font-medium"
            >
              <ExternalLink className="w-3 h-3" />
              {showConfig ? 'Hide External Bot Settings' : 'Optional External Bot Link Slot'}
            </button>
            {showConfig && (
              <div className="mt-2 p-2.5 bg-[#F4EEDC] rounded-xl border border-slate-300 space-y-2">
                <p className="text-[10.5px] text-slate-600 leading-snug">
                  To connect an external educator bot (e.g. n8n webhook or verified Telegram support), supply the URL below. It will open in a new tab without passing student identifiers.
                </p>
                <input
                  type="url"
                  placeholder="https://t.me/your_bot or https://your-server/webhook"
                  value={externalBotUrl}
                  onChange={e => setExternalBotUrl(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                />
                {externalBotUrl ? (
                  <a
                    href={externalBotUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-[#008C96] font-semibold hover:underline"
                  >
                    Open configured bot <ExternalLink className="w-3 h-3" />
                  </a>
                ) : (
                  <span className="text-[10px] text-slate-500 italic">No external URL configured</span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-[#B8892D]/20 text-center">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2 bg-[#E8E1CE] hover:bg-[#DDD5C0] text-slate-800 font-semibold rounded-xl text-xs transition-colors"
          >
            Return to Learning
          </button>
        </div>
      </div>
    </div>
  );
};
