import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Volume2, FileText, ChevronDown, ChevronUp } from 'lucide-react';
import { AudioItem } from '../types';

interface AudioPlayerProps {
  audio: AudioItem;
  onTranscriptRevealed?: () => void;
  className?: string;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({ audio, onTranscriptRevealed, className = '' }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1.0);
  const [progress, setProgress] = useState(0); // 0 to 100
  const [showTranscript, setShowTranscript] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const speechRef = useRef<SpeechSynthesisUtterance | null>(null);
  const timerRef = useRef<any>(null);

  useEffect(() => {
    // Reset when audio changes
    stopAudio();
    setProgress(0);
    setCurrentTime(0);
    return () => {
      stopAudio();
    };
  }, [audio.id]);

  const stopAudio = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setIsPlaying(false);
  };

  const togglePlay = () => {
    if (isPlaying) {
      stopAudio();
    } else {
      startAudio();
    }
  };

  const startAudio = () => {
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      console.warn("Speech synthesis is not supported on this browser.");
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(audio.transcript);
    utterance.rate = playbackRate;
    utterance.lang = 'en-US';

    // Estimate duration based on word count and rate
    const words = audio.transcript.split(/\s+/).length;
    const estimatedDurationSec = (words / (140 * playbackRate)) * 60;

    const startTime = Date.now() - (currentTime * 1000);

    timerRef.current = setInterval(() => {
      const elapsed = (Date.now() - startTime) / 1000;
      setCurrentTime(elapsed);
      const pct = Math.min(100, (elapsed / estimatedDurationSec) * 100);
      setProgress(pct);
      if (pct >= 100) {
        clearInterval(timerRef.current);
        setIsPlaying(false);
      }
    }, 250);

    utterance.onend = () => {
      if (timerRef.current) clearInterval(timerRef.current);
      setIsPlaying(false);
      setProgress(100);
    };

    utterance.onerror = () => {
      if (timerRef.current) clearInterval(timerRef.current);
      setIsPlaying(false);
    };

    speechRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    setIsPlaying(true);
  };

  const handleRateChange = (newRate: number) => {
    setPlaybackRate(newRate);
    if (isPlaying) {
      stopAudio();
      setTimeout(() => {
        // restart with new rate
        const utterance = new SpeechSynthesisUtterance(audio.transcript);
        utterance.rate = newRate;
        utterance.lang = 'en-US';
        speechRef.current = utterance;
        window.speechSynthesis.speak(utterance);
        setIsPlaying(true);
      }, 100);
    }
  };

  const handleReplay = () => {
    stopAudio();
    setCurrentTime(0);
    setProgress(0);
    setTimeout(() => {
      startAudio();
    }, 100);
  };

  const handleToggleTranscript = () => {
    const next = !showTranscript;
    setShowTranscript(next);
    if (next && onTranscriptRevealed) {
      onTranscriptRevealed();
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className={`bg-[#FFF9EC] border border-[#B8892D]/30 rounded-2xl p-4 shadow-sm ${className}`}>
      <div className="flex items-center justify-between gap-3 mb-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-[#008C96]/15 flex items-center justify-center text-[#008C96]">
            <Volume2 className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-[#172A2E] leading-snug">{audio.title}</h4>
            <p className="text-[11px] text-slate-500">{audio.disclaimer}</p>
          </div>
        </div>

        {/* Speed Controls */}
        <div className="flex items-center gap-1 bg-[#E8E1CE] p-1 rounded-lg">
          <button
            type="button"
            onClick={() => handleRateChange(0.8)}
            className={`px-2 py-0.5 text-xs font-medium rounded transition-colors ${
              playbackRate === 0.8 ? 'bg-[#008C96] text-white shadow-xs' : 'text-slate-700 hover:text-black'
            }`}
          >
            0.8x
          </button>
          <button
            type="button"
            onClick={() => handleRateChange(1.0)}
            className={`px-2 py-0.5 text-xs font-medium rounded transition-colors ${
              playbackRate === 1.0 ? 'bg-[#008C96] text-white shadow-xs' : 'text-slate-700 hover:text-black'
            }`}
          >
            1.0x
          </button>
        </div>
      </div>

      {/* Progress Track */}
      <div className="w-full bg-[#E8E1CE] h-2 rounded-full overflow-hidden my-3">
        <div
          className="bg-[#008C96] h-full transition-all duration-300 rounded-full"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Play / Replay Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={togglePlay}
            className="flex items-center justify-center min-w-[44px] min-h-[44px] px-4 py-2 bg-[#B8892D] hover:bg-[#A37622] text-white rounded-xl font-medium text-xs shadow-sm transition-transform active:scale-95"
            aria-label={isPlaying ? "Pause audio" : "Play audio"}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 mr-1.5" /> Pause
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-1.5 fill-current" /> Play Recording
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleReplay}
            className="flex items-center justify-center min-w-[44px] min-h-[44px] px-3 py-2 bg-[#EFE8D6] hover:bg-[#E5DDC7] text-slate-700 rounded-xl text-xs font-medium transition-colors"
            title="Replay from start"
            aria-label="Replay audio"
          >
            <RotateCcw className="w-3.5 h-3.5 mr-1" /> Replay
          </button>
        </div>

        <button
          type="button"
          onClick={handleToggleTranscript}
          className="flex items-center gap-1 min-h-[44px] px-3 text-xs font-medium text-[#008C96] hover:text-[#006E76]"
          aria-expanded={showTranscript}
        >
          <FileText className="w-3.5 h-3.5" />
          {showTranscript ? 'Hide Transcript' : 'Show Transcript (support)'}
          {showTranscript ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Collapsible Transcript */}
      {showTranscript && (
        <div className="mt-3 pt-3 border-t border-[#B8892D]/20 text-xs text-slate-700 leading-relaxed font-normal bg-white/70 p-3 rounded-xl">
          <div className="flex items-center justify-between text-[11px] text-[#B8892D] font-semibold uppercase tracking-wider mb-1">
            <span>Transcript (Unverified Alignment)</span>
            <span>Support Activated</span>
          </div>
          <p>{audio.transcript}</p>
        </div>
      )}
    </div>
  );
};
