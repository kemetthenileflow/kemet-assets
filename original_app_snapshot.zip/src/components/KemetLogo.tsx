import React from 'react';

interface KemetLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const KemetLogo: React.FC<KemetLogoProps> = ({ className = '', size = 'md' }) => {
  const heights = {
    sm: 'h-11',
    md: 'h-16',
    lg: 'h-24'
  };

  return (
    <div className={`flex items-center justify-center ${heights[size]} ${className}`}>
      <svg
        viewBox="0 0 520 260"
        className="h-full w-auto max-w-full drop-shadow-sm select-none"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="Kemet: The Nile Flow Logo"
      >
        <defs>
          {/* Gold Gradients */}
          <linearGradient id="goldWingL" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFF1B8" />
            <stop offset="35%" stopColor="#DFB253" />
            <stop offset="70%" stopColor="#B8892D" />
            <stop offset="100%" stopColor="#7E5813" />
          </linearGradient>
          <linearGradient id="goldWingR" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FFF1B8" />
            <stop offset="35%" stopColor="#DFB253" />
            <stop offset="70%" stopColor="#B8892D" />
            <stop offset="100%" stopColor="#7E5813" />
          </linearGradient>
          <linearGradient id="goldTextGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FFFCE8" />
            <stop offset="25%" stopColor="#F5D77F" />
            <stop offset="60%" stopColor="#D4A136" />
            <stop offset="100%" stopColor="#8A5E12" />
          </linearGradient>
          <linearGradient id="turquoiseStream" x1="0%" y1="0%" x2="100%" y2="50%">
            <stop offset="0%" stopColor="#005B60" />
            <stop offset="50%" stopColor="#00A8B5" />
            <stop offset="100%" stopColor="#48E5EF" />
          </linearGradient>
          <radialGradient id="dropGrad" cx="35%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#7BFFFF" />
            <stop offset="40%" stopColor="#00B4C5" />
            <stop offset="90%" stopColor="#00565E" />
            <stop offset="100%" stopColor="#002D32" />
          </radialGradient>
          <linearGradient id="cartoucheEdge" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#9C701B" />
            <stop offset="20%" stopColor="#F9DF88" />
            <stop offset="50%" stopColor="#CA9B32" />
            <stop offset="80%" stopColor="#F9DF88" />
            <stop offset="100%" stopColor="#7E5813" />
          </linearGradient>
          <filter id="goldShine" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#3B2605" floodOpacity="0.4" />
          </filter>
        </defs>

        {/* LEFT WING */}
        <g filter="url(#goldShine)">
          <path
            d="M 170 120 C 120 70, 50 40, 20 80 C 10 110, 45 155, 120 170 C 145 175, 165 160, 175 140 Z"
            fill="url(#goldWingL)"
            stroke="#63450B"
            strokeWidth="3"
          />
          {/* Feather details left */}
          <path d="M 25 85 C 45 105, 80 135, 130 150" stroke="#4F3507" strokeWidth="2.5" />
          <path d="M 40 100 C 65 125, 95 145, 145 158" stroke="#4F3507" strokeWidth="2" />
          <path d="M 60 125 C 80 140, 110 155, 155 165" stroke="#4F3507" strokeWidth="2" />
          {/* Dark wing tips */}
          <path d="M 18 80 C 15 95, 30 115, 45 110 C 35 95, 25 85, 18 80 Z" fill="#1C2123" />
          <path d="M 28 115 C 28 130, 48 142, 60 132 C 48 120, 36 112, 28 115 Z" fill="#1C2123" />
          <path d="M 48 140 C 55 155, 78 162, 88 150 C 72 140, 60 135, 48 140 Z" fill="#1C2123" />
        </g>

        {/* RIGHT WING */}
        <g filter="url(#goldShine)">
          <path
            d="M 350 120 C 400 70, 470 40, 500 80 C 510 110, 475 155, 400 170 C 375 175, 355 160, 345 140 Z"
            fill="url(#goldWingR)"
            stroke="#63450B"
            strokeWidth="3"
          />
          {/* Feather details right */}
          <path d="M 495 85 C 475 105, 440 135, 390 150" stroke="#4F3507" strokeWidth="2.5" />
          <path d="M 480 100 C 455 125, 425 145, 375 158" stroke="#4F3507" strokeWidth="2" />
          <path d="M 460 125 C 440 140, 410 155, 365 165" stroke="#4F3507" strokeWidth="2" />
          {/* Dark wing tips */}
          <path d="M 502 80 C 505 95, 490 115, 475 110 C 485 95, 495 85, 502 80 Z" fill="#1C2123" />
          <path d="M 492 115 C 492 130, 472 142, 460 132 C 472 120, 484 112, 492 115 Z" fill="#1C2123" />
          <path d="M 472 140 C 465 155, 442 162, 432 150 C 448 140, 460 135, 472 140 Z" fill="#1C2123" />
        </g>

        {/* TOP ARCH / HORUS SOLAR DISC SPREAD */}
        <path
          d="M 140 100 C 180 50, 340 50, 380 100 C 320 65, 200 65, 140 100 Z"
          fill="url(#goldTextGrad)"
          stroke="#68470C"
          strokeWidth="2"
        />

        {/* ROSETTA STELE (Left of Kemet) */}
        <g>
          <path
            d="M 112 75 C 122 70, 138 72, 145 80 L 148 142 C 145 152, 128 154, 115 146 L 110 85 Z"
            fill="#1E2325"
            stroke="#C99E39"
            strokeWidth="2"
          />
          {/* Hieroglyphic gold engravings */}
          <path d="M 120 86 Q 130 83 138 86" stroke="#E2BC57" strokeWidth="1.5" />
          {/* Horus Falcon / Owl symbol */}
          <path d="M 125 93 C 122 98, 126 106, 133 106 C 137 106, 138 100, 134 95 Z" stroke="#FDE57E" strokeWidth="1.5" fill="none" />
          <path d="M 128 95 L 126 97" stroke="#FDE57E" strokeWidth="1.5" />
          {/* Bread loaf / sun arc */}
          <path d="M 122 114 C 122 110, 136 110, 136 114 Z" stroke="#FDE57E" strokeWidth="1.5" fill="none" />
          {/* Sun / Cross disc */}
          <circle cx="129" cy="126" r="6" stroke="#FDE57E" strokeWidth="1.5" fill="none" />
          <path d="M 123 126 L 135 126 M 129 120 L 129 132" stroke="#FDE57E" strokeWidth="1.2" />
        </g>

        {/* MAIN TITLE: KEMET */}
        <g filter="url(#goldShine)">
          <text
            x="285"
            y="126"
            textAnchor="middle"
            fill="url(#goldTextGrad)"
            stroke="#533706"
            strokeWidth="3.5"
            paintOrder="stroke fill"
            fontSize="54"
            fontWeight="900"
            fontFamily="'Cinzel', Georgia, serif"
            letterSpacing="6"
          >
            KEMET
          </text>
          {/* Golden Lotus leaves curling from 'K' */}
          <path
            d="M 172 82 C 180 72, 205 76, 208 92 C 195 98, 180 92, 172 82 Z"
            fill="url(#goldTextGrad)"
            stroke="#63450B"
            strokeWidth="1.5"
          />
          <path
            d="M 188 90 C 205 85, 218 95, 216 110 C 202 112, 192 102, 188 90 Z"
            fill="url(#goldTextGrad)"
            stroke="#63450B"
            strokeWidth="1.5"
          />
        </g>

        {/* CARTOUCHE: AI Language Assistant */}
        <g filter="url(#goldShine)">
          <rect
            x="146"
            y="138"
            width="228"
            height="26"
            rx="13"
            fill="#0F1B1E"
            stroke="url(#cartoucheEdge)"
            strokeWidth="3"
          />
          {/* Cartouche tied knot bar at right */}
          <rect x="370" y="137" width="5" height="28" rx="2" fill="url(#goldTextGrad)" stroke="#533706" strokeWidth="1" />
          <text
            x="260"
            y="156"
            textAnchor="middle"
            fill="#FFF1B8"
            fontSize="12.5"
            fontWeight="700"
            fontFamily="'Cinzel', Georgia, serif"
            letterSpacing="2"
          >
            AI Language Assistant
          </text>
        </g>

        {/* THE NILE FLOW: Curving eye flourish & Turquoise drop */}
        <g>
          {/* Eye of Horus stem & underline */}
          <path
            d="M 215 174 L 215 198 L 226 198 L 226 182 C 260 186, 320 188, 380 200 C 370 216, 345 220, 335 210 C 330 202, 340 196, 348 200"
            stroke="#B8892D"
            strokeWidth="3.5"
            strokeLinecap="round"
            fill="none"
          />
          {/* Turquoise stream ribbon */}
          <path
            d="M 235 182 C 275 186, 325 190, 360 205 C 330 200, 280 194, 235 182 Z"
            fill="url(#turquoiseStream)"
          />
          {/* Hanging turquoise drop */}
          <path
            d="M 238 186 C 248 198, 256 214, 248 226 C 240 236, 226 236, 218 226 C 210 214, 228 198, 238 186 Z"
            fill="url(#dropGrad)"
            stroke="#D4A136"
            strokeWidth="2.5"
            filter="url(#goldShine)"
          />
          {/* Text: The Nile Flow */}
          <text
            x="320"
            y="218"
            fill="#172A2E"
            fontSize="19"
            fontWeight="800"
            fontFamily="'Cinzel', Georgia, serif"
            fontStyle="italic"
            stroke="#FFF9EC"
            strokeWidth="0.8"
            letterSpacing="0.5"
          >
            The Nile Flow
          </text>
        </g>
      </svg>
    </div>
  );
};
