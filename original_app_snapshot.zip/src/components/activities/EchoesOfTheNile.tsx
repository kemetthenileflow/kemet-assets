import React, { useState } from 'react';
import { Headphones, Check, ArrowRight, Volume2 } from 'lucide-react';
import { QuestionItem, AudioItem } from '../../types';
import { AUDIO_ITEMS } from '../../data/audio';
import { AudioPlayer } from '../AudioPlayer';
import { saveAttempt } from '../../services/storage';

interface EchoesOfTheNileProps {
  questions: QuestionItem[]; // L1 questions
  onComplete: () => void;
  userId: string;
}

export const EchoesOfTheNile: React.FC<EchoesOfTheNileProps> = ({
  questions,
  onComplete,
  userId
}) => {
  const [sessionIndex, setSessionIndex] = useState(0); // 5 sessions of 6 tasks
  const [taskInSession, setTaskInSession] = useState(0);
  const [transcriptUsed, setTranscriptUsed] = useState(false);
  const [writtenResponse, setWrittenResponse] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [startTime] = useState(Date.now());

  const sessionQuestions = questions.slice(sessionIndex * 6, (sessionIndex + 1) * 6);
  const currentQ = sessionQuestions[taskInSession];

  const audioId = currentQ?.relatedAudioId || 'REC-01';
  const audioItem: AudioItem = AUDIO_ITEMS.find(a => a.id === audioId) || AUDIO_ITEMS[0];

  if (!currentQ) {
    return <div className="p-6 text-center text-slate-500">Listening session finished.</div>;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!writtenResponse.trim()) return;

    setSubmitted(true);

    saveAttempt({
      id: `att-listen-${currentQ.id}-${Date.now()}`,
      uid: userId,
      studentName: 'Learner',
      sessionId: `session-listening-${sessionIndex + 1}`,
      contentVersion: '1.0.0',
      questionId: currentQ.id,
      gameMode: 'Echoes of the Nile',
      difficultyRoute: currentQ.level,
      firstResponse: writtenResponse,
      submittedResponse: writtenResponse,
      submittedAt: new Date().toISOString(),
      objectiveOutcome: 'pending',
      isFirstAttempt: true,
      hintCount: 0,
      revealUsed: false,
      transcriptUsed: transcriptUsed,
      retryCount: 0,
      activeDurationMs: Date.now() - startTime,
      teacherReviewStatus: 'pending'
    });
  };

  const handleNext = () => {
    setWrittenResponse('');
    setSubmitted(false);

    if (taskInSession < sessionQuestions.length - 1) {
      setTaskInSession(taskInSession + 1);
    } else {
      if ((sessionIndex + 1) * 6 < questions.length) {
        setSessionIndex(sessionIndex + 1);
        setTaskInSession(0);
      } else {
        onComplete();
      }
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Top Banner */}
      <div className="flex items-center justify-between text-xs text-slate-600 bg-white/80 p-3 rounded-2xl border border-slate-200">
        <div className="flex items-center gap-1.5 font-semibold text-[#008C96]">
          <Headphones className="w-4 h-4" />
          <span>Echoes of the Nile · Session {sessionIndex + 1}</span>
        </div>
        <div className="text-[11px] text-slate-500">
          Task {taskInSession + 1} of 6 ({currentQ.level})
        </div>
      </div>

      {/* Embedded Audio Player */}
      <AudioPlayer
        audio={audioItem}
        onTranscriptRevealed={() => setTranscriptUsed(true)}
      />

      {/* Task Card */}
      <div className="bg-[#FFF9EC] border-2 border-[#008C96]/40 rounded-3xl p-5 shadow-sm space-y-4">
        <div>
          <span className="text-[11px] font-mono text-[#008C96] uppercase tracking-wide">
            {currentQ.id} · {currentQ.level}
          </span>
          <h3 className="text-base font-bold text-slate-900 mt-1 leading-snug">
            {currentQ.prompt}
          </h3>
        </div>

        {transcriptUsed && (
          <div className="p-2 bg-[#E8F4F5] border border-[#008C96]/30 text-[#006E76] rounded-xl text-[11px]">
            Notice: Transcript view enabled as learning support.
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label htmlFor="listening-input" className="block text-xs font-semibold text-slate-700 mb-1">
              Your Extracted Detail / Answer:
            </label>
            <textarea
              id="listening-input"
              rows={2}
              disabled={submitted}
              value={writtenResponse}
              onChange={e => setWrittenResponse(e.target.value)}
              placeholder="Type what you identified from the audio..."
              className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:border-[#008C96]"
            />
          </div>

          {!submitted ? (
            <button
              type="submit"
              disabled={!writtenResponse.trim()}
              className="w-full min-h-[44px] py-2.5 bg-[#008C96] hover:bg-[#00747C] disabled:opacity-50 text-white rounded-xl font-semibold text-xs shadow-xs transition-colors"
            >
              Submit for Comparison
            </button>
          ) : (
            <div className="space-y-3 pt-2 border-t border-slate-200">
              <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1.5 text-xs">
                <div className="flex items-center justify-between font-bold text-slate-900">
                  <span>Approved Source Model</span>
                  <span className="text-[11px] font-mono text-[#008C96]">Teacher Review</span>
                </div>
                <p className="text-slate-900 font-medium">
                  {currentQ.sourceAnswer}
                </p>
                <p className="text-slate-600 text-[11.5px] leading-relaxed">
                  Context: {currentQ.explanation}
                </p>
              </div>

              <button
                type="button"
                onClick={handleNext}
                className="w-full min-h-[44px] py-2.5 bg-[#172A2E] hover:bg-black text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-2"
              >
                <span>
                  {taskInSession < sessionQuestions.length - 1
                    ? 'Next Listening Task'
                    : 'Complete Session'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
