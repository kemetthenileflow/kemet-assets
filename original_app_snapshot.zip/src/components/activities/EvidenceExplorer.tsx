import React, { useState } from 'react';
import { BookOpen, Check, ArrowRight, Quote, Info } from 'lucide-react';
import { QuestionItem, ReadingPassage } from '../../types';
import { READING_PASSAGES } from '../../data/references';
import { saveAttempt } from '../../services/storage';

interface EvidenceExplorerProps {
  questions: QuestionItem[]; // S1 questions
  onComplete: () => void;
  userId: string;
}

export const EvidenceExplorer: React.FC<EvidenceExplorerProps> = ({
  questions,
  onComplete,
  userId
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [activeTab, setActiveTab] = useState<'question' | 'passage'>('question');
  const [selectedParagraphIdx, setSelectedParagraphIdx] = useState<number | null>(null);
  const [selectedQuote, setSelectedQuote] = useState<string>('');
  const [writtenReasoning, setWrittenReasoning] = useState<string>('');
  const [tfSelection, setTfSelection] = useState<'True' | 'False' | 'Not Given' | ''>('');
  const [submitted, setSubmitted] = useState(false);
  const [startTime] = useState(Date.now());

  const currentQ = questions[currentIndex];
  const relatedPassageId = currentQ?.relatedPassageId || 'A1';
  const passage: ReadingPassage = READING_PASSAGES.find(p => p.id === relatedPassageId) || READING_PASSAGES[0];

  const isTfng = currentQ?.prompt.includes('True, False or Not Given');

  const handleSelectParagraph = (pIdx: number, text: string) => {
    setSelectedParagraphIdx(pIdx);
    setSelectedQuote(text.slice(0, 160) + '...');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (submitted) return;

    const fullResponse = isTfng
      ? `Choice: ${tfSelection} | Evidence: "${selectedQuote}" | Reasoning: ${writtenReasoning}`
      : `Evidence: "${selectedQuote}" | Response: ${writtenReasoning}`;

    setSubmitted(true);

    saveAttempt({
      id: `att-evi-${currentQ.id}-${Date.now()}`,
      uid: userId,
      studentName: 'Learner',
      sessionId: `session-evidence-explorer`,
      contentVersion: '1.0.0',
      questionId: currentQ.id,
      gameMode: 'Evidence Explorer',
      difficultyRoute: currentQ.level,
      firstResponse: fullResponse,
      submittedResponse: fullResponse,
      submittedAt: new Date().toISOString(),
      objectiveOutcome: 'pending', // Teacher reviewed
      isFirstAttempt: true,
      hintCount: 0,
      revealUsed: false,
      transcriptUsed: false,
      retryCount: 0,
      activeDurationMs: Date.now() - startTime,
      selectedEvidence: selectedQuote,
      teacherReviewStatus: 'pending'
    });
  };

  const handleNext = () => {
    setSelectedParagraphIdx(null);
    setSelectedQuote('');
    setWrittenReasoning('');
    setTfSelection('');
    setSubmitted(false);

    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Passage / Question Switcher for Mobile */}
      <div className="flex bg-[#E8E1CE] p-1 rounded-xl text-xs font-semibold">
        <button
          type="button"
          onClick={() => setActiveTab('question')}
          className={`flex-1 py-1.5 rounded-lg transition-colors ${
            activeTab === 'question' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Task {currentIndex + 1} of {questions.length} ({currentQ.level})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('passage')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-colors ${
            activeTab === 'passage' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 text-[#008C96]" />
          <span>Passage {passage.id}: {passage.title.slice(0, 16)}...</span>
        </button>
      </div>

      {/* READING PASSAGE VIEW */}
      {activeTab === 'passage' && (
        <div className="bg-[#FFF9EC] border-2 border-[#008C96]/40 rounded-3xl p-5 shadow-sm space-y-3 animate-in fade-in">
          <div className="border-b border-[#008C96]/20 pb-2">
            <span className="text-[11px] font-mono text-[#008C96] uppercase tracking-wide">
              Reading Reference {passage.id}
            </span>
            <h3 className="text-base font-bold text-[#172A2E]">{passage.title}</h3>
            {passage.disclaimer && (
              <p className="text-[11px] text-slate-500 italic mt-0.5">{passage.disclaimer}</p>
            )}
          </div>

          <div className="space-y-2 text-xs leading-relaxed text-slate-800 max-h-[360px] overflow-y-auto pr-1">
            {passage.paragraphs.map((p, idx) => {
              const isSelected = selectedParagraphIdx === idx;
              return (
                <div
                  key={idx}
                  onClick={() => handleSelectParagraph(idx, p)}
                  className={`p-3 rounded-xl cursor-pointer border transition-all ${
                    isSelected
                      ? 'bg-[#E8F4F5] border-[#008C96] text-[#004D53] font-medium shadow-xs'
                      : 'bg-white/80 border-slate-200 hover:bg-white hover:border-[#008C96]/40'
                  }`}
                >
                  <span className="text-[10px] font-mono text-slate-400 block mb-0.5">¶ Paragraph {idx + 1} (Tap to cite)</span>
                  <p>{p}</p>
                </div>
              );
            })}
          </div>

          <button
            type="button"
            onClick={() => setActiveTab('question')}
            className="w-full min-h-[44px] py-2 bg-[#008C96] text-white rounded-xl text-xs font-semibold hover:bg-[#00757D]"
          >
            Return to Question {selectedQuote ? 'with Selected Evidence' : ''}
          </button>
        </div>
      )}

      {/* QUESTION & EVIDENCE VIEW */}
      {activeTab === 'question' && (
        <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-3xl p-5 shadow-sm space-y-4 animate-in fade-in">
          <div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono mb-1">
              <span>{currentQ.id} · {currentQ.level}</span>
              <span>Passage {passage.id}</span>
            </div>
            <h3 className="text-base font-bold text-slate-900 leading-snug">
              {currentQ.prompt}
            </h3>
          </div>

          {/* Selected Evidence Preview */}
          <div className="p-3 bg-white rounded-2xl border border-slate-200 space-y-1">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-600">
              <span className="flex items-center gap-1">
                <Quote className="w-3.5 h-3.5 text-[#008C96]" /> Attached Source Quote:
              </span>
              <button
                type="button"
                onClick={() => setActiveTab('passage')}
                className="text-[#008C96] hover:underline"
              >
                {selectedQuote ? 'Change quote' : 'Select from text'}
              </button>
            </div>
            <p className="text-xs text-slate-700 italic">
              {selectedQuote ? `"${selectedQuote}"` : 'No text span selected yet. Tap "Passage" above to cite specific evidence.'}
            </p>
          </div>

          {/* True / False / Not Given Selector */}
          {isTfng && (
            <div className="space-y-1.5">
              <span className="text-xs font-semibold text-slate-700 block">
                Select guided claim label:
              </span>
              <div className="grid grid-cols-3 gap-2">
                {(['True', 'False', 'Not Given'] as const).map(opt => (
                  <button
                    key={opt}
                    type="button"
                    disabled={submitted}
                    onClick={() => setTfSelection(opt)}
                    className={`py-2 px-3 text-xs font-semibold rounded-xl border transition-all ${
                      tfSelection === opt
                        ? 'bg-[#B8892D] border-[#B8892D] text-white'
                        : 'bg-white border-slate-200 text-slate-700 hover:border-[#B8892D]'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Written reasoning */}
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label htmlFor="reasoning-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Explain your reasoning using the text:
              </label>
              <textarea
                id="reasoning-input"
                rows={3}
                disabled={submitted}
                value={writtenReasoning}
                onChange={e => setWrittenReasoning(e.target.value)}
                placeholder="Explain which details support your conclusion and why..."
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:border-[#B8892D]"
              />
            </div>

            {!submitted ? (
              <button
                type="submit"
                disabled={!writtenReasoning.trim() || (isTfng && !tfSelection)}
                className="w-full min-h-[44px] py-2.5 bg-[#B8892D] hover:bg-[#A37622] disabled:opacity-50 text-white rounded-xl font-semibold text-xs shadow-xs transition-colors"
              >
                Submit Evidence & Explanation
              </button>
            ) : (
              <div className="space-y-3 pt-2 border-t border-slate-200">
                <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between font-bold text-slate-900">
                    <span>Source Model for Comparison</span>
                    <span className="text-[11px] font-mono text-[#008C96]">Pending Teacher Review</span>
                  </div>
                  <p className="text-slate-900 font-medium">
                    Approved Answer: {currentQ.sourceAnswer}
                  </p>
                  <p className="text-slate-600 text-[11.5px] leading-relaxed">
                    Note: {currentQ.explanation}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleNext}
                  className="w-full min-h-[44px] py-2.5 bg-[#172A2E] hover:bg-black text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-2"
                >
                  <span>{currentIndex < questions.length - 1 ? 'Next Evidence Task' : 'Complete Reading Tasks'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </form>
        </div>
      )}
    </div>
  );
};
