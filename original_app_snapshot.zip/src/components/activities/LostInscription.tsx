import React, { useState } from 'react';
import { Lightbulb, Check, AlertCircle, ArrowRight } from 'lucide-react';
import { VocabularyItem } from '../../types';
import { saveAttempt, updateWordProgress } from '../../services/storage';

interface LostInscriptionProps {
  vocabularyList: VocabularyItem[];
  onComplete: () => void;
  userId: string;
}

export const LostInscription: React.FC<LostInscriptionProps> = ({
  vocabularyList,
  onComplete,
  userId
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [typedInput, setTypedInput] = useState('');
  const [hintLevel, setHintLevel] = useState<number>(0); // 0 = no hint, 1 = first letter & length
  const [submitted, setSubmitted] = useState(false);
  const [differenceCharIndex, setDifferenceCharIndex] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [startTime] = useState(Date.now());

  const currentItem = vocabularyList[currentIndex];

  if (!currentItem) {
    return <div className="p-6 text-center text-slate-500">No inscription items remaining.</div>;
  }

  // Generate blanked context sentence
  const regex = new RegExp(`\\b${currentItem.word}\\b`, 'gi');
  const blankedContext = currentItem.example.replace(regex, '________');

  const normalizeWord = (str: string) => {
    return str
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .trim()
      .replace(/\s+/g, ' ');
  };

  const handleHintRequest = () => {
    setHintLevel(1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedInput.trim()) return;

    const userNorm = normalizeWord(typedInput);
    const targetNorm = normalizeWord(currentItem.word);

    let diffIdx: number | null = null;
    const minLen = Math.min(userNorm.length, targetNorm.length);
    for (let i = 0; i < minLen; i++) {
      if (userNorm[i] !== targetNorm[i]) {
        diffIdx = i;
        break;
      }
    }
    if (diffIdx === null && userNorm.length !== targetNorm.length) {
      diffIdx = minLen;
    }

    const correct = userNorm === targetNorm;
    setIsCorrect(correct);
    setDifferenceCharIndex(diffIdx);
    setSubmitted(true);

    const isUnassisted = hintLevel === 0;

    // Save attempt
    saveAttempt({
      id: `att-inscr-${currentItem.id}-${Date.now()}`,
      uid: userId,
      studentName: 'Learner',
      sessionId: `session-inscription`,
      contentVersion: '1.0.0',
      vocabularyId: currentItem.id,
      gameMode: 'Lost Inscription',
      difficultyRoute: 'Apply',
      firstResponse: typedInput,
      submittedResponse: typedInput,
      submittedAt: new Date().toISOString(),
      objectiveOutcome: correct ? 'correct' : 'incorrect',
      isFirstAttempt: true,
      hintCount: hintLevel,
      revealUsed: false,
      transcriptUsed: false,
      retryCount: 0,
      activeDurationMs: Date.now() - startTime,
      teacherReviewStatus: 'none'
    });

    if (correct && isUnassisted) {
      updateWordProgress(currentItem.id, prev => ({
        ...prev,
        successfulTypingCount: prev.successfulTypingCount + 1,
        status: prev.successfulTypingCount >= 1 ? 'Recall confirmed' : 'Practising',
        lastPractisedAt: new Date().toISOString()
      }));
    } else {
      updateWordProgress(currentItem.id, prev => ({
        ...prev,
        typingAttempts: prev.typingAttempts + 1,
        status: 'Practising'
      }));
    }
  };

  const handleNext = () => {
    setTypedInput('');
    setHintLevel(0);
    setSubmitted(false);
    setDifferenceCharIndex(null);
    setIsCorrect(null);

    if (currentIndex < vocabularyList.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Header Info */}
      <div className="flex items-center justify-between text-xs text-slate-600 bg-white/80 p-3 rounded-2xl border border-slate-200">
        <div>
          <span className="font-semibold text-[#B8892D]">Inscription {currentIndex + 1}</span> of {vocabularyList.length}
        </div>
        <div className="text-[11px] text-slate-500 font-mono">
          {currentItem.id} · {currentItem.partOfSpeech}
        </div>
      </div>

      {/* Inscription Tablet Card */}
      <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-3xl p-5 shadow-sm space-y-4">
        {/* Definition & Blanked Context */}
        <div className="space-y-3">
          <div className="bg-white/80 p-3.5 rounded-2xl border border-slate-200">
            <span className="text-[11px] font-semibold text-[#B8892D] uppercase tracking-wider block mb-1">
              Approved Definition
            </span>
            <p className="text-sm font-medium text-slate-800 leading-snug">
              {currentItem.englishMeaning}
            </p>
          </div>

          <div className="bg-white/90 p-3.5 rounded-2xl border border-slate-200">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
              Context Sentence
            </span>
            <p className="text-xs text-slate-800 leading-relaxed italic">
              "{blankedContext}"
            </p>
          </div>
        </div>

        {/* Optional Hint Box */}
        {hintLevel > 0 && (
          <div className="p-3 bg-[#E8F4F5] border border-[#008C96]/30 rounded-xl text-xs text-[#006E76] flex items-center justify-between animate-in fade-in">
            <span>
              Clue: Starts with <strong>'{currentItem.word[0].toUpperCase()}'</strong> · {currentItem.word.length} letters long
            </span>
            <span className="text-[10px] uppercase font-semibold text-slate-500">(Assisted)</span>
          </div>
        )}

        {/* Input Form */}
        {!submitted ? (
          <form onSubmit={handleSubmit} className="space-y-3 pt-1">
            <div>
              <label htmlFor="inscription-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Type the recovered spelling:
              </label>
              <input
                id="inscription-input"
                type="text"
                autoComplete="off"
                spellCheck={false}
                value={typedInput}
                onChange={e => setTypedInput(e.target.value)}
                placeholder="Type target word..."
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:border-[#B8892D]"
              />
            </div>

            <div className="flex gap-2">
              <button
                type="submit"
                disabled={!typedInput.trim()}
                className="flex-1 min-h-[44px] py-2.5 bg-[#B8892D] hover:bg-[#A37622] disabled:opacity-50 text-white rounded-xl font-semibold text-xs shadow-xs transition-colors"
              >
                Inscribe Word
              </button>
              {hintLevel === 0 && (
                <button
                  type="button"
                  onClick={handleHintRequest}
                  className="px-3.5 min-h-[44px] bg-[#EFE8D6] hover:bg-[#E5DDC7] text-slate-700 rounded-xl text-xs font-medium flex items-center gap-1.5"
                >
                  <Lightbulb className="w-3.5 h-3.5 text-amber-600" />
                  <span>Letter Clue</span>
                </button>
              )}
            </div>
          </form>
        ) : (
          /* Submission Feedback with Precise Non-Shaming Spelling Comparison */
          <div className="space-y-3 pt-1">
            {isCorrect ? (
              <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-2xl text-xs text-emerald-900 font-semibold flex items-center gap-2">
                <Check className="w-5 h-5 text-emerald-600 shrink-0" />
                <div>
                  <div>Correct spelling inscribed: "{currentItem.word}"</div>
                  <div className="text-[11px] font-normal text-emerald-700 mt-0.5">
                    {hintLevel === 0 ? 'Independent retrieval confirmed.' : 'Assisted retrieval recorded.'}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-amber-50 border border-amber-300 rounded-2xl text-xs text-amber-900 space-y-1.5">
                <div className="font-semibold flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Spelling difference noticed:</span>
                </div>
                <div className="bg-white/80 p-2 rounded-lg font-mono text-xs">
                  <div>Your input:&nbsp;
                    {typedInput.split('').map((char, i) => (
                      <span key={i} className={i === differenceCharIndex ? 'bg-amber-300 font-bold underline px-0.5 rounded' : ''}>
                        {char}
                      </span>
                    ))}
                  </div>
                  <div className="mt-1 text-slate-600">
                    Approved:&nbsp;&nbsp;&nbsp;{currentItem.word}
                  </div>
                </div>
                <div className="text-[11px] text-amber-800">
                  First difference at letter position {(differenceCharIndex || 0) + 1}. Item will return to your review queue.
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={handleNext}
              className="w-full min-h-[44px] py-2.5 bg-[#172A2E] hover:bg-black text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-2 transition-colors"
            >
              <span>{currentIndex < vocabularyList.length - 1 ? 'Next Inscription' : 'Complete Inscriptions'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
