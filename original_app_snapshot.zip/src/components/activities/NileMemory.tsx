import React, { useState } from 'react';
import { Eye, EyeOff, Check, RotateCcw, Volume2, ArrowRight } from 'lucide-react';
import { VocabularyItem, StoryVocabularyItem } from '../../types';
import { updateWordProgress, saveAttempt } from '../../services/storage';

interface NileMemoryProps {
  vocabularyList: VocabularyItem[];
  storyLexicon?: StoryVocabularyItem[];
  onCompleteGroup: () => void;
  userId: string;
}

export const NileMemory: React.FC<NileMemoryProps> = ({
  vocabularyList,
  onCompleteGroup,
  userId
}) => {
  const [groupIndex, setGroupIndex] = useState(0);
  const [wordIndex, setWordIndex] = useState(0);
  const [showEnglishMeaning, setShowEnglishMeaning] = useState(false);
  const [showArabicMeaning, setShowArabicMeaning] = useState(false);
  const [userRecallGuess, setUserRecallGuess] = useState('');
  const [phase, setPhase] = useState<'observe' | 'recall' | 'completed'>('observe');
  const [startTime] = useState<number>(Date.now());
  const [revealUsed, setRevealUsed] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Group words into chunks of 6
  const groupsCount = Math.ceil(vocabularyList.length / 6);
  const currentGroupWords = vocabularyList.slice(groupIndex * 6, (groupIndex + 1) * 6);
  const currentWord = currentGroupWords[wordIndex];

  const handleNextWord = () => {
    // Reset state for next word
    setShowEnglishMeaning(false);
    setShowArabicMeaning(false);
    setUserRecallGuess('');
    setFeedback(null);
    setRevealUsed(false);

    if (wordIndex < currentGroupWords.length - 1) {
      setWordIndex(wordIndex + 1);
      setPhase('observe');
    } else {
      if (phase === 'observe') {
        // Move to retrieval phase for this group
        setPhase('recall');
        setWordIndex(0);
      } else {
        setPhase('completed');
        onCompleteGroup();
      }
    }
  };

  const handleRevealEnglish = () => {
    setShowEnglishMeaning(true);
    setRevealUsed(true);
    if (currentWord) {
      updateWordProgress(currentWord.id, prev => ({
        ...prev,
        revealsCount: prev.revealsCount + 1,
        status: prev.status === 'New' ? 'Practising' : prev.status
      }));
    }
  };

  const handleRevealArabic = () => {
    setShowArabicMeaning(true);
    if (currentWord) {
      updateWordProgress(currentWord.id, prev => ({
        ...prev,
        arabicRevealsCount: prev.arabicRevealsCount + 1
      }));
    }
  };

  const speakWord = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'en-US';
      window.speechSynthesis.speak(u);
    }
  };

  const handleCheckRecall = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentWord) return;

    const normalizedGuess = userRecallGuess.trim().toLowerCase();
    const normalizedTarget = currentWord.word.trim().toLowerCase();
    const isCorrect = normalizedGuess === normalizedTarget;

    const duration = Date.now() - startTime;

    // Save attempt
    saveAttempt({
      id: `att-mem-${currentWord.id}-${Date.now()}`,
      uid: userId,
      studentName: 'Learner',
      sessionId: `session-group-${groupIndex}`,
      contentVersion: '1.0.0',
      vocabularyId: currentWord.id,
      gameMode: 'Nile Memory',
      difficultyRoute: 'Foundation',
      firstResponse: userRecallGuess,
      submittedResponse: userRecallGuess,
      submittedAt: new Date().toISOString(),
      objectiveOutcome: isCorrect ? 'correct' : 'incorrect',
      isFirstAttempt: true,
      hintCount: revealUsed ? 1 : 0,
      revealUsed: revealUsed,
      transcriptUsed: false,
      retryCount: 0,
      activeDurationMs: duration,
      teacherReviewStatus: 'none'
    });

    if (isCorrect) {
      setFeedback('Correct! Unassisted retrieval registered.');
      updateWordProgress(currentWord.id, prev => ({
        ...prev,
        successfulTypingCount: prev.successfulTypingCount + 1,
        status: prev.successfulTypingCount >= 1 ? 'Recall confirmed' : 'Practising',
        lastPractisedAt: new Date().toISOString()
      }));
    } else {
      setFeedback(`Target was: "${currentWord.word}". Practice will cycle back.`);
    }
  };

  if (!currentWord && phase !== 'completed') {
    return <div className="p-6 text-center text-slate-500">No vocabulary items loaded.</div>;
  }

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Group and Word Indicators */}
      <div className="flex items-center justify-between text-xs text-slate-600 bg-white/80 p-3 rounded-2xl border border-slate-200">
        <div>
          <span className="font-semibold text-[#B8892D]">Group {groupIndex + 1}</span> of {groupsCount}
          <span className="mx-2">·</span>
          <span>Word {wordIndex + 1} of {currentGroupWords.length}</span>
        </div>
        <div className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-[#FFF9EC] text-[#B8892D] border border-[#B8892D]/30">
          {phase === 'observe' ? 'Step 1: Predict & Reveal' : 'Step 2: Active Recall'}
        </div>
      </div>

      {phase === 'observe' && currentWord && (
        <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[11px] font-mono text-[#B8892D] tracking-wide uppercase">
                {currentWord.id} · {currentWord.partOfSpeech}
              </span>
              <h2 className="text-2xl font-bold text-[#172A2E] mt-0.5 flex items-center gap-2">
                {currentWord.word}
                <button
                  type="button"
                  onClick={() => speakWord(currentWord.word)}
                  className="p-1.5 rounded-full hover:bg-[#B8892D]/20 text-[#B8892D] transition-colors"
                  title="Pronounce word"
                  aria-label="Pronounce word"
                >
                  <Volume2 className="w-5 h-5" />
                </button>
              </h2>
              <span className="text-xs text-slate-500 font-mono">{currentWord.ipa}</span>
            </div>
          </div>

          {/* Context Sentence */}
          <div className="bg-white/80 p-3.5 rounded-2xl border border-slate-200 text-xs leading-relaxed text-slate-800">
            <span className="font-semibold text-[#B8892D] block mb-1">Authentic Context:</span>
            "{currentWord.example}"
          </div>

          {/* Reveal Controls */}
          <div className="space-y-2 pt-1">
            {!showEnglishMeaning ? (
              <button
                type="button"
                onClick={handleRevealEnglish}
                className="w-full flex items-center justify-center gap-2 min-h-[44px] py-2.5 px-4 bg-[#B8892D] hover:bg-[#A37622] text-white rounded-xl font-medium text-xs shadow-xs transition-transform active:scale-98"
              >
                <Eye className="w-4 h-4" />
                <span>Predict Meaning & Reveal Definition</span>
              </button>
            ) : (
              <div className="bg-white p-3.5 rounded-2xl border border-emerald-200 shadow-2xs space-y-2 animate-in fade-in duration-150">
                <div className="text-xs text-slate-800">
                  <span className="font-bold text-emerald-800 block mb-0.5">English Definition:</span>
                  {currentWord.englishMeaning}
                </div>
                {currentWord.synonym && (
                  <div className="text-[11px] text-slate-600">
                    <span className="font-semibold">Synonym:</span> {currentWord.synonym}
                  </div>
                )}
                {currentWord.antonymContrast && currentWord.antonymContrast !== 'no direct antonym' && (
                  <div className="text-[11px] text-slate-600">
                    <span className="font-semibold">Contrast:</span> {currentWord.antonymContrast}
                  </div>
                )}

                {/* Optional Arabic Reveal */}
                {!showArabicMeaning ? (
                  <button
                    type="button"
                    onClick={handleRevealArabic}
                    className="mt-2 text-[11px] text-[#008C96] hover:underline flex items-center gap-1 font-medium"
                  >
                    <span>Reveal Arabic translation</span>
                  </button>
                ) : (
                  <div className="mt-2 pt-2 border-t border-slate-100 text-xs font-arabic text-emerald-900 text-right dir-rtl">
                    <span className="text-[10px] text-slate-400 font-sans block mb-0.5">المعنى بالعربية:</span>
                    {currentWord.arabicMeaning}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Forward Button */}
          <button
            type="button"
            onClick={handleNextWord}
            className="w-full flex items-center justify-center gap-2 min-h-[44px] py-2.5 px-4 bg-[#172A2E] hover:bg-black text-white rounded-xl font-medium text-xs transition-colors"
          >
            <span>{wordIndex < currentGroupWords.length - 1 ? 'Next Word' : 'Proceed to Group Recall'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* PHASE 2: RETRIEVAL FROM MEANING */}
      {phase === 'recall' && currentWord && (
        <div className="bg-[#FFF9EC] border-2 border-[#008C96]/40 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="space-y-1">
            <span className="text-[11px] font-mono text-[#008C96] tracking-wide uppercase">
              Retrieval Check #{wordIndex + 1}
            </span>
            <h3 className="text-base font-bold text-slate-900">What word matches this definition?</h3>
          </div>

          <div className="bg-white/90 p-4 rounded-2xl border border-slate-200 text-sm font-medium text-slate-800 leading-relaxed">
            "{currentWord.englishMeaning}"
          </div>

          <form onSubmit={handleCheckRecall} className="space-y-3">
            <div>
              <label htmlFor="recall-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Type the target English word:
              </label>
              <input
                id="recall-input"
                type="text"
                autoComplete="off"
                value={userRecallGuess}
                onChange={e => setUserRecallGuess(e.target.value)}
                placeholder="Type word here..."
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:border-[#008C96]"
              />
            </div>

            <div className="flex gap-2">
              <button
                type="submit"
                disabled={!userRecallGuess.trim()}
                className="flex-1 min-h-[44px] py-2.5 bg-[#008C96] hover:bg-[#00767F] disabled:opacity-50 text-white rounded-xl font-semibold text-xs transition-colors"
              >
                Verify Retrieval
              </button>
              <button
                type="button"
                onClick={handleRevealEnglish}
                className="px-3 min-h-[44px] bg-[#EFE8D6] hover:bg-[#E5DDC7] text-slate-700 rounded-xl text-xs font-medium"
                title="Assisted peek (marked in records)"
              >
                Need Clue
              </button>
            </div>
          </form>

          {feedback && (
            <div className={`p-3 rounded-xl text-xs font-medium ${
              feedback.includes('Correct') ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-amber-50 text-amber-800 border border-amber-200'
            }`}>
              {feedback}
            </div>
          )}

          {feedback && (
            <button
              type="button"
              onClick={handleNextWord}
              className="w-full flex items-center justify-center gap-2 min-h-[44px] py-2.5 bg-[#172A2E] hover:bg-black text-white rounded-xl font-medium text-xs transition-colors"
            >
              <span>{wordIndex < currentGroupWords.length - 1 ? 'Next Retrieval Item' : 'Complete Group'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      )}

      {phase === 'completed' && (
        <div className="bg-white border border-[#B8892D]/40 rounded-3xl p-6 text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
            <Check className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Group {groupIndex + 1} Cycle Finished</h3>
          <p className="text-xs text-slate-600 leading-relaxed max-w-xs mx-auto">
            Your retrieval attempts are stored on this device. Mastery status will be updated when you practice again across subsequent sessions.
          </p>
          <div className="flex flex-col gap-2 pt-2">
            {groupIndex < groupsCount - 1 && (
              <button
                type="button"
                onClick={() => {
                  setGroupIndex(groupIndex + 1);
                  setWordIndex(0);
                  setPhase('observe');
                }}
                className="w-full min-h-[44px] py-2.5 bg-[#B8892D] text-white rounded-xl font-semibold text-xs hover:bg-[#A37622]"
              >
                Proceed to Group {groupIndex + 2}
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                setWordIndex(0);
                setPhase('observe');
              }}
              className="w-full min-h-[44px] py-2.5 bg-[#EFE8D6] text-slate-800 rounded-xl font-medium text-xs hover:bg-[#E5DDC7]"
            >
              Review Group {groupIndex + 1} Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
