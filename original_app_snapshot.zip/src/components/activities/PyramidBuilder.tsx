import React, { useState, useEffect } from 'react';
import { Check, X, ArrowRight, Lightbulb, RotateCcw, AlertTriangle } from 'lucide-react';
import { QuestionItem } from '../../types';
import { saveAttempt } from '../../services/storage';
import { GRAMMAR_REFERENCES } from '../../data/references';

interface PyramidBuilderProps {
  questions: QuestionItem[];
  onComplete: () => void;
  userId: string;
}

export const PyramidBuilder: React.FC<PyramidBuilderProps> = ({
  questions,
  onComplete,
  userId
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [writtenInput, setWrittenInput] = useState('');
  const [tokens, setTokens] = useState<string[]>([]);
  const [selectedTokens, setSelectedTokens] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [startTime] = useState(Date.now());

  const currentQ = questions[currentIndex];

  useEffect(() => {
    setSelectedOptionId(null);
    setWrittenInput('');
    setSubmitted(false);
    setShowHint(false);

    // If it's a model reconstruction written item, tokenize the model answer for guided reconstruction
    if (currentQ && currentQ.grading === 'teacher_review' && currentQ.sourceAnswer) {
      const cleanTokens = currentQ.sourceAnswer
        .replace(/[.,]/g, '')
        .split(/\s+/)
        .filter(t => t.length > 0)
        .sort(() => Math.random() - 0.5);
      setTokens(cleanTokens);
      setSelectedTokens([]);
    } else {
      setTokens([]);
      setSelectedTokens([]);
    }
  }, [currentIndex, currentQ?.id]);

  if (!currentQ) {
    return <div className="p-6 text-center text-slate-500">No questions available.</div>;
  }

  const isMcq = currentQ.grading === 'deterministic_choice' && !!currentQ.options;
  const isGuidedExact = currentQ.grading === 'guided_exact_match';
  const isReview = currentQ.grading === 'teacher_review';

  const grammarRef = currentQ.relatedGrammarId
    ? GRAMMAR_REFERENCES.find(g => g.id === currentQ.relatedGrammarId)
    : null;

  const handleSelectOption = (optId: string) => {
    if (submitted) return;
    setSelectedOptionId(optId);
  };

  const handleTokenClick = (token: string, tokenIndex: number) => {
    if (submitted) return;
    setSelectedTokens(prev => [...prev, token]);
    setTokens(prev => prev.filter((_, idx) => idx !== tokenIndex));
  };

  const handleRemoveToken = (token: string, tokenIndex: number) => {
    if (submitted) return;
    setSelectedTokens(prev => prev.filter((_, idx) => idx !== tokenIndex));
    setTokens(prev => [...prev, token]);
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (submitted) return;

    let responseValue = '';
    let isCorrectOutcome: 'correct' | 'incorrect' | 'pending' = 'pending';

    if (isMcq) {
      if (!selectedOptionId) return;
      responseValue = selectedOptionId;
      isCorrectOutcome = selectedOptionId === currentQ.correctOptionId ? 'correct' : 'incorrect';
    } else if (isGuidedExact) {
      responseValue = writtenInput.trim();
      const normInput = responseValue.toLowerCase();
      const normSource = currentQ.sourceAnswer.toLowerCase().trim();
      if (normInput === normSource) {
        isCorrectOutcome = 'correct';
      } else {
        // Guided exact match mismatch remains needs_review and does NOT increment confirmed wrong count
        isCorrectOutcome = 'pending';
      }
    } else {
      // Reconstruction or written response
      responseValue = selectedTokens.length > 0 ? selectedTokens.join(' ') : writtenInput.trim();
      isCorrectOutcome = 'pending';
    }

    setSubmitted(true);

    saveAttempt({
      id: `att-pyr-${currentQ.id}-${Date.now()}`,
      uid: userId,
      studentName: 'Learner',
      sessionId: `session-pyramid-${currentQ.bankId}`,
      contentVersion: '1.0.0',
      questionId: currentQ.id,
      gameMode: 'Pyramid Builder',
      difficultyRoute: currentQ.level,
      firstResponse: responseValue,
      submittedResponse: responseValue,
      submittedAt: new Date().toISOString(),
      objectiveOutcome: isCorrectOutcome,
      isFirstAttempt: true,
      hintCount: showHint ? 1 : 0,
      revealUsed: false,
      transcriptUsed: false,
      retryCount: 0,
      activeDurationMs: Date.now() - startTime,
      teacherReviewStatus: isReview || isCorrectOutcome === 'pending' ? 'pending' : 'none'
    });
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Top Bank Progress */}
      <div className="flex items-center justify-between text-xs text-slate-600 bg-white/80 p-3 rounded-2xl border border-slate-200">
        <div>
          <span className="font-semibold text-[#B8892D]">Bank {currentQ.bankId}</span>
          <span className="mx-2">·</span>
          <span>Question {currentIndex + 1} of {questions.length}</span>
        </div>
        <div className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-[#FFF9EC] text-[#B8892D] border border-[#B8892D]/30">
          {currentQ.level}
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-3xl p-5 shadow-sm space-y-4">
        <div>
          <span className="text-[11px] font-mono text-[#B8892D] tracking-wide uppercase">
            {currentQ.id} · {currentQ.grading.replace('_', ' ')}
          </span>
          <h3 className="text-base font-bold text-slate-900 mt-1 leading-snug">
            {currentQ.prompt}
          </h3>
        </div>

        {/* C2-14 Special Note */}
        {currentQ.id === 'C2-14' && (
          <div className="p-2.5 bg-blue-50 border border-blue-200 text-blue-900 rounded-xl text-xs flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4 text-blue-600 shrink-0" />
            <span>Note: C2-14 model changes 'every' to 'some'. This is cautious claim rewriting.</span>
          </div>
        )}

        {/* MCQ Mode */}
        {isMcq && currentQ.options && (
          <div className="space-y-2">
            {currentQ.options.map(opt => {
              const isSelected = selectedOptionId === opt.id;
              const isCorrectOpt = opt.id === currentQ.correctOptionId;
              let btnClass = 'bg-white border-slate-200 text-slate-800 hover:border-[#B8892D]';

              if (submitted) {
                if (isCorrectOpt) {
                  btnClass = 'bg-emerald-50 border-emerald-500 text-emerald-900 font-semibold';
                } else if (isSelected && !isCorrectOpt) {
                  btnClass = 'bg-red-50 border-red-300 text-red-900 line-through';
                } else {
                  btnClass = 'bg-white/60 border-slate-200 text-slate-500';
                }
              } else if (isSelected) {
                btnClass = 'bg-[#B8892D] border-[#B8892D] text-white font-medium shadow-xs';
              }

              return (
                <button
                  key={opt.id}
                  type="button"
                  disabled={submitted}
                  onClick={() => handleSelectOption(opt.id)}
                  className={`w-full min-h-[46px] p-3 text-left rounded-xl text-xs border flex items-center justify-between transition-all ${btnClass}`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-full border border-current flex items-center justify-center font-bold text-[10px]">
                      {opt.id}
                    </span>
                    <span>{opt.text}</span>
                  </div>
                  {submitted && isCorrectOpt && <Check className="w-4 h-4 text-emerald-600" />}
                  {submitted && isSelected && !isCorrectOpt && <X className="w-4 h-4 text-red-600" />}
                </button>
              );
            })}
          </div>
        )}

        {/* Guided Exact Match / Written Mode */}
        {(isGuidedExact || (isReview && tokens.length === 0)) && (
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label htmlFor="grammar-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Your Answer / Rewrite:
              </label>
              <textarea
                id="grammar-input"
                rows={2}
                disabled={submitted}
                value={writtenInput}
                onChange={e => setWrittenInput(e.target.value)}
                placeholder="Type your complete grammatical answer..."
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:border-[#B8892D]"
              />
            </div>
          </form>
        )}

        {/* Model Reconstruction with Token Blocks */}
        {isReview && tokens.length > 0 && (
          <div className="space-y-3">
            <span className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider block">
              Guided Practice: Model Reconstruction
            </span>

            {/* Target Assembly Area */}
            <div className="min-h-[50px] p-3 bg-white rounded-xl border-2 border-dashed border-[#B8892D]/40 flex flex-wrap gap-1.5 items-center">
              {selectedTokens.length === 0 ? (
                <span className="text-xs text-slate-400 italic">Tap word tokens below to construct the sentence...</span>
              ) : (
                selectedTokens.map((t, i) => (
                  <button
                    key={i}
                    type="button"
                    disabled={submitted}
                    onClick={() => handleRemoveToken(t, i)}
                    className="px-2.5 py-1 bg-[#FFF9EC] border border-[#B8892D] text-slate-900 rounded-lg text-xs font-medium hover:bg-amber-100 transition-colors"
                  >
                    {t}
                  </button>
                ))
              )}
            </div>

            {/* Available Tokens */}
            <div className="flex flex-wrap gap-1.5">
              {tokens.map((t, i) => (
                <button
                  key={i}
                  type="button"
                  disabled={submitted}
                  onClick={() => handleTokenClick(t, i)}
                  className="px-2.5 py-1 bg-white border border-slate-300 hover:border-[#008C96] text-slate-800 rounded-lg text-xs font-medium shadow-2xs transition-colors"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Hint button */}
        {!submitted && (
          <div className="flex items-center justify-between pt-1">
            <button
              type="button"
              onClick={() => setShowHint(!showHint)}
              className="text-xs text-[#008C96] hover:underline flex items-center gap-1 font-medium"
            >
              <Lightbulb className="w-3.5 h-3.5" />
              <span>{showHint ? 'Hide Grammar Clue' : 'Grammar Clue'}</span>
            </button>
            <button
              type="button"
              onClick={() => handleSubmit()}
              disabled={isMcq ? !selectedOptionId : isReview && tokens.length > 0 ? selectedTokens.length === 0 : !writtenInput.trim()}
              className="min-h-[44px] px-5 py-2 bg-[#B8892D] hover:bg-[#A37622] disabled:opacity-50 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors"
            >
              Submit Answer
            </button>
          </div>
        )}

        {/* Revealed Clue */}
        {showHint && grammarRef && (
          <div className="p-3 bg-[#E8F4F5] border border-[#008C96]/30 rounded-xl text-xs text-[#006E76] space-y-1 animate-in fade-in">
            <div className="font-semibold">{grammarRef.title}</div>
            <p className="text-[11px] leading-relaxed">{grammarRef.englishRules[0]}</p>
          </div>
        )}

        {/* Post-Submission Reveal and Pedagogical Explanation */}
        {submitted && (
          <div className="space-y-3 pt-2 border-t border-[#B8892D]/20 animate-in fade-in">
            <div className="bg-white/95 p-3.5 rounded-2xl border border-slate-200 space-y-2">
              <div className="text-xs font-semibold text-slate-800 flex items-center justify-between">
                <span>Source Model / Explanation</span>
                <span className="text-[11px] font-mono text-[#B8892D]">
                  {isMcq ? (selectedOptionId === currentQ.correctOptionId ? 'Correct' : 'Incorrect') : 'Needs Comparison / Review'}
                </span>
              </div>
              <p className="text-xs text-slate-900 font-medium">
                Approved model: <span className="text-emerald-900 font-bold">{currentQ.sourceAnswer}</span>
              </p>
              <p className="text-xs text-slate-600 leading-relaxed">
                {currentQ.explanation}
              </p>

              {/* Performer/Receiver or Condition/Result relationship */}
              {grammarRef && (
                <div className="mt-2 pt-2 border-t border-slate-100 text-[11px] text-slate-500">
                  <span className="font-semibold text-slate-700">Structural rule: </span>
                  {grammarRef.englishRules[1] || grammarRef.englishRules[0]}
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={handleNext}
              className="w-full min-h-[44px] py-2.5 bg-[#172A2E] hover:bg-black text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-2 transition-colors"
            >
              <span>{currentIndex < questions.length - 1 ? 'Next Question' : 'Complete Bank Session'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
