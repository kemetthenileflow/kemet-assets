import React, { useState, useEffect } from 'react';
import { Check, RotateCcw, ArrowRight, Languages } from 'lucide-react';
import { VocabularyItem } from '../../types';
import { saveAttempt } from '../../services/storage';

interface RosettaMatchProps {
  vocabularyList: VocabularyItem[];
  onComplete: () => void;
  userId: string;
}

export const RosettaMatch: React.FC<RosettaMatchProps> = ({
  vocabularyList,
  onComplete,
  userId
}) => {
  const [sessionIndex, setSessionIndex] = useState(0);
  const [selectedWordId, setSelectedWordId] = useState<string | null>(null);
  const [selectedDefId, setSelectedDefId] = useState<string | null>(null);
  const [matchedIds, setMatchedIds] = useState<string[]>([]);
  const [useArabic, setUseArabic] = useState<boolean>(false);
  const [shuffledWords, setShuffledWords] = useState<VocabularyItem[]>([]);
  const [shuffledDefs, setShuffledDefs] = useState<VocabularyItem[]>([]);
  const [mistakesCount, setMistakesCount] = useState(0);
  const [startTime] = useState(Date.now());
  const [typingWord, setTypingWord] = useState<VocabularyItem | null>(null);
  const [typingInput, setTypingInput] = useState('');
  const [typingPassed, setTypingPassed] = useState(false);
  const [typingError, setTypingError] = useState<string | null>(null);

  // Take 6 words for current round
  const currentSet = vocabularyList.slice(sessionIndex * 6, (sessionIndex + 1) * 6);

  useEffect(() => {
    if (currentSet.length > 0) {
      setShuffledWords([...currentSet].sort(() => Math.random() - 0.5));
      setShuffledDefs([...currentSet].sort(() => Math.random() - 0.5));
      setMatchedIds([]);
      setSelectedWordId(null);
      setSelectedDefId(null);
      setTypingWord(null);
      setTypingPassed(false);
    }
  }, [sessionIndex]);

  const handleWordSelect = (id: string) => {
    if (matchedIds.includes(id)) return;
    setSelectedWordId(id);
    if (selectedDefId) {
      evaluateMatch(id, selectedDefId);
    }
  };

  const handleDefSelect = (id: string) => {
    if (matchedIds.includes(id)) return;
    setSelectedDefId(id);
    if (selectedWordId) {
      evaluateMatch(selectedWordId, id);
    }
  };

  const evaluateMatch = (wordId: string, defId: string) => {
    if (wordId === defId) {
      // Match found
      const nextMatched = [...matchedIds, wordId];
      setMatchedIds(nextMatched);
      setSelectedWordId(null);
      setSelectedDefId(null);

      // If all 6 matched, initiate typing checkpoint
      if (nextMatched.length === currentSet.length) {
        // Select one random word for spelling checkpoint
        const randomTarget = currentSet[Math.floor(Math.random() * currentSet.length)];
        setTypingWord(randomTarget);
      }
    } else {
      // Mismatch
      setMistakesCount(prev => prev + 1);
      setTimeout(() => {
        setSelectedWordId(null);
        setSelectedDefId(null);
      }, 500);
    }
  };

  const handleTypingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!typingWord) return;

    const normalizedGuess = typingInput.trim().toLowerCase();
    const normalizedTarget = typingWord.word.trim().toLowerCase();
    const isCorrect = normalizedGuess === normalizedTarget;

    saveAttempt({
      id: `att-rosetta-${typingWord.id}-${Date.now()}`,
      uid: userId,
      studentName: 'Learner',
      sessionId: `session-rosetta-${sessionIndex}`,
      contentVersion: '1.0.0',
      vocabularyId: typingWord.id,
      gameMode: 'Rosetta Match',
      difficultyRoute: 'Foundation',
      firstResponse: typingInput,
      submittedResponse: typingInput,
      submittedAt: new Date().toISOString(),
      objectiveOutcome: isCorrect ? 'correct' : 'incorrect',
      isFirstAttempt: true,
      hintCount: 0,
      revealUsed: useArabic,
      transcriptUsed: false,
      retryCount: 0,
      activeDurationMs: Date.now() - startTime,
      teacherReviewStatus: 'none'
    });

    if (isCorrect) {
      setTypingPassed(true);
      setTypingError(null);
    } else {
      setTypingError(`Spelling mismatch. The correct spelling is "${typingWord.word}". Try again!`);
      setTypingInput('');
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Header bar */}
      <div className="flex items-center justify-between bg-white/80 border border-slate-200 p-3 rounded-2xl text-xs text-slate-700">
        <div className="font-semibold text-[#B8892D]">
          Round {sessionIndex + 1} · {matchedIds.length} of {currentSet.length} matched
        </div>
        <button
          type="button"
          onClick={() => setUseArabic(!useArabic)}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-medium transition-colors ${
            useArabic ? 'bg-[#008C96] text-white border-[#008C96]' : 'bg-[#FFF9EC] text-slate-700 border-[#B8892D]/30'
          }`}
          aria-label="Toggle Arabic definition support"
        >
          <Languages className="w-3.5 h-3.5" />
          <span>{useArabic ? 'Arabic on' : 'English only'}</span>
        </button>
      </div>

      {!typingWord ? (
        <div className="grid grid-cols-2 gap-3">
          {/* Words column */}
          <div className="space-y-2">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Vocabulary Word
            </span>
            {shuffledWords.map(item => {
              const isMatched = matchedIds.includes(item.id);
              const isSelected = selectedWordId === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  disabled={isMatched}
                  onClick={() => handleWordSelect(item.id)}
                  className={`w-full min-h-[50px] p-2.5 text-left rounded-xl text-xs font-semibold border transition-all ${
                    isMatched
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-800 opacity-60'
                      : isSelected
                      ? 'bg-[#B8892D] border-[#B8892D] text-white shadow-xs'
                      : 'bg-white border-slate-200 text-slate-800 hover:border-[#B8892D]/60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span>{item.word}</span>
                    {isMatched && <Check className="w-3.5 h-3.5 text-emerald-600" />}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Definitions column */}
          <div className="space-y-2">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Approved Meaning
            </span>
            {shuffledDefs.map(item => {
              const isMatched = matchedIds.includes(item.id);
              const isSelected = selectedDefId === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  disabled={isMatched}
                  onClick={() => handleDefSelect(item.id)}
                  className={`w-full min-h-[50px] p-2.5 text-left rounded-xl text-[11.5px] border leading-snug transition-all ${
                    isMatched
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-800 opacity-60'
                      : isSelected
                      ? 'bg-[#008C96] border-[#008C96] text-white shadow-xs'
                      : 'bg-white border-slate-200 text-slate-700 hover:border-[#008C96]/60'
                  }`}
                >
                  {useArabic ? (
                    <span className="font-arabic text-xs dir-rtl block text-right">
                      {item.arabicMeaning}
                    </span>
                  ) : (
                    <span>{item.englishMeaning}</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        /* Spelling Checkpoint after pair matching */
        <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-3xl p-5 shadow-sm space-y-4 animate-in fade-in">
          <div className="space-y-1">
            <span className="text-[11px] font-mono text-[#B8892D] tracking-wide uppercase">
              Checkpoint: Recognition is not spelling
            </span>
            <h3 className="text-base font-bold text-slate-900">
              Type the word for this matched meaning:
            </h3>
            <p className="text-xs text-slate-700 bg-white/80 p-3 rounded-xl border border-slate-200">
              "{typingWord.englishMeaning}"
            </p>
          </div>

          {!typingPassed ? (
            <form onSubmit={handleTypingSubmit} className="space-y-3">
              {typingError && (
                <div className="p-2.5 bg-amber-50 border border-amber-300 text-amber-900 rounded-xl text-xs font-medium">
                  {typingError}
                </div>
              )}
              <input
                type="text"
                autoComplete="off"
                value={typingInput}
                onChange={e => setTypingInput(e.target.value)}
                placeholder="Spell the word correctly..."
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:border-[#B8892D]"
              />
              <button
                type="submit"
                disabled={!typingInput.trim()}
                className="w-full min-h-[44px] py-2.5 bg-[#B8892D] hover:bg-[#A37622] disabled:opacity-50 text-white rounded-xl font-semibold text-xs transition-colors"
              >
                Submit Spelling Checkpoint
              </button>
            </form>
          ) : (
            <div className="space-y-3">
              <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                Spelling verified! Round completed.
              </div>
              <button
                type="button"
                onClick={() => {
                  if ((sessionIndex + 1) * 6 < vocabularyList.length) {
                    setSessionIndex(sessionIndex + 1);
                  } else {
                    onComplete();
                  }
                }}
                className="w-full min-h-[44px] py-2.5 bg-[#172A2E] hover:bg-black text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-2"
              >
                <span>Proceed to Next Set</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
