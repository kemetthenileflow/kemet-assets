import React, { useState } from 'react';
import { PenTool, Check, ArrowRight, HelpCircle, Languages, BookOpen } from 'lucide-react';
import { QuestionItem } from '../../types';
import { SHARED_TASKS } from '../../data/references';
import { saveAttempt } from '../../services/storage';

interface SocraticCouncilProps {
  questions: QuestionItem[]; // Challenge level questions across banks or shared tasks
  onComplete: () => void;
  userId: string;
}

export const SocraticCouncil: React.FC<SocraticCouncilProps> = ({
  questions,
  onComplete,
  userId
}) => {
  const [activeTab, setActiveTab] = useState<'socratic' | 'essay' | 'media' | 'translation'>('socratic');
  const [qIndex, setQIndex] = useState(0);

  // Socratic JRE fields
  const [judgment, setJudgment] = useState('');
  const [reason, setReason] = useState('');
  const [evidence, setEvidence] = useState('');
  const [counterargument, setCounterargument] = useState('');
  const [submittedSocratic, setSubmittedSocratic] = useState(false);

  // Essay writing fields
  const [essayText, setEssayText] = useState('');
  const [submittedEssay, setSubmittedEssay] = useState(false);

  // Media evaluation fields
  const [mediaRewritten, setMediaRewritten] = useState('');
  const [mediaNotes, setMediaNotes] = useState('');
  const [submittedMedia, setSubmittedMedia] = useState(false);

  // Translation fields
  const [transIndex, setTransIndex] = useState(0);
  const [transInput, setTransInput] = useState('');
  const [submittedTrans, setSubmittedTrans] = useState(false);

  const challengeQuestions = questions.filter(q => q.level === 'Challenge');
  const currentQ = challengeQuestions[qIndex] || challengeQuestions[0];
  const currentTrans = SHARED_TASKS.translationSentences[transIndex];

  const countWords = (text: string) => {
    return text.trim() ? text.trim().split(/\s+/).length : 0;
  };

  const handleSocraticSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!judgment.trim() || !reason.trim() || !evidence.trim()) return;

    setSubmittedSocratic(true);

    const fullJRE = `Judgment: ${judgment} | Reason: ${reason} | Evidence: ${evidence} | Counterargument: ${counterargument}`;

    saveAttempt({
      id: `att-soc-${currentQ.id}-${Date.now()}`,
      uid: userId,
      studentName: 'Learner',
      sessionId: `session-socratic-council`,
      contentVersion: '1.0.0',
      questionId: currentQ.id,
      gameMode: 'Socratic Council',
      difficultyRoute: 'Challenge',
      firstResponse: fullJRE,
      submittedResponse: fullJRE,
      submittedAt: new Date().toISOString(),
      objectiveOutcome: 'pending',
      isFirstAttempt: true,
      hintCount: 0,
      revealUsed: false,
      transcriptUsed: false,
      retryCount: 0,
      activeDurationMs: 45000,
      teacherReviewStatus: 'pending'
    });
  };

  const handleEssaySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!essayText.trim()) return;

    setSubmittedEssay(true);

    saveAttempt({
      id: `att-essay-${Date.now()}`,
      uid: userId,
      studentName: 'Learner',
      sessionId: `session-extended-writing`,
      contentVersion: '1.0.0',
      questionId: 'WRITING-TARGET-01',
      gameMode: 'Writer\'s Papyrus',
      difficultyRoute: 'Challenge',
      firstResponse: essayText,
      submittedResponse: essayText,
      submittedAt: new Date().toISOString(),
      objectiveOutcome: 'pending',
      isFirstAttempt: true,
      hintCount: 0,
      revealUsed: false,
      transcriptUsed: false,
      retryCount: 0,
      activeDurationMs: 90000,
      teacherReviewStatus: 'pending'
    });
  };

  const handleMediaSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mediaRewritten.trim()) return;

    setSubmittedMedia(true);

    const full = `Notes: ${mediaNotes} | Cautious Rewrite: ${mediaRewritten}`;

    saveAttempt({
      id: `att-media-${Date.now()}`,
      uid: userId,
      studentName: 'Learner',
      sessionId: `session-media-evaluation`,
      contentVersion: '1.0.0',
      questionId: 'MEDIA-EVAL-01',
      gameMode: 'Media Evaluation',
      difficultyRoute: 'Challenge',
      firstResponse: full,
      submittedResponse: full,
      submittedAt: new Date().toISOString(),
      objectiveOutcome: 'pending',
      isFirstAttempt: true,
      hintCount: 0,
      revealUsed: false,
      transcriptUsed: false,
      retryCount: 0,
      activeDurationMs: 60000,
      teacherReviewStatus: 'pending'
    });
  };

  const handleTransSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transInput.trim()) return;

    setSubmittedTrans(true);

    saveAttempt({
      id: `att-trans-${currentTrans.id}-${Date.now()}`,
      uid: userId,
      studentName: 'Learner',
      sessionId: `session-translation`,
      contentVersion: '1.0.0',
      questionId: `TRANS-${currentTrans.id}`,
      gameMode: 'Translation Practice',
      difficultyRoute: 'Apply',
      firstResponse: transInput,
      submittedResponse: transInput,
      submittedAt: new Date().toISOString(),
      objectiveOutcome: 'pending',
      isFirstAttempt: true,
      hintCount: 0,
      revealUsed: false,
      transcriptUsed: false,
      retryCount: 0,
      activeDurationMs: 30000,
      teacherReviewStatus: 'pending'
    });
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Tab Switcher */}
      <div className="flex bg-[#E8E1CE] p-1 rounded-xl text-xs font-semibold overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('socratic')}
          className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
            activeTab === 'socratic' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Socratic Council
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('essay')}
          className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
            activeTab === 'essay' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Writer's Papyrus
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('media')}
          className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
            activeTab === 'media' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Media Evaluation
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('translation')}
          className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
            activeTab === 'translation' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Translation
        </button>
      </div>

      {/* TAB 1: SOCRATIC JRE COUNCIL */}
      {activeTab === 'socratic' && currentQ && (
        <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-3xl p-5 shadow-sm space-y-4 animate-in fade-in">
          <div>
            <div className="flex items-center justify-between text-[11px] font-mono text-[#B8892D] mb-1">
              <span>{currentQ.id} · Challenge Deliberation</span>
              <span>Item {qIndex + 1} of {challengeQuestions.length}</span>
            </div>
            <h3 className="text-base font-bold text-slate-900 leading-snug">
              {currentQ.prompt}
            </h3>
          </div>

          {/* Socratic Facilitation Prompts */}
          <div className="p-3 bg-white/80 rounded-2xl border border-slate-200 text-xs space-y-1.5">
            <span className="font-semibold text-slate-800 flex items-center gap-1">
              <HelpCircle className="w-3.5 h-3.5 text-[#008C96]" /> Facilitation Guide:
            </span>
            <ul className="text-[11px] text-slate-600 list-disc list-inside space-y-0.5">
              <li>What makes you think that?</li>
              <li>Which source detail supports it?</li>
              <li>Could another interpretation fit?</li>
              <li>What would change your mind?</li>
            </ul>
          </div>

          <form onSubmit={handleSocraticSubmit} className="space-y-3">
            <div>
              <label htmlFor="soc-judgment" className="block text-xs font-semibold text-slate-700 mb-0.5">
                1. Your Stated Judgment:
              </label>
              <input
                id="soc-judgment"
                type="text"
                disabled={submittedSocratic}
                value={judgment}
                onChange={e => setJudgment(e.target.value)}
                placeholder="State your qualified position..."
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-[#B8892D]"
              />
            </div>

            <div>
              <label htmlFor="soc-reason" className="block text-xs font-semibold text-slate-700 mb-0.5">
                2. Reason (Why?):
              </label>
              <textarea
                id="soc-reason"
                rows={2}
                disabled={submittedSocratic}
                value={reason}
                onChange={e => setReason(e.target.value)}
                placeholder="Explain the underlying reason..."
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-[#B8892D]"
              />
            </div>

            <div>
              <label htmlFor="soc-evidence" className="block text-xs font-semibold text-slate-700 mb-0.5">
                3. Concrete Source Evidence:
              </label>
              <input
                id="soc-evidence"
                type="text"
                disabled={submittedSocratic}
                value={evidence}
                onChange={e => setEvidence(e.target.value)}
                placeholder="Cite specific data, quotation, or passage detail..."
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-[#B8892D]"
              />
            </div>

            <div>
              <label htmlFor="soc-counter" className="block text-xs font-semibold text-slate-700 mb-0.5">
                4. Counterargument & Revision (What would change your mind?):
              </label>
              <input
                id="soc-counter"
                type="text"
                disabled={submittedSocratic}
                value={counterargument}
                onChange={e => setCounterargument(e.target.value)}
                placeholder="Consider an opposing view or limitation..."
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-[#B8892D]"
              />
            </div>

            {!submittedSocratic ? (
              <button
                type="submit"
                disabled={!judgment.trim() || !reason.trim() || !evidence.trim()}
                className="w-full min-h-[44px] py-2.5 bg-[#B8892D] hover:bg-[#A37622] disabled:opacity-50 text-white rounded-xl font-semibold text-xs shadow-xs transition-colors"
              >
                Inscribe JRE Argument
              </button>
            ) : (
              <div className="space-y-3 pt-2 border-t border-slate-200">
                <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1 text-xs">
                  <div className="flex items-center justify-between font-bold text-slate-900">
                    <span>Approved Source Model (One Supported Answer)</span>
                    <span className="text-[11px] font-mono text-[#008C96]">Teacher Rubric</span>
                  </div>
                  <p className="text-slate-900 font-medium">{currentQ.sourceAnswer}</p>
                  <p className="text-slate-600 text-[11px]">{currentQ.explanation}</p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setJudgment('');
                    setReason('');
                    setEvidence('');
                    setCounterargument('');
                    setSubmittedSocratic(false);
                    if (qIndex < challengeQuestions.length - 1) setQIndex(qIndex + 1);
                    else onComplete();
                  }}
                  className="w-full min-h-[44px] py-2.5 bg-[#172A2E] hover:bg-black text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-2"
                >
                  <span>Next Challenge Deliberation</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </form>
        </div>
      )}

      {/* TAB 2: WRITER'S PAPYRUS (150-180 words) */}
      {activeTab === 'essay' && (
        <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-3xl p-5 shadow-sm space-y-4 animate-in fade-in">
          <div>
            <div className="flex items-center justify-between text-[11px] font-mono text-[#B8892D] mb-1">
              <span>Extended Writing Target</span>
              <span>{SHARED_TASKS.writingTargetWords}</span>
            </div>
            <h3 className="text-base font-bold text-slate-900 leading-snug">
              {SHARED_TASKS.writingPrompt}
            </h3>
          </div>

          <div className="p-3 bg-white/80 rounded-2xl border border-slate-200 text-xs space-y-1">
            <span className="font-semibold text-slate-800">Rubric Criteria:</span>
            <ul className="text-[11px] text-slate-600 list-disc list-inside space-y-0.5">
              {SHARED_TASKS.writingRequirements.map((req, i) => (
                <li key={i}>{req}</li>
              ))}
            </ul>
          </div>

          <form onSubmit={handleEssaySubmit} className="space-y-3">
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-1">
                <label htmlFor="essay-textarea">Your Composition:</label>
                <span className={`text-[11px] font-mono ${countWords(essayText) >= 150 && countWords(essayText) <= 180 ? 'text-emerald-700 font-bold' : 'text-slate-500'}`}>
                  {countWords(essayText)} words
                </span>
              </div>
              <textarea
                id="essay-textarea"
                rows={7}
                disabled={submittedEssay}
                value={essayText}
                onChange={e => setEssayText(e.target.value)}
                placeholder="Compose your paragraph here incorporating relative clauses and conditionals..."
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 leading-relaxed focus:outline-none focus:border-[#B8892D]"
              />
            </div>

            {!submittedEssay ? (
              <button
                type="submit"
                disabled={countWords(essayText) < 20}
                className="w-full min-h-[44px] py-2.5 bg-[#B8892D] hover:bg-[#A37622] disabled:opacity-50 text-white rounded-xl font-semibold text-xs shadow-xs"
              >
                Submit Composition for Teacher Rubric
              </button>
            ) : (
              <div className="space-y-3 pt-2 border-t border-slate-200">
                <div className="p-3 bg-white rounded-2xl border border-slate-200 space-y-2 text-xs">
                  <div className="font-bold text-slate-900">Study the Benchmark Model Paragraph:</div>
                  <p className="text-slate-700 leading-relaxed italic text-[11.5px] bg-[#FFF9EC] p-3 rounded-xl border border-[#B8892D]/20">
                    "{SHARED_TASKS.modelParagraph}"
                  </p>
                  <div className="text-[11px] text-slate-500">
                    Notice how the writer qualifies the claim without guaranteeing identical results for everyone.
                  </div>
                </div>
              </div>
            )}
          </form>
        </div>
      )}

      {/* TAB 3: MEDIA POST EVALUATION */}
      {activeTab === 'media' && (
        <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-3xl p-5 shadow-sm space-y-4 animate-in fade-in">
          <div>
            <span className="text-[11px] font-mono text-[#B8892D] uppercase tracking-wide block mb-1">
              Media Evaluation & Hedging
            </span>
            <h3 className="text-base font-bold text-slate-900">Evaluate and Rewrite this Viral Post:</h3>
          </div>

          <div className="p-4 bg-white rounded-2xl border-2 border-amber-200 text-xs text-slate-800 leading-relaxed space-y-1">
            <span className="text-[10px] font-mono uppercase text-amber-700 block font-semibold">Source Post:</span>
            <p className="font-medium text-slate-900">"{SHARED_TASKS.mediaPostToEvaluate.text}"</p>
          </div>

          <div className="p-3 bg-white/70 rounded-xl border border-slate-200 text-xs space-y-1">
            <span className="font-semibold text-slate-700">Tasks to complete:</span>
            <ul className="text-[11px] text-slate-600 list-disc list-inside space-y-0.5">
              {SHARED_TASKS.mediaPostToEvaluate.tasks.map((t, i) => (
                <li key={i}>{t}</li>
              ))}
            </ul>
          </div>

          <form onSubmit={handleMediaSubmit} className="space-y-3">
            <div>
              <label htmlFor="media-notes" className="block text-xs font-semibold text-slate-700 mb-0.5">
                Analysis (Evaluative words, absolutes, rhetorical question):
              </label>
              <textarea
                id="media-notes"
                rows={2}
                disabled={submittedMedia}
                value={mediaNotes}
                onChange={e => setMediaNotes(e.target.value)}
                placeholder="Identify 'brilliant', 'always', 'everyone'..."
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-[#B8892D]"
              />
            </div>

            <div>
              <label htmlFor="media-rewrite" className="block text-xs font-semibold text-slate-700 mb-0.5">
                Cautious Rewrite (Using hedging like may, might, some):
              </label>
              <textarea
                id="media-rewrite"
                rows={2}
                disabled={submittedMedia}
                value={mediaRewritten}
                onChange={e => setMediaRewritten(e.target.value)}
                placeholder="Rewrite the post with cautious scientific language..."
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-[#B8892D]"
              />
            </div>

            {!submittedMedia ? (
              <button
                type="submit"
                disabled={!mediaRewritten.trim()}
                className="w-full min-h-[44px] py-2.5 bg-[#B8892D] hover:bg-[#A37622] disabled:opacity-50 text-white rounded-xl font-semibold text-xs shadow-xs"
              >
                Submit Cautious Rewrite
              </button>
            ) : (
              <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs space-y-1">
                <div className="font-bold text-slate-900">Approved Reference Rewrite:</div>
                <p className="text-slate-700 italic">
                  "This study routine has helped some students organise their time effectively. Planning regular revision may reduce stress for certain learners, though individual needs vary."
                </p>
              </div>
            )}
          </form>
        </div>
      )}

      {/* TAB 4: TRANSLATION PRACTICE */}
      {activeTab === 'translation' && currentTrans && (
        <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-3xl p-5 shadow-sm space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#B8892D]">
            <span>Translation #{currentTrans.id} of 10</span>
            <span>{currentTrans.direction === 'en-to-ar' ? 'English → Arabic' : 'Arabic → English'}</span>
          </div>

          <div className={`p-4 bg-white rounded-2xl border border-slate-200 text-sm font-semibold text-slate-900 ${
            currentTrans.direction === 'ar-to-en' ? 'font-arabic text-base text-right dir-rtl' : ''
          }`}>
            {currentTrans.text}
          </div>

          <form onSubmit={handleTransSubmit} className="space-y-3">
            <div>
              <label htmlFor="trans-input" className="block text-xs font-semibold text-slate-700 mb-1">
                Your Translation (Preserve time and degree of certainty):
              </label>
              <input
                id="trans-input"
                type="text"
                disabled={submittedTrans}
                value={transInput}
                onChange={e => setTransInput(e.target.value)}
                placeholder={currentTrans.direction === 'en-to-ar' ? 'اكتب الترجمة هنا...' : 'Type English translation...'}
                className={`w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:border-[#B8892D] ${
                  currentTrans.direction === 'en-to-ar' ? 'font-arabic text-sm text-right dir-rtl' : ''
                }`}
              />
            </div>

            {!submittedTrans ? (
              <button
                type="submit"
                disabled={!transInput.trim()}
                className="w-full min-h-[44px] py-2.5 bg-[#B8892D] hover:bg-[#A37622] disabled:opacity-50 text-white rounded-xl font-semibold text-xs shadow-xs"
              >
                Submit Translation
              </button>
            ) : (
              <div className="space-y-3 pt-2 border-t border-slate-200">
                <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1 text-xs">
                  <div className="font-bold text-slate-900">Approved Reference Translation:</div>
                  <p className={`font-semibold text-emerald-800 ${currentTrans.direction === 'en-to-ar' ? 'font-arabic text-sm text-right dir-rtl' : ''}`}>
                    {currentTrans.model}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setTransInput('');
                    setSubmittedTrans(false);
                    if (transIndex < SHARED_TASKS.translationSentences.length - 1) {
                      setTransIndex(transIndex + 1);
                    } else {
                      onComplete();
                    }
                  }}
                  className="w-full min-h-[44px] py-2.5 bg-[#172A2E] hover:bg-black text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-2"
                >
                  <span>Next Translation</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </form>
        </div>
      )}
    </div>
  );
};
