import React, { useState } from 'react';
import { Compass, BookOpen, ArrowRight, User, AlertCircle } from 'lucide-react';
import { QuestionItem } from '../../types';
import { READING_PASSAGES } from '../../data/references';
import { saveAttempt } from '../../services/storage';

interface StoryQuestProps {
  questions: QuestionItem[]; // N1 questions (30 total)
  onComplete: () => void;
  userId: string;
}

export const StoryQuest: React.FC<StoryQuestProps> = ({
  questions,
  onComplete,
  userId
}) => {
  const [roundIndex, setRoundIndex] = useState(0); // 3 rounds of 10 questions
  const [questionInRound, setQuestionInRound] = useState(0);
  const [showStorySummary, setShowStorySummary] = useState(false);
  const [writtenResponse, setWrittenResponse] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [startTime] = useState(Date.now());

  const roundQuestions = questions.slice(roundIndex * 10, (roundIndex + 1) * 10);
  const currentQ = roundQuestions[questionInRound];

  const storyPassage = READING_PASSAGES.find(p => p.id === 'STORY-CH1');

  if (!currentQ) {
    return <div className="p-6 text-center text-slate-500">Story Quest complete.</div>;
  }

  // Character badges referenced in Chapter 1
  const characterLabels = [
    { name: 'Edward Malone', role: 'Reporter, Daily Gazette, age 23' },
    { name: 'Gladys Hungerton', role: 'Values courage in character' },
    { name: 'Mr McArdle', role: 'News Editor' },
    { name: 'Prof. Challenger', role: 'Zoologist, South American claims' },
    { name: 'Tarp Henry', role: 'Savage Club associate' },
    { name: 'Austin', role: 'Kensington servant' },
    { name: 'Mrs Challenger', role: 'Warns Malone at door' }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!writtenResponse.trim()) return;

    setSubmitted(true);

    saveAttempt({
      id: `att-story-${currentQ.id}-${Date.now()}`,
      uid: userId,
      studentName: 'Learner',
      sessionId: `session-story-round-${roundIndex + 1}`,
      contentVersion: '1.0.0',
      questionId: currentQ.id,
      gameMode: 'Story Quest',
      difficultyRoute: currentQ.level,
      firstResponse: writtenResponse,
      submittedResponse: writtenResponse,
      submittedAt: new Date().toISOString(),
      objectiveOutcome: 'pending',
      isFirstAttempt: true,
      hintCount: 0,
      revealUsed: false,
      transcriptUsed: false,
      retryCount: 0,
      activeDurationMs: Date.now() - startTime,
      teacherReviewStatus: 'pending'
    });
  };

  const handleNext = () => {
    setWrittenResponse('');
    setSubmitted(false);

    if (questionInRound < roundQuestions.length - 1) {
      setQuestionInRound(questionInRound + 1);
    } else {
      if (roundIndex < 2) {
        setRoundIndex(roundIndex + 1);
        setQuestionInRound(0);
      } else {
        onComplete();
      }
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Top Banner */}
      <div className="bg-[#FFF9EC] border border-[#B8892D]/40 p-3.5 rounded-2xl flex items-center justify-between text-xs">
        <div>
          <span className="font-semibold text-[#B8892D]">The Lost World · Chapter 1</span>
          <div className="text-[11px] text-slate-500">
            Round {roundIndex + 1} of 3 · Question {questionInRound + 1} of 10
          </div>
        </div>
        <button
          type="button"
          onClick={() => setShowStorySummary(!showStorySummary)}
          className="px-2.5 py-1 bg-[#E8E1CE] hover:bg-[#DCD4BF] text-slate-800 rounded-lg text-xs font-medium flex items-center gap-1"
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>{showStorySummary ? 'Hide Synopsis' : 'Chapter Synopsis'}</span>
        </button>
      </div>

      {/* Story Summary Collapsible */}
      {showStorySummary && storyPassage && (
        <div className="bg-white p-4 rounded-2xl border border-[#B8892D]/30 space-y-2 text-xs leading-relaxed text-slate-800 animate-in fade-in">
          <div className="font-bold text-slate-900 border-b pb-1">
            The Lost World | Chapter 1 Synopsis
          </div>
          {storyPassage.paragraphs.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
          <div className="p-2 bg-amber-50 border border-amber-200 text-amber-900 rounded-lg text-[11px] font-medium">
            {storyPassage.disclaimer}
          </div>
        </div>
      )}

      {/* Main Task Card */}
      <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-3xl p-5 shadow-sm space-y-4">
        <div>
          <span className="text-[11px] font-mono text-[#B8892D] tracking-wide uppercase">
            {currentQ.id} · {currentQ.level}
          </span>
          <h3 className="text-base font-bold text-slate-900 mt-1 leading-snug">
            {currentQ.prompt}
          </h3>
        </div>

        {/* Relevant Characters Mentioned */}
        <div className="pt-1">
          <span className="text-[10.5px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
            Active Story Characters (Chapter 1 Only)
          </span>
          <div className="flex flex-wrap gap-1">
            {characterLabels.map(char => (
              <span
                key={char.name}
                className="inline-flex items-center gap-1 px-2 py-0.5 bg-white border border-slate-200 rounded-md text-[11px] text-slate-700 font-medium"
                title={char.role}
              >
                <User className="w-3 h-3 text-[#B8892D]" />
                {char.name}
              </span>
            ))}
          </div>
        </div>

        {/* Written Response Form */}
        <form onSubmit={handleSubmit} className="space-y-3 pt-2">
          <div>
            <label htmlFor="story-input" className="block text-xs font-semibold text-slate-700 mb-1">
              Your Chapter 1 Observation / Analysis:
            </label>
            <textarea
              id="story-input"
              rows={3}
              disabled={submitted}
              value={writtenResponse}
              onChange={e => setWrittenResponse(e.target.value)}
              placeholder="State the character action, motive, or evidence based on Chapter 1..."
              className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:border-[#B8892D]"
            />
          </div>

          {!submitted ? (
            <button
              type="submit"
              disabled={!writtenResponse.trim()}
              className="w-full min-h-[44px] py-2.5 bg-[#B8892D] hover:bg-[#A37622] disabled:opacity-50 text-white rounded-xl font-semibold text-xs shadow-xs transition-colors"
            >
              Submit Response for Teacher Review
            </button>
          ) : (
            <div className="space-y-3 pt-2 border-t border-slate-200">
              <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1.5 text-xs">
                <div className="flex items-center justify-between font-bold text-slate-900">
                  <span>Approved Source Model</span>
                  <span className="text-[11px] font-mono text-[#008C96]">Awaiting Review</span>
                </div>
                <p className="text-slate-900 font-medium">
                  {currentQ.sourceAnswer}
                </p>
                <p className="text-slate-600 text-[11.5px] leading-relaxed">
                  Evidence location: {currentQ.explanation}
                </p>
              </div>

              <button
                type="button"
                onClick={handleNext}
                className="w-full min-h-[44px] py-2.5 bg-[#172A2E] hover:bg-black text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-2"
              >
                <span>
                  {questionInRound < roundQuestions.length - 1
                    ? 'Next Question'
                    : roundIndex < 2
                    ? 'Start Next Round of 10'
                    : 'Complete Story Quest'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
