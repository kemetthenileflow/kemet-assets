import React from 'react';
import { ArrowRight, BookOpen, Scroll, Headphones, PenTool, Layers, Compass, ChevronRight, ShieldAlert } from 'lucide-react';
import { KemetLogo } from '../KemetLogo';

interface HomeViewProps {
  onStartJourney: () => void;
  onOpenGateway: (gateway: 'vocab' | 'story' | 'challenge') => void;
  onOpenLibraryCategory: (category: 'reading' | 'grammar' | 'listening' | 'writing' | 'vocab' | 'story') => void;
  unapprovedCount: number;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onStartJourney,
  onOpenGateway,
  onOpenLibraryCategory,
  unapprovedCount
}) => {
  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Top Header Logo Area */}
      <div className="pt-2 text-center">
        <KemetLogo size="lg" className="mx-auto" />
      </div>

      {/* Teacher Content Review Pending Notice (Truthful State) */}
      {unapprovedCount > 0 && (
        <div className="bg-amber-50 border border-amber-200/80 rounded-2xl p-2.5 text-xs text-amber-900 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              Teacher review pending for {unapprovedCount} imported items.
            </span>
          </div>
          <span className="text-[11px] font-semibold text-amber-700">Preview Mode</span>
        </div>
      )}

      {/* Compact Visual Hero Banner (ramesses, nefertiti, nile background aesthetic) */}
      <div className="relative rounded-3xl overflow-hidden shadow-md border border-[#B8892D]/30 bg-gradient-to-b from-[#FFF9EC] via-[#F4ECD8] to-[#EAE0C4]">
        {/* Subtle decorative Nile illustration overlay */}
        <div className="p-5 text-center relative z-10 space-y-2.5">
          <h1 className="font-display text-2xl font-black text-[#172A2E] tracking-tight leading-tight">
            Your adventure <br />
            starts here.
          </h1>
          <p className="text-xs text-slate-700 max-w-xs mx-auto leading-relaxed">
            Discover English. Unlock your world. Restoring the living library of the Nile.
          </p>

          <div className="pt-1">
            <button
              type="button"
              onClick={onStartJourney}
              className="inline-flex items-center justify-center gap-2 min-h-[48px] px-6 py-2.5 bg-gradient-to-r from-[#008C96] to-[#00A7B3] hover:from-[#007881] hover:to-[#008C96] text-white rounded-full font-bold text-xs shadow-md shadow-[#008C96]/20 transition-transform active:scale-95"
            >
              <span>Start Your Journey</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* 3 Step Ribbon */}
          <div className="flex items-center justify-center gap-6 pt-2 text-[11px] font-semibold text-[#B8892D]">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#B8892D] ring-2 ring-[#B8892D]/30" />
              <span>Discover</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#B8892D] ring-2 ring-[#B8892D]/30" />
              <span>Practice</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#B8892D] ring-2 ring-[#B8892D]/30" />
              <span>Master</span>
            </div>
          </div>
        </div>
      </div>

      {/* THREE MANDATORY HOME GATEWAY CARDS */}
      <div className="space-y-3">
        {/* Gateway 1: Vocabulary Vault */}
        <button
          type="button"
          onClick={() => onOpenGateway('vocab')}
          className="w-full text-left bg-[#FFF9EC] border-2 border-[#B8892D]/40 hover:border-[#B8892D] rounded-2xl p-4 shadow-xs transition-all active:scale-[0.99] flex items-center justify-between group"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#B8892D] to-[#8C6212] flex items-center justify-center text-white shadow-2xs">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base text-[#172A2E] group-hover:text-[#B8892D] transition-colors">
                Vocabulary Vault
              </h3>
              <p className="text-xs text-slate-600">66 Unit 1 words · Spaced retrieval</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-[#B8892D] transition-colors" />
        </button>

        {/* Gateway 2: Story Quest */}
        <button
          type="button"
          onClick={() => onOpenGateway('story')}
          className="w-full text-left bg-[#FFF9EC] border-2 border-[#B8892D]/40 hover:border-[#B8892D] rounded-2xl p-4 shadow-xs transition-all active:scale-[0.99] flex items-center justify-between group"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#008C96] to-[#005F66] flex items-center justify-center text-white shadow-2xs">
              <Compass className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base text-[#172A2E] group-hover:text-[#008C96] transition-colors">
                Story Quest
              </h3>
              <p className="text-xs text-slate-600">Chapter 1 · 30 questions (The Lost World)</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-[#008C96] transition-colors" />
        </button>

        {/* Gateway 3: Challenge Arena */}
        <button
          type="button"
          onClick={() => onOpenGateway('challenge')}
          className="w-full text-left bg-[#FFF9EC] border-2 border-[#B8892D]/40 hover:border-[#B8892D] rounded-2xl p-4 shadow-xs transition-all active:scale-[0.99] flex items-center justify-between group"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#172A2E] to-[#2E4F56] flex items-center justify-center text-white shadow-2xs">
              <Scroll className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base text-[#172A2E] group-hover:text-[#B8892D] transition-colors">
                Challenge Arena
              </h3>
              <p className="text-xs text-slate-600">330 questions across 11 banks</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-[#B8892D] transition-colors" />
        </button>
      </div>

      {/* EXPLORE THE LIBRARY SHORTCUTS */}
      <div className="space-y-2.5 pt-2">
        <div className="flex items-center justify-between">
          <h2 className="font-display font-bold text-sm text-[#172A2E]">
            Explore the Library
          </h2>
          <span className="text-[11px] text-slate-500">Curated Unit 1 Content</span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => onOpenLibraryCategory('reading')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white border border-slate-200 hover:border-[#008C96] transition-colors min-h-[74px]"
          >
            <BookOpen className="w-5 h-5 text-[#008C96] mb-1" />
            <span className="text-xs font-semibold text-slate-800">Reading</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenLibraryCategory('grammar')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white border border-slate-200 hover:border-[#B8892D] transition-colors min-h-[74px]"
          >
            <Scroll className="w-5 h-5 text-[#B8892D] mb-1" />
            <span className="text-xs font-semibold text-slate-800">Grammar</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenLibraryCategory('listening')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white border border-slate-200 hover:border-[#008C96] transition-colors min-h-[74px]"
          >
            <Headphones className="w-5 h-5 text-[#008C96] mb-1" />
            <span className="text-xs font-semibold text-slate-800">Listening</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenLibraryCategory('writing')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white border border-slate-200 hover:border-[#B8892D] transition-colors min-h-[74px]"
          >
            <PenTool className="w-5 h-5 text-[#B8892D] mb-1" />
            <span className="text-xs font-semibold text-slate-800">Writing</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenLibraryCategory('vocab')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white border border-slate-200 hover:border-[#008C96] transition-colors min-h-[74px]"
          >
            <Layers className="w-5 h-5 text-[#008C96] mb-1" />
            <span className="text-xs font-semibold text-slate-800">Vocabulary</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenLibraryCategory('story')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white border border-slate-200 hover:border-[#B8892D] transition-colors min-h-[74px]"
          >
            <Compass className="w-5 h-5 text-[#B8892D] mb-1" />
            <span className="text-xs font-semibold text-slate-800">Story</span>
          </button>
        </div>
      </div>
    </div>
  );
};
