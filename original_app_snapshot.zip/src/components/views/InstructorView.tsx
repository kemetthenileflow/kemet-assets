import React, { useState } from 'react';
import { ShieldCheck, CheckCircle2, AlertTriangle, FileSpreadsheet, Mail, Edit3, Send, Check, X, RefreshCw, HardDrive } from 'lucide-react';
import { runImportAudit, AuditReport } from '../../services/audit';
import { ALL_330_QUESTIONS, BANK_METADATA } from '../../data/questions';
import {
  getTeacherApprovals,
  setTeacherApproval,
  approveAllQuestions,
  getTeacherCorrections,
  saveTeacherCorrection,
  getStoredAttempts,
  saveAttempt,
  getStoredReportJobs,
  saveReportJob,
  exportAttemptsToCSV
} from '../../services/storage';

export const InstructorView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'audit' | 'approval' | 'reviews' | 'reports'>('audit');
  const [audit, setAudit] = useState<AuditReport>(runImportAudit());
  const [approvals, setApprovals] = useState(getTeacherApprovals());
  const [corrections, setCorrections] = useState(getTeacherCorrections());
  const [selectedBankFilter, setSelectedBankFilter] = useState<string>('ALL');
  const [editingQuestionId, setEditingQuestionId] = useState<string | null>(null);
  const [correctionAnswer, setCorrectionAnswer] = useState<string>('');
  const [correctionRationale, setCorrectionRationale] = useState<string>('');

  // Report configuration
  const [reportJobs, setReportJobs] = useState(getStoredReportJobs());
  const [recipientEmail, setRecipientEmail] = useState('Kemetthenileflow@gmail.com');
  const [scheduleFreq, setScheduleFreq] = useState('Daily at 21:00 (Africa/Cairo)');
  const [emailProviderStatus, setEmailProviderStatus] = useState<'Not configured' | 'Ready' | 'Sent'>('Not configured');
  const [dispatchMessage, setDispatchMessage] = useState<string | null>(null);

  // Review queue
  const attempts = getStoredAttempts();
  const pendingQueue = attempts.filter(a => a.teacherReviewStatus === 'pending');
  const [activeReviewId, setActiveReviewId] = useState<string | null>(null);
  const [rubricScore, setRubricScore] = useState<number>(5);
  const [rubricFeedback, setRubricFeedback] = useState<string>('');

  const refreshAudit = () => {
    setAudit(runImportAudit());
    setApprovals(getTeacherApprovals());
    setCorrections(getTeacherCorrections());
  };

  const handleToggleApproval = (qId: string) => {
    const nextState = !approvals[qId];
    setTeacherApproval(qId, nextState);
    setApprovals(prev => ({ ...prev, [qId]: nextState }));
    refreshAudit();
  };

  const handleApproveAll = () => {
    approveAllQuestions();
    refreshAudit();
  };

  const handleStartEdit = (qId: string, currentAns: string) => {
    setEditingQuestionId(qId);
    setCorrectionAnswer(currentAns);
    setCorrectionRationale('');
  };

  const handleSaveCorrection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingQuestionId || !correctionAnswer.trim()) return;

    const existing = corrections[editingQuestionId];
    const newVersion = existing ? existing.version + 1 : 1;

    saveTeacherCorrection({
      questionId: editingQuestionId,
      version: newVersion,
      correctedAnswer: correctionAnswer.trim(),
      rationale: correctionRationale.trim() || 'Teacher verification adjustment',
      updatedAt: new Date().toISOString()
    });

    setCorrections(getTeacherCorrections());
    setEditingQuestionId(null);
    refreshAudit();
  };

  const handleGradeAttempt = (attemptId: string) => {
    const target = attempts.find(a => a.id === attemptId);
    if (!target) return;

    const updated = {
      ...target,
      teacherReviewStatus: 'reviewed' as const,
      teacherRubricScore: rubricScore,
      teacherFeedback: rubricFeedback
    };

    saveAttempt(updated);
    setActiveReviewId(null);
    setRubricFeedback('');
  };

  const handleExportCSV = () => {
    const csv = exportAttemptsToCSV(attempts);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.setAttribute('download', `kemet_instructor_audit_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleTestReportJob = () => {
    // Truthful report dispatcher
    const cairoTime = new Date().toLocaleString('en-US', { timeZone: 'Africa/Cairo' });
    const firstObjective = attempts.filter(a => a.isFirstAttempt && a.objectiveOutcome);
    const correctCount = firstObjective.filter(a => a.objectiveOutcome === 'correct').length;

    const job = {
      id: `report-job-${Date.now()}`,
      recipientEmail,
      scheduledTime: `${scheduleFreq} · Generated ${cairoTime}`,
      status: 'Ready' as const,
      timezone: 'Africa/Cairo',
      learnerCount: Array.from(new Set(attempts.map(a => a.uid))).length,
      objectiveNumerator: correctCount,
      objectiveDenominator: firstObjective.length,
      pendingReviewsCount: pendingQueue.length,
      lastProviderResponse: 'Report preview assembled. Live external SMTP or Gmail API dispatch awaits server-side secret configuration.'
    };

    saveReportJob(job);
    setReportJobs(getStoredReportJobs());
    setDispatchMessage('Report payload generated for Kemetthenileflow@gmail.com with Africa/Cairo timestamp. External email provider requires production credential binding.');
  };

  const filteredQuestions = ALL_330_QUESTIONS.filter(q =>
    selectedBankFilter === 'ALL' ? true : q.bankId === selectedBankFilter
  );

  return (
    <div className="space-y-4 pb-8 animate-in fade-in duration-200">
      {/* View Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="font-display text-xl font-bold text-[#172A2E]">Instructor Console</h2>
          <p className="text-xs text-slate-600">
            Source content verification, item approval, and Cairo delivery dispatcher.
          </p>
        </div>
        <span className="text-[11px] font-mono px-2 py-1 bg-[#172A2E] text-white rounded-lg">
          Authorized Staff
        </span>
      </div>

      {/* Tabs */}
      <div className="flex bg-[#E8E1CE] p-1 rounded-2xl text-xs font-semibold overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('audit')}
          className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
            activeTab === 'audit' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Import Audit ({audit.isValid ? 'Verified' : 'Notice'})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('approval')}
          className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
            activeTab === 'approval' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Item Approvals ({audit.teacherApprovedCount}/330)
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('reviews')}
          className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
            activeTab === 'reviews' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Review Queue ({pendingQueue.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('reports')}
          className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
            activeTab === 'reports' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Cairo Dispatcher
        </button>
      </div>

      {/* TAB 1: IMPORT VALIDATION AUDIT */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-3xl p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between border-b border-[#B8892D]/20 pb-2">
              <span className="font-display font-bold text-sm text-slate-900">
                Source Data Inventory & Import Integrity
              </span>
              <button
                type="button"
                onClick={refreshAudit}
                className="p-1 rounded-lg text-slate-600 hover:text-black flex items-center gap-1 text-xs"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Refresh
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-white p-3 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 font-mono uppercase block">Primary Vocabulary</span>
                <div className="text-base font-bold text-slate-900 tabular-nums">
                  {audit.primaryVocabularyCount} / {audit.expectedPrimaryVocabularyCount} words
                </div>
                <div className="text-[11px] text-emerald-700">✓ Exactly 66 Unit 1 entries</div>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 font-mono uppercase block">Story Lexicon (Separate)</span>
                <div className="text-base font-bold text-slate-900 tabular-nums">
                  {audit.storyLexiconCount} / {audit.expectedStoryLexiconCount} words
                </div>
                <div className="text-[11px] text-emerald-700">✓ Exactly 59 story entries</div>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 font-mono uppercase block">Total Source Questions</span>
                <div className="text-base font-bold text-slate-900 tabular-nums">
                  {audit.totalQuestionsCount} / {audit.expectedQuestionsCount}
                </div>
                <div className="text-[11px] text-emerald-700">✓ Exactly 330 numbered items</div>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 font-mono uppercase block">Question Banks</span>
                <div className="text-base font-bold text-slate-900 tabular-nums">
                  11 Banks (30 each)
                </div>
                <div className="text-[11px] text-emerald-700">✓ V1..N1 all populated</div>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 font-mono uppercase block">Deterministic Choice</span>
                <div className="text-base font-bold text-slate-900 tabular-nums">
                  {audit.deterministicChoiceCount} / {audit.expectedDeterministicChoiceCount}
                </div>
                <div className="text-[11px] text-slate-500">150 MCQ + 19 bracket choices</div>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 font-mono uppercase block">Teacher Review & Exact</span>
                <div className="text-base font-bold text-slate-900 tabular-nums">
                  {audit.teacherReviewCount} Review / {audit.guidedExactMatchCount} Exact
                </div>
                <div className="text-[11px] text-slate-500">152 open + 9 guided exact</div>
              </div>
            </div>

            {/* Audio Files Audit */}
            <div className="bg-white p-3 rounded-2xl border border-slate-200 text-xs space-y-1.5">
              <span className="font-semibold text-slate-800 block">Audio Assets Audit:</span>
              <div className="space-y-1">
                {audit.audioItems.map(a => (
                  <div key={a.id} className="flex items-center justify-between text-[11.5px] text-slate-700">
                    <span className="font-mono text-[#008C96]">{a.filename} ({a.id})</span>
                    <span>{a.transcriptWords} words · Synthesized & speech enabled</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Integrity status check */}
            <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-2xl text-xs text-emerald-900 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <span className="font-bold">Zero Duplicates & Zero Missing Answers Verified.</span>
                <div className="text-[11px] text-emerald-700">
                  Duplicate question IDs: {audit.duplicateQuestionIds.length} · Missing answers: {audit.missingAnswerQuestions.length}
                </div>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleExportCSV}
            className="w-full min-h-[44px] py-2.5 bg-[#172A2E] hover:bg-black text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export Full Teacher Content Audit (CSV)</span>
          </button>
        </div>
      )}

      {/* TAB 2: ITEM APPROVALS & VERSIONED CORRECTIONS */}
      {activeTab === 'approval' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={handleApproveAll}
              className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold"
            >
              Approve All 330 Questions for Student Release
            </button>
            <select
              value={selectedBankFilter}
              onChange={e => setSelectedBankFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-800"
            >
              <option value="ALL">All Banks (330)</option>
              {BANK_METADATA.map(b => (
                <option key={b.id} value={b.id}>Bank {b.id} ({b.name})</option>
              ))}
            </select>
          </div>

          {/* Edit Correction Modal / Form */}
          {editingQuestionId && (
            <div className="p-4 bg-amber-50 border-2 border-amber-300 rounded-2xl space-y-3 animate-in fade-in">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-amber-900 font-mono">
                  Record Teacher Correction for {editingQuestionId}
                </span>
                <button
                  type="button"
                  onClick={() => setEditingQuestionId(null)}
                  className="text-slate-500 hover:text-black"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveCorrection} className="space-y-2">
                <div>
                  <label htmlFor="corr-answer" className="block text-[11px] font-semibold text-slate-700">Corrected Answer Text:</label>
                  <input
                    id="corr-answer"
                    type="text"
                    value={correctionAnswer}
                    onChange={e => setCorrectionAnswer(e.target.value)}
                    className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label htmlFor="corr-rationale" className="block text-[11px] font-semibold text-slate-700">Correction Rationale & Version Note:</label>
                  <input
                    id="corr-rationale"
                    type="text"
                    value={correctionRationale}
                    onChange={e => setCorrectionRationale(e.target.value)}
                    placeholder="e.g. Grammar convention note or regional spelling alias"
                    className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div className="flex gap-2 pt-1">
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-amber-700 text-white rounded-lg text-xs font-semibold hover:bg-amber-800"
                  >
                    Save Correction Version
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingQuestionId(null)}
                    className="px-3 py-1.5 bg-slate-200 text-slate-700 rounded-lg text-xs"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Questions List */}
          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {filteredQuestions.map(q => {
              const isApproved = !!approvals[q.id];
              const correction = corrections[q.id];
              return (
                <div
                  key={q.id}
                  className="bg-white border border-slate-200 rounded-xl p-3 text-xs space-y-1.5 shadow-2xs"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 font-mono">{q.id}</span>
                        <span className="text-[10px] text-slate-400 font-mono">Bank {q.bankId} · {q.level}</span>
                        {correction && (
                          <span className="px-1.5 py-0.2 rounded bg-amber-100 text-amber-900 text-[10px] font-mono">
                            v{correction.version}
                          </span>
                        )}
                      </div>
                      <p className="text-slate-800 mt-1 font-medium">{q.prompt}</p>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleStartEdit(q.id, q.sourceAnswer)}
                        className="p-1 text-slate-500 hover:text-black rounded"
                        title="Record correction"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleToggleApproval(q.id)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors ${
                          isApproved ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {isApproved ? <Check className="w-3 h-3" /> : null}
                        <span>{isApproved ? 'Approved' : 'Pending'}</span>
                      </button>
                    </div>
                  </div>

                  <div className="text-[11.5px] text-slate-600 bg-slate-50 p-2 rounded-lg">
                    <span className="font-semibold text-slate-800">Source Answer: </span>
                    {correction ? (
                      <span>
                        <span className="line-through text-slate-400 mr-1">{q.sourceAnswer}</span>
                        <strong className="text-amber-800">{correction.correctedAnswer}</strong>
                      </span>
                    ) : (
                      <span>{q.sourceAnswer}</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: TEACHER REVIEW QUEUE */}
      {activeTab === 'reviews' && (
        <div className="space-y-3">
          <span className="text-xs font-semibold text-slate-700 block">
            Pending Open Responses ({pendingQueue.length})
          </span>

          {pendingQueue.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-3xl p-6 text-center text-xs text-slate-500">
              No open tasks currently awaiting instructor grading.
            </div>
          ) : (
            <div className="space-y-3">
              {pendingQueue.map(att => {
                const isSelected = activeReviewId === att.id;
                return (
                  <div
                    key={att.id}
                    className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-2"
                  >
                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span className="font-bold text-slate-900">{att.questionId || att.vocabularyId}</span>
                      <span>Student: {att.studentName}</span>
                    </div>

                    <div className="text-xs text-slate-800 bg-[#FFF9EC] p-3 rounded-xl border border-[#B8892D]/20">
                      <span className="text-[10px] text-slate-400 font-mono uppercase block mb-1">Submitted Response:</span>
                      <p className="font-medium">{att.submittedResponse}</p>
                    </div>

                    {!isSelected ? (
                      <button
                        type="button"
                        onClick={() => {
                          setActiveReviewId(att.id);
                          setRubricScore(5);
                          setRubricFeedback('');
                        }}
                        className="px-3.5 py-1.5 bg-[#B8892D] text-white rounded-xl text-xs font-semibold hover:bg-[#A37622]"
                      >
                        Grade with Rubric
                      </button>
                    ) : (
                      <div className="p-3 bg-slate-50 rounded-xl space-y-3 border border-slate-200 animate-in fade-in">
                        <div className="space-y-1">
                          <label htmlFor="rubric-score" className="block text-[11px] font-semibold text-slate-700">
                            Rubric Score (0 to 5 marks):
                          </label>
                          <div className="flex gap-2">
                            {[1, 2, 3, 4, 5].map(score => (
                              <button
                                key={score}
                                type="button"
                                onClick={() => setRubricScore(score)}
                                className={`w-9 h-9 rounded-lg font-bold text-xs ${
                                  rubricScore === score ? 'bg-[#008C96] text-white' : 'bg-white border text-slate-700'
                                }`}
                              >
                                {score}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div>
                          <label htmlFor="rubric-feedback" className="block text-[11px] font-semibold text-slate-700">
                            Teacher Feedback:
                          </label>
                          <textarea
                            id="rubric-feedback"
                            rows={2}
                            value={rubricFeedback}
                            onChange={e => setRubricFeedback(e.target.value)}
                            placeholder="Provide constructive feedback..."
                            className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                          />
                        </div>

                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => handleGradeAttempt(att.id)}
                            className="px-4 py-2 bg-emerald-700 text-white rounded-xl text-xs font-semibold hover:bg-emerald-800"
                          >
                            Save Score & Release to Student
                          </button>
                          <button
                            type="button"
                            onClick={() => setActiveReviewId(null)}
                            className="px-3 py-2 bg-slate-200 text-slate-700 rounded-xl text-xs"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: CAIRO REPORT DISPATCHER */}
      {activeTab === 'reports' && (
        <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-3xl p-5 shadow-sm space-y-4 animate-in fade-in">
          <div>
            <div className="flex items-center gap-1.5 text-[11px] font-mono text-[#B8892D] uppercase font-bold">
              <Mail className="w-3.5 h-3.5" />
              <span>Automated Report Dispatcher</span>
            </div>
            <h3 className="font-display font-bold text-base text-slate-900 mt-1">
              Destination: Kemetthenileflow@gmail.com
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              Scheduled daily/weekly progress summary calculated for Africa/Cairo timezone.
            </p>
          </div>

          <div className="space-y-3 bg-white p-4 rounded-2xl border border-slate-200 text-xs">
            <div>
              <label htmlFor="rep-email" className="block font-semibold text-slate-700 mb-0.5">Report Recipient Address:</label>
              <input
                id="rep-email"
                type="email"
                value={recipientEmail}
                onChange={e => setRecipientEmail(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div>
              <label htmlFor="rep-freq" className="block font-semibold text-slate-700 mb-0.5">Delivery Schedule:</label>
              <input
                id="rep-freq"
                type="text"
                value={scheduleFreq}
                onChange={e => setScheduleFreq(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-[11px] text-slate-600 space-y-1">
              <span className="font-semibold text-slate-800 block">Adapter Status: Not Configured (Truthful State)</span>
              <p>
                In accordance with system specifications, automatic live email delivery requires server-side configuration of an authorized Gmail OAuth token or transactional SMTP API key. No mock success is reported.
              </p>
            </div>

            <button
              type="button"
              onClick={handleTestReportJob}
              className="w-full min-h-[44px] py-2 bg-[#B8892D] hover:bg-[#A37622] text-white font-semibold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Assemble Cairo Report Payload</span>
            </button>
          </div>

          {dispatchMessage && (
            <div className="p-3 bg-blue-50 border border-blue-200 text-blue-900 rounded-xl text-xs">
              {dispatchMessage}
            </div>
          )}

          {/* Job History */}
          <div className="space-y-2 pt-2 border-t border-[#B8892D]/20">
            <span className="text-xs font-bold text-slate-800">Recent Job Queue:</span>
            {reportJobs.map(job => (
              <div key={job.id} className="p-2.5 bg-white rounded-xl border border-slate-200 text-xs space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-slate-900">{job.recipientEmail}</span>
                  <span className="font-mono text-slate-500">{job.status}</span>
                </div>
                <div className="text-[11px] text-slate-600">
                  Timezone: {job.timezone} · Participants: {job.learnerCount} · Accuracy: {job.objectiveNumerator}/{job.objectiveDenominator}
                </div>
                <p className="text-[10px] text-slate-400 italic">{job.lastProviderResponse}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
