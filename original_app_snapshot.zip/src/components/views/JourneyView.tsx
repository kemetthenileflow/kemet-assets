import React, { useState } from 'react';
import { Layers, CheckCircle2, Clock, AlertCircle, ArrowRight, Play, BookOpen } from 'lucide-react';
import { UNIT_1_VOCABULARY } from '../../data/vocabulary';
import { BANK_METADATA } from '../../data/questions';
import { getWordProgress, getStoredAttempts } from '../../services/storage';
import { WordRecallStatus } from '../../types';

interface JourneyViewProps {
  onStartActivity: (mode: string, params?: any) => void;
}

export const JourneyView: React.FC<JourneyViewProps> = ({ onStartActivity }) => {
  const [selectedTab, setSelectedTab] = useState<'vocabulary' | 'banks' | 'revision'>('vocabulary');
  const wordProgress = getWordProgress();
  const attempts = getStoredAttempts();

  // Status tallies
  let newCount = 0;
  let practisingCount = 0;
  let confirmedCount = 0;
  let reviewDueCount = 0;

  UNIT_1_VOCABULARY.forEach(v => {
    const prog = wordProgress[v.id];
    const status: WordRecallStatus = prog ? prog.status : 'New';
    if (status === 'New') newCount++;
    else if (status === 'Practising') practisingCount++;
    else if (status === 'Recall confirmed') confirmedCount++;
    else if (status === 'Review due') reviewDueCount++;
  });

  // Calculate question completion by bank
  const completedBankCounts: Record<string, number> = {};
  attempts.forEach(a => {
    if (a.questionId) {
      const bank = a.questionId.split('-')[0];
      completedBankCounts[bank] = (completedBankCounts[bank] || 0) + 1;
    }
  });

  // Revision items (attempts with incorrect outcome or words needing review)
  const incorrectAttempts = attempts.filter(a => a.objectiveOutcome === 'incorrect');

  return (
    <div className="space-y-4 pb-8 animate-in fade-in duration-200">
      {/* View Title */}
      <div>
        <h2 className="font-display text-xl font-bold text-[#172A2E]">Learning Journey</h2>
        <p className="text-xs text-slate-600">
          Restore the library through progressive retrieval cycles.
        </p>
      </div>

      {/* Mode Tabs */}
      <div className="flex bg-[#E8E1CE] p-1 rounded-2xl text-xs font-semibold">
        <button
          type="button"
          onClick={() => setSelectedTab('vocabulary')}
          className={`flex-1 py-2 rounded-xl transition-colors ${
            selectedTab === 'vocabulary' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          11 Word Groups
        </button>
        <button
          type="button"
          onClick={() => setSelectedTab('banks')}
          className={`flex-1 py-2 rounded-xl transition-colors ${
            selectedTab === 'banks' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          11 Question Banks
        </button>
        <button
          type="button"
          onClick={() => setSelectedTab('revision')}
          className={`flex-1 py-2 rounded-xl transition-colors ${
            selectedTab === 'revision' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Revision Queue ({incorrectAttempts.length})
        </button>
      </div>

      {/* TAB 1: 11 WORD GROUPS (6 words each) */}
      {selectedTab === 'vocabulary' && (
        <div className="space-y-4">
          {/* Status Metric Strip */}
          <div className="grid grid-cols-4 gap-2 bg-[#FFF9EC] p-3 rounded-2xl border border-[#B8892D]/30 text-center">
            <div>
              <div className="text-xs font-bold text-slate-800 tabular-nums">{newCount}</div>
              <div className="text-[10px] text-slate-500">New</div>
            </div>
            <div>
              <div className="text-xs font-bold text-amber-700 tabular-nums">{practisingCount}</div>
              <div className="text-[10px] text-slate-500">Practising</div>
            </div>
            <div>
              <div className="text-xs font-bold text-emerald-700 tabular-nums">{confirmedCount}</div>
              <div className="text-[10px] text-slate-500">Confirmed</div>
            </div>
            <div>
              <div className="text-xs font-bold text-blue-700 tabular-nums">{reviewDueCount}</div>
              <div className="text-[10px] text-slate-500">Due Review</div>
            </div>
          </div>

          {/* 11 Groups List */}
          <div className="space-y-2.5">
            {Array.from({ length: 11 }).map((_, gIdx) => {
              const groupWords = UNIT_1_VOCABULARY.slice(gIdx * 6, (gIdx + 1) * 6);
              const confirmedInGroup = groupWords.filter(w => wordProgress[w.id]?.status === 'Recall confirmed').length;

              return (
                <div
                  key={gIdx}
                  className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-2.5 hover:border-[#B8892D]/50 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-mono text-[#B8892D] uppercase tracking-wide">
                        Group {gIdx + 1} of 11
                      </span>
                      <h4 className="text-sm font-bold text-slate-900">
                        Words {gIdx * 6 + 1}–{(gIdx + 1) * 6}
                      </h4>
                    </div>
                    <span className="text-xs text-slate-500 font-medium tabular-nums">
                      {confirmedInGroup}/6 Confirmed
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {groupWords.map(w => {
                      const st = wordProgress[w.id]?.status || 'New';
                      let badge = 'bg-slate-100 text-slate-700';
                      if (st === 'Recall confirmed') badge = 'bg-emerald-100 text-emerald-800 font-semibold';
                      else if (st === 'Practising') badge = 'bg-amber-100 text-amber-800';
                      return (
                        <span key={w.id} className={`px-2 py-0.5 rounded-md text-[11px] ${badge}`}>
                          {w.word}
                        </span>
                      );
                    })}
                  </div>

                  <div className="flex gap-2 pt-1 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => onStartActivity('nile-memory', { groupIndex: gIdx })}
                      className="flex-1 min-h-[38px] py-1.5 px-3 bg-[#FFF9EC] border border-[#B8892D]/40 text-[#B8892D] rounded-xl text-xs font-semibold hover:bg-[#B8892D] hover:text-white transition-colors flex items-center justify-center gap-1.5"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Learn & Recall</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onStartActivity('lost-inscription', { groupIndex: gIdx })}
                      className="flex-1 min-h-[38px] py-1.5 px-3 bg-[#E8F4F5] border border-[#008C96]/40 text-[#008C96] rounded-xl text-xs font-semibold hover:bg-[#008C96] hover:text-white transition-colors flex items-center justify-center gap-1.5"
                    >
                      <span>Spelling Recall</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: 11 QUESTION BANKS */}
      {selectedTab === 'banks' && (
        <div className="space-y-2.5">
          {BANK_METADATA.map(bank => {
            const completed = completedBankCounts[bank.id] || 0;
            return (
              <div
                key={bank.id}
                className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-2 hover:border-[#008C96]/50 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono text-[#008C96] font-bold uppercase">
                      Bank {bank.id}
                    </span>
                    <h4 className="text-sm font-bold text-slate-900">{bank.name}</h4>
                    <p className="text-xs text-slate-600 mt-0.5">{bank.description}</p>
                  </div>
                  <span className="text-xs font-mono font-semibold text-slate-600 tabular-nums">
                    {completed}/{bank.count}
                  </span>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      if (bank.id === 'S1') onStartActivity('evidence-explorer', { bankId: 'S1' });
                      else if (bank.id === 'L1') onStartActivity('echoes-nile', { bankId: 'L1' });
                      else if (bank.id === 'N1') onStartActivity('story-quest', { bankId: 'N1' });
                      else onStartActivity('pyramid-builder', { bankId: bank.id });
                    }}
                    className="w-full min-h-[40px] py-2 bg-[#172A2E] hover:bg-black text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors"
                  >
                    <span>Launch Bank {bank.id}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 3: REVISION QUEUE */}
      {selectedTab === 'revision' && (
        <div className="space-y-3">
          {incorrectAttempts.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-3xl p-6 text-center space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
              <h4 className="font-bold text-slate-800 text-sm">Revision Queue Clear</h4>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                No incorrect objective attempts recorded yet. Items will populate here when errors occur.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-700 block">
                Items Needing Review:
              </span>
              {incorrectAttempts.slice(-10).map((att, i) => (
                <div
                  key={i}
                  className="bg-white border border-amber-200 rounded-xl p-3 text-xs space-y-1"
                >
                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-500">
                    <span className="font-bold text-amber-800">{att.questionId || att.vocabularyId}</span>
                    <span>{att.gameMode}</span>
                  </div>
                  <div className="text-slate-800">
                    Submitted: <span className="font-semibold text-red-700">"{att.submittedResponse}"</span>
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Submitted on: {new Date(att.submittedAt).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
