import React, { useState } from 'react';
import { BookOpen, Scroll, Headphones, PenTool, Layers, Compass, ChevronDown, ChevronUp, Volume2 } from 'lucide-react';
import { UNIT_1_VOCABULARY } from '../../data/vocabulary';
import { STORY_VOCABULARY_59 } from '../../data/storyLexicon';
import { READING_PASSAGES, GRAMMAR_REFERENCES, SHARED_TASKS } from '../../data/references';
import { AUDIO_ITEMS } from '../../data/audio';
import { AudioPlayer } from '../AudioPlayer';

interface LibraryViewProps {
  initialCategory?: 'reading' | 'grammar' | 'listening' | 'writing' | 'vocab' | 'story';
}

export const LibraryView: React.FC<LibraryViewProps> = ({ initialCategory = 'vocab' }) => {
  const [activeCategory, setActiveCategory] = useState<'vocab' | 'reading' | 'grammar' | 'listening' | 'writing' | 'story'>(initialCategory);
  const [expandedGrammarId, setExpandedGrammarId] = useState<string | null>('GRAM-42');
  const [vocabFilter, setVocabFilter] = useState<'unit1' | 'story59'>('unit1');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredUnit1 = UNIT_1_VOCABULARY.filter(v =>
    v.word.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.englishMeaning.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.arabicMeaning.includes(searchTerm)
  );

  const filteredStory = STORY_VOCABULARY_59.filter(v =>
    v.word.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.meaning.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const speakWord = (word: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(word);
      u.lang = 'en-US';
      window.speechSynthesis.speak(u);
    }
  };

  return (
    <div className="space-y-4 pb-8 animate-in fade-in duration-200">
      <div>
        <h2 className="font-display text-xl font-bold text-[#172A2E]">Alexandrian Library</h2>
        <p className="text-xs text-slate-600">
          Curated primary materials for Unit 1 and The Lost World Chapter 1.
        </p>
      </div>

      {/* Category Pills / Segmented Selector */}
      <div className="flex bg-[#E8E1CE] p-1 rounded-2xl text-xs font-semibold overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveCategory('vocab')}
          className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
            activeCategory === 'vocab' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Vocabulary ({vocabFilter === 'unit1' ? '66 Unit 1' : '59 Story'})
        </button>
        <button
          type="button"
          onClick={() => setActiveCategory('reading')}
          className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
            activeCategory === 'reading' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Reading (6 Passages)
        </button>
        <button
          type="button"
          onClick={() => setActiveCategory('grammar')}
          className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
            activeCategory === 'grammar' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Grammar (12 Guides)
        </button>
        <button
          type="button"
          onClick={() => setActiveCategory('listening')}
          className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
            activeCategory === 'listening' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Listening Lab (2 Recs)
        </button>
        <button
          type="button"
          onClick={() => setActiveCategory('writing')}
          className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
            activeCategory === 'writing' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Writing & Reflection
        </button>
        <button
          type="button"
          onClick={() => setActiveCategory('story')}
          className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
            activeCategory === 'story' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Story Chapter 1
        </button>
      </div>

      {/* CATEGORY 1: VOCABULARY */}
      {activeCategory === 'vocab' && (
        <div className="space-y-3">
          {/* Sub-toggle between Unit 1 and Story Lexicon */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex bg-white border border-slate-200 p-0.5 rounded-xl text-xs font-medium">
              <button
                type="button"
                onClick={() => setVocabFilter('unit1')}
                className={`px-3 py-1 rounded-lg ${
                  vocabFilter === 'unit1' ? 'bg-[#B8892D] text-white' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Unit 1 Words (66)
              </button>
              <button
                type="button"
                onClick={() => setVocabFilter('story59')}
                className={`px-3 py-1 rounded-lg ${
                  vocabFilter === 'story59' ? 'bg-[#008C96] text-white' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Supplemental Story Lexicon (59)
              </button>
            </div>
            <input
              type="text"
              placeholder="Search words..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="px-3 py-1 bg-white border border-slate-300 rounded-xl text-xs w-36 focus:outline-none focus:border-[#B8892D]"
            />
          </div>

          {vocabFilter === 'story59' && (
            <div className="p-2.5 bg-blue-50 border border-blue-200 text-blue-900 rounded-xl text-[11px]">
              Note: This 59-word story lexicon is a separate supplemental glossary from The Lost World Chapter 1, never merged into the 66 Unit 1 words.
            </div>
          )}

          {/* Cards List */}
          <div className="space-y-2">
            {vocabFilter === 'unit1' ? (
              filteredUnit1.map(v => (
                <div
                  key={v.id}
                  className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-1.5 hover:border-[#B8892D]/40 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-base font-bold text-slate-900">{v.word}</h4>
                        <button
                          type="button"
                          onClick={() => speakWord(v.word)}
                          className="p-1 rounded-full text-[#B8892D] hover:bg-[#FFF9EC]"
                          title="Pronounce"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>
                        <span className="text-[11px] text-slate-500 font-mono">{v.ipa}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono uppercase">{v.id} · {v.partOfSpeech}</span>
                    </div>
                    <span className="font-arabic text-sm text-[#008C96] font-semibold text-right dir-rtl">
                      {v.arabicMeaning}
                    </span>
                  </div>

                  <p className="text-xs text-slate-700 leading-snug">
                    <span className="font-semibold text-slate-900">Definition: </span>{v.englishMeaning}
                  </p>

                  <p className="text-xs text-slate-600 italic bg-[#FFF9EC]/60 p-2 rounded-lg border border-[#B8892D]/20">
                    "{v.example}"
                  </p>

                  <div className="flex items-center gap-3 text-[11px] text-slate-500 pt-1">
                    <span>Synonym: {v.synonym}</span>
                    <span>·</span>
                    <span>Contrast: {v.antonymContrast}</span>
                  </div>
                </div>
              ))
            ) : (
              filteredStory.map(v => (
                <div
                  key={v.id}
                  className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <h4 className="text-base font-bold text-slate-900">{v.word}</h4>
                      <button
                        type="button"
                        onClick={() => speakWord(v.word)}
                        className="p-1 rounded-full text-[#008C96] hover:bg-[#E8F4F5]"
                        title="Pronounce"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">Page {v.sourcePdfPage}</span>
                  </div>
                  <p className="text-xs text-slate-700">{v.meaning}</p>
                  <p className="text-xs text-slate-500 italic">Context: "{v.storyContext}"</p>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* CATEGORY 2: READING PASSAGES */}
      {activeCategory === 'reading' && (
        <div className="space-y-4">
          <div className="p-2.5 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl text-[11px]">
            Academic Notice: Research findings and statistics are claims reported in the supplied passages; referring to them does not independently confirm scientific or medical guidelines.
          </div>

          <div className="space-y-3">
            {READING_PASSAGES.filter(p => p.cluster !== 'STORY').map(passage => (
              <div
                key={passage.id}
                className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-2.5"
              >
                <div className="flex items-center justify-between border-b pb-2">
                  <span className="text-[11px] font-mono font-bold text-[#008C96]">
                    Passage {passage.id}
                  </span>
                  <span className="text-xs font-semibold text-slate-500">
                    Cluster {passage.cluster}
                  </span>
                </div>
                <h3 className="font-display font-bold text-base text-slate-900">
                  {passage.title}
                </h3>
                <div className="space-y-2 text-xs text-slate-700 leading-relaxed">
                  {passage.paragraphs.map((p, i) => (
                    <p key={i}>{p}</p>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* CATEGORY 3: GRAMMAR REFERENCES (GRAM-42 to GRAM-53) */}
      {activeCategory === 'grammar' && (
        <div className="space-y-3">
          {GRAMMAR_REFERENCES.map(ref => {
            const isExpanded = expandedGrammarId === ref.id;
            return (
              <div
                key={ref.id}
                className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-2 transition-all"
              >
                <button
                  type="button"
                  onClick={() => setExpandedGrammarId(isExpanded ? null : ref.id)}
                  className="w-full text-left flex items-start justify-between gap-2"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono font-bold text-[#B8892D]">
                        {ref.id}
                      </span>
                      <span className="text-[11px] text-slate-500">· {ref.category}</span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 mt-0.5">{ref.title}</h4>
                  </div>
                  {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-500 shrink-0" /> : <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />}
                </button>

                {isExpanded && (
                  <div className="pt-2 border-t border-slate-100 space-y-3 text-xs leading-relaxed animate-in fade-in">
                    <div className="space-y-1.5">
                      <span className="font-semibold text-slate-800 block text-[11px] uppercase tracking-wider">
                        English Structural Rules:
                      </span>
                      {ref.englishRules.map((rule, idx) => (
                        <p key={idx} className="text-slate-700">{rule}</p>
                      ))}
                    </div>

                    <div className="bg-[#FFF9EC] p-3 rounded-xl border border-[#B8892D]/20 space-y-1 text-right dir-rtl font-arabic">
                      <span className="font-sans text-[10px] text-slate-400 block mb-0.5">شرح وتوجيهات تربوية:</span>
                      {ref.arabicRules.map((ar, idx) => (
                        <p key={idx} className="text-emerald-950 text-xs">{ar}</p>
                      ))}
                    </div>

                    <div className="space-y-1">
                      <span className="font-semibold text-slate-800 block text-[11px]">Worked Models:</span>
                      {ref.examples.map((ex, idx) => (
                        <div key={idx} className="bg-slate-50 p-2 rounded-lg text-slate-800 text-xs">
                          <strong>"{ex.en}"</strong>
                          {ex.note && <span className="text-slate-500 block text-[11px] mt-0.5">{ex.note}</span>}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* CATEGORY 4: LISTENING LAB */}
      {activeCategory === 'listening' && (
        <div className="space-y-4">
          <p className="text-xs text-slate-600">
            Listen to authentic audio recordings. Use 0.8x or 1.0x speed, replay, and view transcripts as support.
          </p>
          {AUDIO_ITEMS.map(audio => (
            <AudioPlayer key={audio.id} audio={audio} />
          ))}
        </div>
      )}

      {/* CATEGORY 5: WRITING & REFLECTION */}
      {activeCategory === 'writing' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-3">
            <span className="text-[11px] font-mono font-bold text-[#B8892D] uppercase">
              Extended Writing Reference
            </span>
            <h3 className="font-display font-bold text-base text-slate-900">
              {SHARED_TASKS.writingPrompt}
            </h3>
            <div className="text-xs text-slate-600 space-y-1">
              <span className="font-semibold">Target word count:</span> {SHARED_TASKS.writingTargetWords}
              <ul className="list-disc list-inside space-y-0.5 text-[11.5px] pt-1">
                {SHARED_TASKS.writingRequirements.map((r, i) => (
                  <li key={i}>{r}</li>
                ))}
              </ul>
            </div>
            <div className="mt-2 pt-2 border-t border-slate-100">
              <span className="text-xs font-bold text-slate-800 block mb-1">Model Paragraph:</span>
              <p className="text-xs text-slate-700 italic bg-[#FFF9EC] p-3 rounded-xl border border-[#B8892D]/20 leading-relaxed">
                "{SHARED_TASKS.modelParagraph}"
              </p>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY 6: STORY CHAPTER 1 */}
      {activeCategory === 'story' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-3">
            <span className="text-[11px] font-mono font-bold text-[#B8892D] uppercase">
              The Lost World · Chapter 1 (Arthur Conan Doyle)
            </span>
            <h3 className="font-display font-bold text-lg text-slate-900">
              Chapter 1 Complete Synopsis
            </h3>
            <div className="space-y-2 text-xs text-slate-700 leading-relaxed">
              {READING_PASSAGES.find(p => p.id === 'STORY-CH1')?.paragraphs.map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </div>
            <div className="p-3 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl text-xs font-semibold">
              Crucial Chapter Boundary: Chapter 1 ends as Malone enters the study and faces Challenger. The later fight and dinosaur details belong to later chapters and must not be used.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
