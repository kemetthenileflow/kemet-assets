import React from 'react';
import { Download, Award, AlertCircle, CheckCircle2, Clock, HelpCircle, HardDrive } from 'lucide-react';
import { getStoredAttempts, getWordProgress, exportAttemptsToCSV } from '../../services/storage';
import { UNIT_1_VOCABULARY } from '../../data/vocabulary';

export const ResultsView: React.FC = () => {
  const attempts = getStoredAttempts();
  const wordProgress = getWordProgress();

  // First-attempt objective accuracy calculation
  // Strictly filter: isFirstAttempt === true AND objectiveOutcome is 'correct' or 'incorrect' (pending excluded!)
  const firstObjectiveAttempts = attempts.filter(
    a => a.isFirstAttempt && (a.objectiveOutcome === 'correct' || a.objectiveOutcome === 'incorrect')
  );

  const objectiveNumerator = firstObjectiveAttempts.filter(a => a.objectiveOutcome === 'correct').length;
  const objectiveDenominator = firstObjectiveAttempts.length;
  const objectiveAccuracyPct = objectiveDenominator > 0
    ? Math.round((objectiveNumerator / objectiveDenominator) * 100)
    : null;

  // Assisted retry count
  const assistedAttempts = attempts.filter(a => a.revealUsed || a.hintCount > 0 || a.transcriptUsed);

  // Pending teacher reviews count
  const pendingReviews = attempts.filter(a => a.teacherReviewStatus === 'pending');

  // Graded reviews count and average
  const gradedReviews = attempts.filter(a => a.teacherReviewStatus === 'reviewed' && a.teacherRubricScore !== undefined);
  const avgRubricScore = gradedReviews.length > 0
    ? (gradedReviews.reduce((sum, a) => sum + (a.teacherRubricScore || 0), 0) / gradedReviews.length).toFixed(1)
    : null;

  // Vocabulary stats
  const wordsPractised = Object.keys(wordProgress).length;
  const confirmedMastery = Object.values(wordProgress).filter(p => p.status === 'Recall confirmed').length;

  const handleDownloadCSV = () => {
    const csvData = exportAttemptsToCSV(attempts);
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `kemet_my_learning_results_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 pb-8 animate-in fade-in duration-200">
      <div>
        <h2 className="font-display text-xl font-bold text-[#172A2E]">Learning Records & Diagnostics</h2>
        <p className="text-xs text-slate-600">
          Unblended metrics strictly separating objective accuracy from open teacher rubrics.
        </p>
      </div>

      {/* Prominent Local Device Sync Notice */}
      <div className="bg-[#FFF9EC] border-2 border-[#B8892D]/40 rounded-2xl p-3.5 text-xs text-slate-800 space-y-1">
        <div className="flex items-center gap-2 font-bold text-[#B8892D]">
          <HardDrive className="w-4 h-4 text-[#B8892D] shrink-0" />
          <span>Local Device Storage Notice</span>
        </div>
        <p className="text-[11.5px] text-slate-600 leading-relaxed">
          Results are stored on this device and not yet synced to a live cloud database.
          No generative AI or third-party tracking is active.
        </p>
      </div>

      {/* Separate Metrics Grid */}
      <div className="grid grid-cols-2 gap-3">
        {/* Metric 1: Objective First-Attempt Accuracy */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-1">
          <span className="text-[10.5px] font-mono text-[#008C96] uppercase font-bold block">
            Objective Accuracy
          </span>
          <div className="text-2xl font-bold text-slate-900 tabular-nums">
            {objectiveAccuracyPct !== null ? `${objectiveAccuracyPct}%` : 'No data'}
          </div>
          <div className="text-[11px] text-slate-500">
            {objectiveNumerator} correct / {objectiveDenominator} first attempts
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            *Excludes pending open evaluations
          </div>
        </div>

        {/* Metric 2: Vocabulary Retrieval */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-1">
          <span className="text-[10.5px] font-mono text-[#B8892D] uppercase font-bold block">
            Vocabulary Mastery
          </span>
          <div className="text-2xl font-bold text-slate-900 tabular-nums">
            {confirmedMastery} / 66
          </div>
          <div className="text-[11px] text-slate-500">
            {wordsPractised} words touched across sessions
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            *Confirmed by unassisted typing
          </div>
        </div>

        {/* Metric 3: Pending Teacher Review */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-1">
          <span className="text-[10.5px] font-mono text-amber-700 uppercase font-bold block">
            Pending Teacher Review
          </span>
          <div className="text-2xl font-bold text-slate-900 tabular-nums">
            {pendingReviews.length}
          </div>
          <div className="text-[11px] text-slate-500">
            Open responses in review queue
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            *Evaluated against rubrics
          </div>
        </div>

        {/* Metric 4: Assisted Retries */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-1">
          <span className="text-[10.5px] font-mono text-purple-700 uppercase font-bold block">
            Scaffolded Practice
          </span>
          <div className="text-2xl font-bold text-slate-900 tabular-nums">
            {assistedAttempts.length}
          </div>
          <div className="text-[11px] text-slate-500">
            Used hints or transcript reveals
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            *Support tracked, not penalized
          </div>
        </div>
      </div>

      {/* Export Button */}
      <button
        type="button"
        onClick={handleDownloadCSV}
        disabled={attempts.length === 0}
        className="w-full min-h-[46px] py-2.5 px-4 bg-[#172A2E] hover:bg-black disabled:opacity-50 text-white rounded-2xl font-semibold text-xs shadow-xs flex items-center justify-center gap-2 transition-colors"
      >
        <Download className="w-4 h-4" />
        <span>Download My Learning Log (Protected CSV)</span>
      </button>

      {/* Recent Attempts History List */}
      <div className="space-y-2 pt-2">
        <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
          Recent Attempt Stream
        </h3>

        {attempts.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-6 text-center text-xs text-slate-500">
            No attempts yet. Launch an activity from Home or Journey to start recording progress.
          </div>
        ) : (
          <div className="space-y-2">
            {attempts.slice(-8).reverse().map(att => (
              <div
                key={att.id}
                className="bg-white border border-slate-200 rounded-xl p-3 text-xs space-y-1 shadow-2xs"
              >
                <div className="flex items-center justify-between text-[11px] text-slate-500">
                  <span className="font-bold text-slate-900 font-mono">
                    {att.questionId || att.vocabularyId} · {att.gameMode}
                  </span>
                  <span className="font-mono">
                    {new Date(att.submittedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <div className="text-slate-800 text-[11.5px]">
                  Response: <span className="font-medium">"{att.submittedResponse}"</span>
                </div>
                <div className="flex items-center justify-between text-[10.5px] pt-0.5 border-t border-slate-100">
                  <span className={
                    att.objectiveOutcome === 'correct' ? 'text-emerald-700 font-semibold' :
                    att.objectiveOutcome === 'incorrect' ? 'text-red-700 font-semibold' :
                    'text-amber-700 font-semibold'
                  }>
                    {att.objectiveOutcome ? att.objectiveOutcome.toUpperCase() : 'OPEN TASK'}
                  </span>
                  <span className="text-slate-500">
                    {att.teacherReviewStatus === 'pending' ? 'Review Pending' :
                     att.teacherReviewStatus === 'reviewed' ? `Teacher Score: ${att.teacherRubricScore}/5` :
                     'Auto Graded'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
