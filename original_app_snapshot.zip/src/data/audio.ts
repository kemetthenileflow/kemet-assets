import { AudioItem } from '../types';

export const AUDIO_ITEMS: AudioItem[] = [
  {
    id: "REC-01",
    title: "Recording 1: Social Media & Identity Formation",
    filename: "recording_1.mp3",
    durationSeconds: 98,
    speaker: "Educational Narrator",
    disclaimer: "Supplied recording transcript labelled unverified alignment. Play on user action.",
    transcript: "Over the past decade, social media platforms have transformed from simple communication tools into carefully chosen stages where individuals perform carefully constructed versions of their lives. For teenagers, who are at a particularly sensitive stage of identity formation, this change carries significant psychological results. Research published by the American Psychological Association in 2023 found that teenagers who spent more than three hours daily on image-based platforms such as Instagram and TikTok were twice as likely to report symptoms of low self-esteem and body dissatisfaction compared to those who used social media for less than one hour per day. What makes social media especially powerful, and especially dangerous, is the mechanism of social comparison. Unlike traditional media, where the gap between ordinary people and celebrities is obvious, social media has hidden this gap completely. Teenagers are now comparing themselves not only to distant celebrities, but to classmates, acquaintances, and influencers who present their lives as easily perfect. Psychologists used the term highlight reel effect to describe this phenomenon. What appears online is a selective, filtered, and strategically timed part of reality, yet viewers instinctively treat it as a complete and accurate picture."
  },
  {
    id: "REC-04",
    title: "Recording 4: Nationwide School Health Survey in Egypt",
    filename: "recording_4.mp3",
    durationSeconds: 170,
    speaker: "Research Presenter",
    disclaimer: "Supplied recording transcript labelled unverified alignment. Play on user action.",
    transcript: "A nationwide school health survey done in Egypt in 2023 gathered data from 450 teenagers aged between 14 and 17, drawn from both urban and rural schools across five governorates. The study aimed to identify the primary sources of stress among teenagers and to examine the coping strategies they most commonly adopted. Its findings a complex picture of modern teenage life, in which academic pressure, digital habits, and social expectations interact in ways that are often difficult to separate. The most significant finding was that 68% of participants reported experiencing moderate to high levels of stress during examination periods. When asked to identify the main causes, students ranked academic pressure first, cited by 82% of respondents, followed by social media comparison (61%), insufficient sleep (57%), and family expectations (49%). Clearly, the study found that teenagers who did regular physical activity, defined as at least 30 minutes of exercise four or more times per week, reported stress levels that were, on average, 34% lower than those of their sedentary peers, even after controlling for academic performance variables. Cultural background also was a significant factor in how teenagers managed stress. Students from families with strong collectivist values were considerably more likely to seek emotional support from parents or siblings when facing difficulties. In contrast, students from more individualistic household environments tended to rely on individual coping strategies such as listening to music, exercising alone, or spending time in nature. Neither approach was found to be universally more effective; rather, the study suggested that the availability and quality of support networks were the decisive variables. The researchers also noted a significant gap in access to school counseling services between urban and rural institutions. While 74% of urban schools in the sample offered some form of counseling, the figure dropped to 31% in rural schools. The study concluded that targeted mental health support programs in schools could meaningfully reduce stress levels among teenagers."
  }
];
