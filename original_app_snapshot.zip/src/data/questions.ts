import { QuestionItem } from '../types';

export const ALL_330_QUESTIONS: QuestionItem[] = [
  // ==========================================
  // V1: Vocabulary in context (30 items)
  // ==========================================
  {
    id: "V1-01",
    bankId: "V1",
    level: "Foundation",
    prompt: "A period of ten years is a _____.",
    options: [
      { id: "A", text: "survey" },
      { id: "B", text: "decade" },
      { id: "C", text: "platform" },
      { id: "D", text: "symptom" }
    ],
    sourceAnswer: "B. decade",
    correctOptionId: "B",
    explanation: "A decade is ten years.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-02",
    bankId: "V1",
    level: "Foundation",
    prompt: "A website used to share posts is an online _____.",
    options: [
      { id: "A", text: "platform" },
      { id: "B", text: "barrier" },
      { id: "C", text: "sibling" },
      { id: "D", text: "diet" }
    ],
    sourceAnswer: "A. platform",
    correctOptionId: "A",
    explanation: "Platform names the digital service.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-03",
    bankId: "V1",
    level: "Foundation",
    prompt: "The village is in a _____ area, far from the city.",
    options: [
      { id: "A", text: "urban" },
      { id: "B", text: "digital" },
      { id: "C", text: "psychological" },
      { id: "D", text: "rural" }
    ],
    sourceAnswer: "D. rural",
    correctOptionId: "D",
    explanation: "Rural refers to the countryside.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-04",
    bankId: "V1",
    level: "Foundation",
    prompt: "Cairo is a large city with a busy _____ environment.",
    options: [
      { id: "A", text: "rural" },
      { id: "B", text: "sedentary" },
      { id: "C", text: "urban" },
      { id: "D", text: "selective" }
    ],
    sourceAnswer: "C. urban",
    correctOptionId: "C",
    explanation: "Urban refers to a city.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-05",
    bankId: "V1",
    level: "Foundation",
    prompt: "My sister is my _____.",
    options: [
      { id: "A", text: "influencer" },
      { id: "B", text: "sibling" },
      { id: "C", text: "nutritionist" },
      { id: "D", text: "acquaintance" }
    ],
    sourceAnswer: "B. sibling",
    correctOptionId: "B",
    explanation: "A sibling is a brother or sister.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-06",
    bankId: "V1",
    level: "Foundation",
    prompt: "A questionnaire can be used to carry out a _____.",
    options: [
      { id: "A", text: "survey" },
      { id: "B", text: "decade" },
      { id: "C", text: "symptom" },
      { id: "D", text: "barrier" }
    ],
    sourceAnswer: "A. survey",
    correctOptionId: "A",
    explanation: "A survey collects information from people.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-07",
    bankId: "V1",
    level: "Foundation",
    prompt: "A _____ lifestyle involves spending much time sitting.",
    options: [
      { id: "A", text: "active" },
      { id: "B", text: "balanced" },
      { id: "C", text: "physical" },
      { id: "D", text: "sedentary" }
    ],
    sourceAnswer: "D. sedentary",
    correctOptionId: "D",
    explanation: "Sedentary describes little movement.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-08",
    bankId: "V1",
    level: "Foundation",
    prompt: "After the long journey, she experienced extreme tiredness, or _____.",
    options: [
      { id: "A", text: "agency" },
      { id: "B", text: "identity" },
      { id: "C", text: "fatigue" },
      { id: "D", text: "resilience" }
    ],
    sourceAnswer: "C. fatigue",
    correctOptionId: "C",
    explanation: "Fatigue means great tiredness.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-09",
    bankId: "V1",
    level: "Foundation",
    prompt: "Your sense of who you are is your _____.",
    options: [
      { id: "A", text: "mechanism" },
      { id: "B", text: "identity" },
      { id: "C", text: "platform" },
      { id: "D", text: "nutrition" }
    ],
    sourceAnswer: "B. identity",
    correctOptionId: "B",
    explanation: "Identity concerns the self.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-10",
    bankId: "V1",
    level: "Foundation",
    prompt: "The opposite of accurate is _____.",
    options: [
      { id: "A", text: "inaccurate" },
      { id: "B", text: "active" },
      { id: "C", text: "adequate" },
      { id: "D", text: "obvious" }
    ],
    sourceAnswer: "A. inaccurate",
    correctOptionId: "A",
    explanation: "The prefix in- makes the opposite here.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-11",
    bankId: "V1",
    level: "Apply",
    prompt: "She believes she can complete the task; this belief is called _____.",
    options: [
      { id: "A", text: "self-esteem" },
      { id: "B", text: "social comparison" },
      { id: "C", text: "dissatisfaction" },
      { id: "D", text: "self-efficacy" }
    ],
    sourceAnswer: "D. self-efficacy",
    correctOptionId: "D",
    explanation: "Self-efficacy concerns ability to do a task.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-12",
    bankId: "V1",
    level: "Apply",
    prompt: "Feeling that you have value as a person is _____.",
    options: [
      { id: "A", text: "self-efficacy" },
      { id: "B", text: "a structural barrier" },
      { id: "C", text: "self-esteem" },
      { id: "D", text: "academic pressure" }
    ],
    sourceAnswer: "C. self-esteem",
    correctOptionId: "C",
    explanation: "Self-esteem concerns personal worth.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-13",
    bankId: "V1",
    level: "Apply",
    prompt: "Recovering and adapting after a setback shows _____.",
    options: [
      { id: "A", text: "fatigue" },
      { id: "B", text: "resilience" },
      { id: "C", text: "anonymity" },
      { id: "D", text: "dissatisfaction" }
    ],
    sourceAnswer: "B. resilience",
    correctOptionId: "B",
    explanation: "Resilience is recovery and adaptation.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-14",
    bankId: "V1",
    level: "Apply",
    prompt: "The ability to choose and act independently is _____.",
    options: [
      { id: "A", text: "agency" },
      { id: "B", text: "nutrition" },
      { id: "C", text: "pressure" },
      { id: "D", text: "counselling" }
    ],
    sourceAnswer: "A. agency",
    correctOptionId: "A",
    explanation: "Agency concerns the power to act.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-15",
    bankId: "V1",
    level: "Apply",
    prompt: "Carefully attending to the present moment is _____.",
    options: [
      { id: "A", text: "comparison" },
      { id: "B", text: "formation" },
      { id: "C", text: "advertising" },
      { id: "D", text: "mindfulness" }
    ],
    sourceAnswer: "D. mindfulness",
    correctOptionId: "D",
    explanation: "Mindfulness involves present attention.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-16",
    bankId: "V1",
    level: "Apply",
    prompt: "There were only two chairs for ten people: the seating was _____.",
    options: [
      { id: "A", text: "accurate" },
      { id: "B", text: "decisive" },
      { id: "C", text: "insufficient" },
      { id: "D", text: "nationwide" }
    ],
    sourceAnswer: "C. insufficient",
    correctOptionId: "C",
    explanation: "Insufficient means not enough.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-17",
    bankId: "V1",
    level: "Apply",
    prompt: "The programme was offered across the whole country; it was _____.",
    options: [
      { id: "A", text: "local" },
      { id: "B", text: "nationwide" },
      { id: "C", text: "rural" },
      { id: "D", text: "individualistic" }
    ],
    sourceAnswer: "B. nationwide",
    correctOptionId: "B",
    explanation: "Nationwide means across a country.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-18",
    bankId: "V1",
    level: "Apply",
    prompt: "The image was edited to hide imperfections; it was _____.",
    options: [
      { id: "A", text: "filtered" },
      { id: "B", text: "raw" },
      { id: "C", text: "untouched" },
      { id: "D", text: "unprocessed" }
    ],
    sourceAnswer: "A. filtered",
    correctOptionId: "A",
    explanation: "Filtered suits an edited image.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-19",
    bankId: "V1",
    level: "Apply",
    prompt: "The improvement can be counted and tracked; it is _____.",
    options: [
      { id: "A", text: "invisible" },
      { id: "B", text: "imaginary" },
      { id: "C", text: "unrecorded" },
      { id: "D", text: "measurable" }
    ],
    sourceAnswer: "D. measurable",
    correctOptionId: "D",
    explanation: "Measurable means capable of being measured.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-20",
    bankId: "V1",
    level: "Apply",
    prompt: "The service is aimed specifically at new students; it is _____.",
    options: [
      { id: "A", text: "random" },
      { id: "B", text: "unplanned" },
      { id: "C", text: "targeted" },
      { id: "D", text: "universal" }
    ],
    sourceAnswer: "C. targeted",
    correctOptionId: "C",
    explanation: "Targeted means directed at a specific group.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-21",
    bankId: "V1",
    level: "Challenge",
    prompt: "A park is unsafe and the nearest sports centre is unaffordable. These are _____.",
    options: [
      { id: "A", text: "personal identities" },
      { id: "B", text: "structural barriers" },
      { id: "C", text: "digital platforms" },
      { id: "D", text: "coping strategies" }
    ],
    sourceAnswer: "B. structural barriers",
    correctOptionId: "B",
    explanation: "The obstacles concern access and the environment.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-22",
    bankId: "V1",
    level: "Challenge",
    prompt: "A display makes fruit easier to notice but leaves all choices available. It is a _____.",
    options: [
      { id: "A", text: "nudge" },
      { id: "B", text: "ban" },
      { id: "C", text: "compulsion" },
      { id: "D", text: "punishment" }
    ],
    sourceAnswer: "A. nudge",
    correctOptionId: "A",
    explanation: "A nudge guides choice without removing options.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-23",
    bankId: "V1",
    level: "Challenge",
    prompt: "Calling every setback a personal failure can leave people feeling powerless, or _____.",
    options: [
      { id: "A", text: "empowered" },
      { id: "B", text: "confident" },
      { id: "C", text: "resilient" },
      { id: "D", text: "disempowered" }
    ],
    sourceAnswer: "D. disempowered",
    correctOptionId: "D",
    explanation: "Disempowered means having less perceived control.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-24",
    bankId: "V1",
    level: "Challenge",
    prompt: "The post shows only perfect moments and hides ordinary difficulties. This illustrates the _____.",
    options: [
      { id: "A", text: "placebo effect" },
      { id: "B", text: "balanced-diet principle" },
      { id: "C", text: "highlight-reel effect" },
      { id: "D", text: "weather cycle" }
    ],
    sourceAnswer: "C. highlight-reel effect",
    correctOptionId: "C",
    explanation: "Selective presentation can distort impressions.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-25",
    bankId: "V1",
    level: "Challenge",
    prompt: "The claim is stated as certain, with no exceptions. Its language is _____.",
    options: [
      { id: "A", text: "cautious" },
      { id: "B", text: "absolute" },
      { id: "C", text: "tentative" },
      { id: "D", text: "hedged" }
    ],
    sourceAnswer: "B. absolute",
    correctOptionId: "B",
    explanation: "Absolute wording includes always and everyone.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-26",
    bankId: "V1",
    level: "Challenge",
    prompt: "In 'The plan might help some students', might expresses _____.",
    options: [
      { id: "A", text: "possibility" },
      { id: "B", text: "certainty" },
      { id: "C", text: "obligation" },
      { id: "D", text: "possession" }
    ],
    sourceAnswer: "A. possibility",
    correctOptionId: "A",
    explanation: "Might hedges the claim.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-27",
    bankId: "V1",
    level: "Challenge",
    prompt: "Calling a routine 'amazing' expresses a judgment. Amazing is an _____ adjective.",
    options: [
      { id: "A", text: "possessive" },
      { id: "B", text: "demonstrative" },
      { id: "C", text: "interrogative" },
      { id: "D", text: "evaluative" }
    ],
    sourceAnswer: "D. evaluative",
    correctOptionId: "D",
    explanation: "An evaluative adjective signals an opinion.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-28",
    bankId: "V1",
    level: "Challenge",
    prompt: "The writer ignores evidence against her view. This suggests _____.",
    options: [
      { id: "A", text: "neutrality" },
      { id: "B", text: "balance" },
      { id: "C", text: "bias" },
      { id: "D", text: "impartiality" }
    ],
    sourceAnswer: "C. bias",
    correctOptionId: "C",
    explanation: "Bias can involve selective evidence.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-29",
    bankId: "V1",
    level: "Challenge",
    prompt: "The survey shows an association. Claiming that one factor definitely caused the other would _____ the evidence.",
    options: [
      { id: "A", text: "collect" },
      { id: "B", text: "overstate" },
      { id: "C", text: "record" },
      { id: "D", text: "quote" }
    ],
    sourceAnswer: "B. overstate",
    correctOptionId: "B",
    explanation: "Overstate means claim more than evidence supports.",
    grading: "deterministic_choice"
  },
  {
    id: "V1-30",
    bankId: "V1",
    level: "Challenge",
    prompt: "A student asks who collected the data and how. This shows critical _____.",
    options: [
      { id: "A", text: "evaluation" },
      { id: "B", text: "imitation" },
      { id: "C", text: "obedience" },
      { id: "D", text: "advertising" }
    ],
    sourceAnswer: "A. evaluation",
    correctOptionId: "A",
    explanation: "Evaluation examines the quality of evidence.",
    grading: "deterministic_choice"
  },

  // ==========================================
  // V2: Collocations, prepositions and word choice (30 items)
  // ==========================================
  {
    id: "V2-01",
    bankId: "V2",
    level: "Foundation",
    prompt: "We spend time _____ social media.",
    options: [
      { id: "A", text: "at" },
      { id: "B", text: "of" },
      { id: "C", text: "on" },
      { id: "D", text: "by" }
    ],
    sourceAnswer: "C. on",
    correctOptionId: "C",
    explanation: "Spend time on something.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-02",
    bankId: "V2",
    level: "Foundation",
    prompt: "You can rely _____ a trusted friend.",
    options: [
      { id: "A", text: "in" },
      { id: "B", text: "on" },
      { id: "C", text: "to" },
      { id: "D", text: "of" }
    ],
    sourceAnswer: "B. on",
    correctOptionId: "B",
    explanation: "Rely on.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-03",
    bankId: "V2",
    level: "Foundation",
    prompt: "She listened _____ the recording twice.",
    options: [
      { id: "A", text: "to" },
      { id: "B", text: "on" },
      { id: "C", text: "for" },
      { id: "D", text: "at" }
    ],
    sourceAnswer: "A. to",
    correctOptionId: "A",
    explanation: "Listen to.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-04",
    bankId: "V2",
    level: "Foundation",
    prompt: "We must learn to cope _____ pressure.",
    options: [
      { id: "A", text: "to" },
      { id: "B", text: "of" },
      { id: "C", text: "at" },
      { id: "D", text: "with" }
    ],
    sourceAnswer: "D. with",
    correctOptionId: "D",
    explanation: "Cope with.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-05",
    bankId: "V2",
    level: "Foundation",
    prompt: "The lesson focuses _____ well-being.",
    options: [
      { id: "A", text: "at" },
      { id: "B", text: "for" },
      { id: "C", text: "on" },
      { id: "D", text: "by" }
    ],
    sourceAnswer: "C. on",
    correctOptionId: "C",
    explanation: "Focus on.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-06",
    bankId: "V2",
    level: "Foundation",
    prompt: "The students participated _____ a discussion.",
    options: [
      { id: "A", text: "on" },
      { id: "B", text: "in" },
      { id: "C", text: "to" },
      { id: "D", text: "with" }
    ],
    sourceAnswer: "B. in",
    correctOptionId: "B",
    explanation: "Participate in.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-07",
    bankId: "V2",
    level: "Foundation",
    prompt: "They sought support _____ their family.",
    options: [
      { id: "A", text: "from" },
      { id: "B", text: "of" },
      { id: "C", text: "at" },
      { id: "D", text: "into" }
    ],
    sourceAnswer: "A. from",
    correctOptionId: "A",
    explanation: "Seek support from someone.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-08",
    bankId: "V2",
    level: "Foundation",
    prompt: "Every student needs access _____ the library.",
    options: [
      { id: "A", text: "on" },
      { id: "B", text: "with" },
      { id: "C", text: "from" },
      { id: "D", text: "to" }
    ],
    sourceAnswer: "D. to",
    correctOptionId: "D",
    explanation: "Access to.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-09",
    bankId: "V2",
    level: "Foundation",
    prompt: "The results were drawn _____ five schools.",
    options: [
      { id: "A", text: "on" },
      { id: "B", text: "at" },
      { id: "C", text: "from" },
      { id: "D", text: "by" }
    ],
    sourceAnswer: "C. from",
    correctOptionId: "C",
    explanation: "Drawn from identifies the source.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-10",
    bankId: "V2",
    level: "Foundation",
    prompt: "We met _____ to discuss the project.",
    options: [
      { id: "A", text: "face by face" },
      { id: "B", text: "face to face" },
      { id: "C", text: "face in face" },
      { id: "D", text: "face of face" }
    ],
    sourceAnswer: "B. face to face",
    correctOptionId: "B",
    explanation: "The fixed expression is face to face.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-11",
    bankId: "V2",
    level: "Apply",
    prompt: "The club helps students _____ realistic goals.",
    options: [
      { id: "A", text: "set" },
      { id: "B", text: "do" },
      { id: "C", text: "take" },
      { id: "D", text: "have made" }
    ],
    sourceAnswer: "A. set",
    correctOptionId: "A",
    explanation: "Set goals.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-12",
    bankId: "V2",
    level: "Apply",
    prompt: "The researcher will _____ data through interviews.",
    options: [
      { id: "A", text: "release" },
      { id: "B", text: "cope" },
      { id: "C", text: "adopt" },
      { id: "D", text: "gather" }
    ],
    sourceAnswer: "D. gather",
    correctOptionId: "D",
    explanation: "Gather or collect data.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-13",
    bankId: "V2",
    level: "Apply",
    prompt: "The class decided to _____ a new strategy.",
    options: [
      { id: "A", text: "gather" },
      { id: "B", text: "release" },
      { id: "C", text: "adopt" },
      { id: "D", text: "underestimate" }
    ],
    sourceAnswer: "C. adopt",
    correctOptionId: "C",
    explanation: "Adopt a strategy.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-14",
    bankId: "V2",
    level: "Apply",
    prompt: "Students may feel _____ pressure before exams.",
    options: [
      { id: "A", text: "below of" },
      { id: "B", text: "under" },
      { id: "C", text: "inside of" },
      { id: "D", text: "among" }
    ],
    sourceAnswer: "B. under",
    correctOptionId: "B",
    explanation: "Under pressure.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-15",
    bankId: "V2",
    level: "Apply",
    prompt: "We should _____ responsibility for our choices.",
    options: [
      { id: "A", text: "take" },
      { id: "B", text: "make" },
      { id: "C", text: "do" },
      { id: "D", text: "set" }
    ],
    sourceAnswer: "A. take",
    correctOptionId: "A",
    explanation: "Take responsibility.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-16",
    bankId: "V2",
    level: "Apply",
    prompt: "The new service could contribute _____ student well-being.",
    options: [
      { id: "A", text: "on" },
      { id: "B", text: "at" },
      { id: "C", text: "of" },
      { id: "D", text: "to" }
    ],
    sourceAnswer: "D. to",
    correctOptionId: "D",
    explanation: "Contribute to.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-17",
    bankId: "V2",
    level: "Apply",
    prompt: "The report links sleep patterns _____ concentration.",
    options: [
      { id: "A", text: "on" },
      { id: "B", text: "at" },
      { id: "C", text: "to" },
      { id: "D", text: "from" }
    ],
    sourceAnswer: "C. to",
    correctOptionId: "C",
    explanation: "Link something to something.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-18",
    bankId: "V2",
    level: "Apply",
    prompt: "The researchers controlled _____ age when comparing the groups.",
    options: [
      { id: "A", text: "at" },
      { id: "B", text: "for" },
      { id: "C", text: "of" },
      { id: "D", text: "to" }
    ],
    sourceAnswer: "B. for",
    correctOptionId: "B",
    explanation: "Control for a variable in analysis.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-19",
    bankId: "V2",
    level: "Apply",
    prompt: "The coach encouraged a _____ diet with a variety of foods.",
    options: [
      { id: "A", text: "balanced" },
      { id: "B", text: "balancing" },
      { id: "C", text: "balance" },
      { id: "D", text: "balances" }
    ],
    sourceAnswer: "A. balanced",
    correctOptionId: "A",
    explanation: "An adjective modifies diet.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-20",
    bankId: "V2",
    level: "Apply",
    prompt: "The difference was _____ enough to influence the decision.",
    options: [
      { id: "A", text: "significance" },
      { id: "B", text: "significantly" },
      { id: "C", text: "signify" },
      { id: "D", text: "significant" }
    ],
    sourceAnswer: "D. significant",
    correctOptionId: "D",
    explanation: "An adjective follows was here.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-21",
    bankId: "V2",
    level: "Challenge",
    prompt: "Which collocation is natural?",
    options: [
      { id: "A", text: "carry results" },
      { id: "B", text: "do consequences" },
      { id: "C", text: "have consequences" },
      { id: "D", text: "make effects" }
    ],
    sourceAnswer: "C. have consequences",
    correctOptionId: "C",
    explanation: "Have consequences is a natural phrase.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-22",
    bankId: "V2",
    level: "Challenge",
    prompt: "Choose the sentence that uses 'attribute' correctly.",
    options: [
      { id: "A", text: "They attribute to the change better access." },
      { id: "B", text: "They attribute the change to better access." },
      { id: "C", text: "They attribute the change on better access." },
      { id: "D", text: "They attribute better access for the change." }
    ],
    sourceAnswer: "B. They attribute the change to better access.",
    correctOptionId: "B",
    explanation: "Attribute an outcome to a cause.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-23",
    bankId: "V2",
    level: "Challenge",
    prompt: "The percentage fell from 70% to 50%. It fell _____ 20 percentage points.",
    options: [
      { id: "A", text: "by" },
      { id: "B", text: "to" },
      { id: "C", text: "at" },
      { id: "D", text: "in" }
    ],
    sourceAnswer: "A. by",
    correctOptionId: "A",
    explanation: "By gives the size of a change.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-24",
    bankId: "V2",
    level: "Challenge",
    prompt: "The percentage fell from 70% _____ 50%.",
    options: [
      { id: "A", text: "by" },
      { id: "B", text: "with" },
      { id: "C", text: "of" },
      { id: "D", text: "to" }
    ],
    sourceAnswer: "D. to",
    correctOptionId: "D",
    explanation: "To gives the final value.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-25",
    bankId: "V2",
    level: "Challenge",
    prompt: "The writer _____ between personal choice and social influence.",
    options: [
      { id: "A", text: "distinction" },
      { id: "B", text: "distinctive" },
      { id: "C", text: "distinguishes" },
      { id: "D", text: "distinctly" }
    ],
    sourceAnswer: "C. distinguishes",
    correctOptionId: "C",
    explanation: "Distinguish between two things.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-26",
    bankId: "V2",
    level: "Challenge",
    prompt: "Which sentence avoids an unsupported universal claim?",
    options: [
      { id: "A", text: "Family support always solves every problem." },
      { id: "B", text: "Family support may help some students." },
      { id: "C", text: "Family support never fails anyone." },
      { id: "D", text: "Every student needs exactly the same support." }
    ],
    sourceAnswer: "B. Family support may help some students.",
    correctOptionId: "B",
    explanation: "May and some limit the claim.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-27",
    bankId: "V2",
    level: "Challenge",
    prompt: "Which pair is a genuine opposite in this context: an accurate report?",
    options: [
      { id: "A", text: "accurate / inaccurate" },
      { id: "B", text: "symptom / cause" },
      { id: "C", text: "peer / adult" },
      { id: "D", text: "influencer / follower" }
    ],
    sourceAnswer: "A. accurate / inaccurate",
    correctOptionId: "A",
    explanation: "Related roles are not necessarily antonyms.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-28",
    bankId: "V2",
    level: "Challenge",
    prompt: "'Processed food' refers to food changed from its original state. Which conclusion is too broad?",
    options: [
      { id: "A", text: "Processing can include preservation." },
      { id: "B", text: "Food can be changed before sale." },
      { id: "C", text: "Different products can be processed differently." },
      { id: "D", text: "All processed food is unhealthy." }
    ],
    sourceAnswer: "D. All processed food is unhealthy.",
    correctOptionId: "D",
    explanation: "Processing alone does not justify a universal judgment.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-29",
    bankId: "V2",
    level: "Challenge",
    prompt: "Which sentence describes a collectivist value without stereotyping a whole country?",
    options: [
      { id: "A", text: "Every Egyptian has identical values." },
      { id: "B", text: "All Americans reject family support." },
      { id: "C", text: "This family gives priority to shared responsibilities." },
      { id: "D", text: "No individual values independence." }
    ],
    sourceAnswer: "C. This family gives priority to shared responsibilities.",
    correctOptionId: "C",
    explanation: "Describe the actual group rather than all citizens.",
    grading: "deterministic_choice"
  },
  {
    id: "V2-30",
    bankId: "V2",
    level: "Challenge",
    prompt: "Which sentence correctly separates an observation from an interpretation?",
    options: [
      { id: "A", text: "Less stress proves that one activity cures everyone." },
      { id: "B", text: "The sample reported less stress; the reason needs investigation." },
      { id: "C", text: "Every student will respond identically." },
      { id: "D", text: "A survey removes all possible bias." }
    ],
    sourceAnswer: "B. The sample reported less stress; the reason needs investigation.",
    correctOptionId: "B",
    explanation: "The first wording does not overclaim causation.",
    grading: "deterministic_choice"
  },

  // ==========================================
  // R1: Relative clauses: choose and understand (30 items)
  // ==========================================
  {
    id: "R1-01",
    bankId: "R1",
    level: "Foundation",
    prompt: "The teacher _____ leads our club is helpful.",
    options: [
      { id: "A", text: "which" },
      { id: "B", text: "who" },
      { id: "C", text: "whom" },
      { id: "D", text: "whose" }
    ],
    sourceAnswer: "B. who",
    correctOptionId: "B",
    explanation: "Who is the subject and refers to a person.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "R1-02",
    bankId: "R1",
    level: "Foundation",
    prompt: "The app _____ reminds me to take breaks is useful.",
    options: [
      { id: "A", text: "which" },
      { id: "B", text: "who" },
      { id: "C", text: "whom" },
      { id: "D", text: "whose" }
    ],
    sourceAnswer: "A. which",
    correctOptionId: "A",
    explanation: "Which is the subject and refers to a thing.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "R1-03",
    bankId: "R1",
    level: "Foundation",
    prompt: "I know a student _____ brother is a nurse.",
    options: [
      { id: "A", text: "who" },
      { id: "B", text: "whom" },
      { id: "C", text: "which" },
      { id: "D", text: "whose" }
    ],
    sourceAnswer: "D. whose",
    correctOptionId: "D",
    explanation: "Whose expresses possession and precedes a noun.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R1-04",
    bankId: "R1",
    level: "Foundation",
    prompt: "The counsellor _____ I met was patient.",
    options: [
      { id: "A", text: "whose" },
      { id: "B", text: "which" },
      { id: "C", text: "whom" },
      { id: "D", text: "where" }
    ],
    sourceAnswer: "C. whom",
    correctOptionId: "C",
    explanation: "Whom is a formal object pronoun for a person.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "R1-05",
    bankId: "R1",
    level: "Foundation",
    prompt: "This is the room _____ we hold discussions.",
    options: [
      { id: "A", text: "which" },
      { id: "B", text: "where" },
      { id: "C", text: "who" },
      { id: "D", text: "whose" }
    ],
    sourceAnswer: "B. where",
    correctOptionId: "B",
    explanation: "Where means in which here.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R1-06",
    bankId: "R1",
    level: "Foundation",
    prompt: "I remember the day _____ our club opened.",
    options: [
      { id: "A", text: "when" },
      { id: "B", text: "who" },
      { id: "C", text: "whose" },
      { id: "D", text: "where" }
    ],
    sourceAnswer: "A. when",
    correctOptionId: "A",
    explanation: "When refers to a time.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R1-07",
    bankId: "R1",
    level: "Foundation",
    prompt: "The reason _____ she left is unclear.",
    options: [
      { id: "A", text: "who" },
      { id: "B", text: "whose" },
      { id: "C", text: "where" },
      { id: "D", text: "why" }
    ],
    sourceAnswer: "D. why",
    correctOptionId: "D",
    explanation: "Why introduces a reason clause.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R1-08",
    bankId: "R1",
    level: "Foundation",
    prompt: "The students _____ are waiting may come in.",
    options: [
      { id: "A", text: "whom" },
      { id: "B", text: "whose" },
      { id: "C", text: "who" },
      { id: "D", text: "which" }
    ],
    sourceAnswer: "C. who",
    correctOptionId: "C",
    explanation: "The relative pronoun is the subject of are.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "R1-09",
    bankId: "R1",
    level: "Foundation",
    prompt: "The book _____ you recommended is useful.",
    options: [
      { id: "A", text: "where" },
      { id: "B", text: "that" },
      { id: "C", text: "whose" },
      { id: "D", text: "who" }
    ],
    sourceAnswer: "B. that",
    correctOptionId: "B",
    explanation: "That is the object of recommended.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "R1-10",
    bankId: "R1",
    level: "Foundation",
    prompt: "The girl _____ bag is blue is my cousin.",
    options: [
      { id: "A", text: "whose" },
      { id: "B", text: "whom" },
      { id: "C", text: "which" },
      { id: "D", text: "where" }
    ],
    sourceAnswer: "A. whose",
    correctOptionId: "A",
    explanation: "Whose + bag expresses ownership.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R1-11",
    bankId: "R1",
    level: "Apply",
    prompt: "Mona, _____ lives next door, joined the club.",
    options: [
      { id: "A", text: "that" },
      { id: "B", text: "whom" },
      { id: "C", text: "whose" },
      { id: "D", text: "who" }
    ],
    sourceAnswer: "D. who",
    correctOptionId: "D",
    explanation: "Use who in a non-defining clause about a person.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R1-12",
    bankId: "R1",
    level: "Apply",
    prompt: "Our library, _____ opened last year, is popular.",
    options: [
      { id: "A", text: "that" },
      { id: "B", text: "where" },
      { id: "C", text: "which" },
      { id: "D", text: "whose" }
    ],
    sourceAnswer: "C. which",
    correctOptionId: "C",
    explanation: "Which is the subject; that is not used after this comma.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R1-13",
    bankId: "R1",
    level: "Apply",
    prompt: "The library _____ we visited has new computers.",
    options: [
      { id: "A", text: "where" },
      { id: "B", text: "which" },
      { id: "C", text: "who" },
      { id: "D", text: "whose" }
    ],
    sourceAnswer: "B. which",
    correctOptionId: "B",
    explanation: "Visited needs an object, not a place adverb.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R1-14",
    bankId: "R1",
    level: "Apply",
    prompt: "The park _____ we exercise is near school.",
    options: [
      { id: "A", text: "where" },
      { id: "B", text: "which" },
      { id: "C", text: "whom" },
      { id: "D", text: "whose" }
    ],
    sourceAnswer: "A. where",
    correctOptionId: "A",
    explanation: "Exercise has no missing direct object; where gives the place.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R1-15",
    bankId: "R1",
    level: "Apply",
    prompt: "Choose the correct sentence.",
    options: [
      { id: "A", text: "The article I read it was useful." },
      { id: "B", text: "The article who I read was useful." },
      { id: "C", text: "The article where I read was useful." },
      { id: "D", text: "The article I read was useful." }
    ],
    sourceAnswer: "D. The article I read was useful.",
    correctOptionId: "D",
    explanation: "Do not repeat the object as it.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-44"
  },
  {
    id: "R1-16",
    bankId: "R1",
    level: "Apply",
    prompt: "In 'The student who won thanked us', who _____.",
    options: [
      { id: "A", text: "must be omitted" },
      { id: "B", text: "is an object" },
      { id: "C", text: "cannot be omitted" },
      { id: "D", text: "shows possession" }
    ],
    sourceAnswer: "C. cannot be omitted",
    correctOptionId: "C",
    explanation: "A subject relative pronoun cannot simply be dropped.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-44"
  },
  {
    id: "R1-17",
    bankId: "R1",
    level: "Apply",
    prompt: "In 'The book that I bought is new', that _____.",
    options: [
      { id: "A", text: "is the subject of bought" },
      { id: "B", text: "can be omitted" },
      { id: "C", text: "shows possession" },
      { id: "D", text: "introduces a non-defining clause" }
    ],
    sourceAnswer: "B. can be omitted",
    correctOptionId: "B",
    explanation: "It is an object in a defining clause.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-44"
  },
  {
    id: "R1-18",
    bankId: "R1",
    level: "Apply",
    prompt: "Choose the correctly punctuated sentence about the already identified Dr Ali.",
    options: [
      { id: "A", text: "Dr Ali, who teaches English, is here." },
      { id: "B", text: "Dr Ali, that teaches English, is here." },
      { id: "C", text: "Dr Ali, whom teaches English, is here." },
      { id: "D", text: "Dr Ali who, teaches English is here." }
    ],
    sourceAnswer: "A. Dr Ali, who teaches English, is here.",
    correctOptionId: "A",
    explanation: "Extra information needs two commas here.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R1-19",
    bankId: "R1",
    level: "Apply",
    prompt: "The only student who _____ the answer is Salma.",
    options: [
      { id: "A", text: "know" },
      { id: "B", text: "knowing" },
      { id: "C", text: "have known" },
      { id: "D", text: "knows" }
    ],
    sourceAnswer: "D. knows",
    correctOptionId: "D",
    explanation: "Who agrees with singular student.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R1-20",
    bankId: "R1",
    level: "Apply",
    prompt: "The students who _____ the answer can explain it.",
    options: [
      { id: "A", text: "knows" },
      { id: "B", text: "knowing" },
      { id: "C", text: "know" },
      { id: "D", text: "has known" }
    ],
    sourceAnswer: "C. know",
    correctOptionId: "C",
    explanation: "Who agrees with plural students.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R1-21",
    bankId: "R1",
    level: "Challenge",
    prompt: "The person to _____ I spoke was the librarian.",
    options: [
      { id: "A", text: "who" },
      { id: "B", text: "whom" },
      { id: "C", text: "that" },
      { id: "D", text: "whose" }
    ],
    sourceAnswer: "B. whom",
    correctOptionId: "B",
    explanation: "In formal fronted-preposition structures use whom for people.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R1-22",
    bankId: "R1",
    level: "Challenge",
    prompt: "The topic about _____ we spoke was well-being.",
    options: [
      { id: "A", text: "which" },
      { id: "B", text: "that" },
      { id: "C", text: "where" },
      { id: "D", text: "who" }
    ],
    sourceAnswer: "A. which",
    correctOptionId: "A",
    explanation: "Use preposition + which for things.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R1-23",
    bankId: "R1",
    level: "Challenge",
    prompt: "The friend _____ I study with is reliable.",
    options: [
      { id: "A", text: "whose" },
      { id: "B", text: "where" },
      { id: "C", text: "which" },
      { id: "D", text: "who" }
    ],
    sourceAnswer: "D. who",
    correctOptionId: "D",
    explanation: "Who is acceptable as an object in everyday English.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R1-24",
    bankId: "R1",
    level: "Challenge",
    prompt: "The school in _____ I study has a library.",
    options: [
      { id: "A", text: "where" },
      { id: "B", text: "that" },
      { id: "C", text: "which" },
      { id: "D", text: "who" }
    ],
    sourceAnswer: "C. which",
    correctOptionId: "C",
    explanation: "In which is equivalent to where here.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R1-25",
    bankId: "R1",
    level: "Challenge",
    prompt: "She missed the bus, _____ made her late.",
    options: [
      { id: "A", text: "that" },
      { id: "B", text: "which" },
      { id: "C", text: "what" },
      { id: "D", text: "who" }
    ],
    sourceAnswer: "B. which",
    correctOptionId: "B",
    explanation: "Which can refer to the whole preceding event.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-46"
  },
  {
    id: "R1-26",
    bankId: "R1",
    level: "Challenge",
    prompt: "I met three students, two of _____ were new.",
    options: [
      { id: "A", text: "whom" },
      { id: "B", text: "who" },
      { id: "C", text: "that" },
      { id: "D", text: "whose" }
    ],
    sourceAnswer: "A. whom",
    correctOptionId: "A",
    explanation: "Number + of whom refers to people.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-46"
  },
  {
    id: "R1-27",
    bankId: "R1",
    level: "Challenge",
    prompt: "She submitted four reports, all of _____ were clear.",
    options: [
      { id: "A", text: "that" },
      { id: "B", text: "what" },
      { id: "C", text: "where" },
      { id: "D", text: "which" }
    ],
    sourceAnswer: "D. which",
    correctOptionId: "D",
    explanation: "All of which refers to things.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-46"
  },
  {
    id: "R1-28",
    bankId: "R1",
    level: "Challenge",
    prompt: "The school _____ roof was repaired reopened today.",
    options: [
      { id: "A", text: "who" },
      { id: "B", text: "whom" },
      { id: "C", text: "whose" },
      { id: "D", text: "where" }
    ],
    sourceAnswer: "C. whose",
    correctOptionId: "C",
    explanation: "Whose can express possession for things and organisations.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R1-29",
    bankId: "R1",
    level: "Challenge",
    prompt: "Which sentence is grammatical?",
    options: [
      { id: "A", text: "The chair on that I sat was broken." },
      { id: "B", text: "The chair on which I sat was broken." },
      { id: "C", text: "The chair which I sat on it was broken." },
      { id: "D", text: "The chair where I sat on was broken." }
    ],
    sourceAnswer: "B. The chair on which I sat was broken.",
    correctOptionId: "B",
    explanation: "A fronted preposition takes which, not that.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R1-30",
    bankId: "R1",
    level: "Challenge",
    prompt: "Which relative clause identifies only some students?",
    options: [
      { id: "A", text: "Students who need help can stay." },
      { id: "B", text: "Students, who need help, can stay." },
      { id: "C", text: "Mona, who needs help, can stay." },
      { id: "D", text: "Our teacher, who offers help, can stay." }
    ],
    sourceAnswer: "A. Students who need help can stay.",
    correctOptionId: "A",
    explanation: "The defining clause selects a subgroup.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-43"
  },

  // ==========================================
  // R2: Relative clauses: build, edit and explain (30 items)
  // ==========================================
  {
    id: "R2-01",
    bankId: "R2",
    level: "Foundation",
    prompt: "Join using who: A girl sits near me. She speaks French.",
    sourceAnswer: "A girl who speaks French sits near me.",
    explanation: "Who replaces the subject she.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "R2-02",
    bankId: "R2",
    level: "Foundation",
    prompt: "Join using which: I bought a notebook. It has a green cover.",
    sourceAnswer: "I bought a notebook which has a green cover.",
    explanation: "Which refers to notebook.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "R2-03",
    bankId: "R2",
    level: "Foundation",
    prompt: "Join using whose: I met a boy. His father is a teacher.",
    sourceAnswer: "I met a boy whose father is a teacher.",
    explanation: "Whose replaces his.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R2-04",
    bankId: "R2",
    level: "Foundation",
    prompt: "Join using where: This is the library. We study there.",
    sourceAnswer: "This is the library where we study.",
    explanation: "Do not keep there.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R2-05",
    bankId: "R2",
    level: "Foundation",
    prompt: "Join using when: Friday is the day. Our club meets then.",
    sourceAnswer: "Friday is the day when our club meets.",
    explanation: "When replaces then.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R2-06",
    bankId: "R2",
    level: "Foundation",
    prompt: "Join using why: Tell me the reason. You were absent for that reason.",
    sourceAnswer: "Tell me the reason why you were absent.",
    explanation: "Why introduces the reason.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R2-07",
    bankId: "R2",
    level: "Foundation",
    prompt: "Correct: The woman which helps us is kind.",
    sourceAnswer: "The woman who helps us is kind.",
    explanation: "Use who or that for a person in a defining clause.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "R2-08",
    bankId: "R2",
    level: "Foundation",
    prompt: "Correct: The book who is on the desk is mine.",
    sourceAnswer: "The book which is on the desk is mine.",
    explanation: "Which or that refers to a thing.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "R2-09",
    bankId: "R2",
    level: "Foundation",
    prompt: "Correct: The boy whose won is happy.",
    sourceAnswer: "The boy who won is happy.",
    explanation: "Who is a subject; whose requires a following noun here.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R2-10",
    bankId: "R2",
    level: "Foundation",
    prompt: "Correct: The students who studies here work hard.",
    sourceAnswer: "The students who study here work hard.",
    explanation: "Plural antecedent requires study.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R2-11",
    bankId: "R2",
    level: "Apply",
    prompt: "Omit only the object relative pronoun: The film that we watched was interesting.",
    sourceAnswer: "The film we watched was interesting.",
    explanation: "That is an object in a defining clause.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-44"
  },
  {
    id: "R2-12",
    bankId: "R2",
    level: "Apply",
    prompt: "Explain why who cannot be omitted: The nurse who works here is kind.",
    sourceAnswer: "Who is the subject of works, so it cannot simply be omitted.",
    explanation: "Dropping a subject pronoun is different from reducing a clause.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-44"
  },
  {
    id: "R2-13",
    bankId: "R2",
    level: "Apply",
    prompt: "Correct: The article which I read it was useful.",
    sourceAnswer: "The article which I read was useful.",
    explanation: "Remove the repeated object it.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-44"
  },
  {
    id: "R2-14",
    bankId: "R2",
    level: "Apply",
    prompt: "Add punctuation for extra information: Cairo which is Egypt's capital is a large city.",
    sourceAnswer: "Cairo, which is Egypt's capital, is a large city.",
    explanation: "Use a comma at each end of the inserted clause.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R2-15",
    bankId: "R2",
    level: "Apply",
    prompt: "Correct: My teacher, that lives nearby, walks to school.",
    sourceAnswer: "My teacher, who lives nearby, walks to school.",
    explanation: "That is not used in non-defining clauses.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R2-16",
    bankId: "R2",
    level: "Apply",
    prompt: "Join using whom: This is the doctor. We consulted her.",
    sourceAnswer: "This is the doctor whom we consulted.",
    explanation: "Whom is the object; who or that also works without the specified keyword.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "R2-17",
    bankId: "R2",
    level: "Apply",
    prompt: "Rewrite using where: The room in which we meet is quiet.",
    sourceAnswer: "The room where we meet is quiet.",
    explanation: "Where replaces in which.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R2-18",
    bankId: "R2",
    level: "Apply",
    prompt: "Rewrite using which: The museum that we visited is new.",
    sourceAnswer: "The museum which we visited is new.",
    explanation: "Visited requires an object; where would not work.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R2-19",
    bankId: "R2",
    level: "Apply",
    prompt: "Join using whose: The organisation reopened. Its offices were repaired.",
    sourceAnswer: "The organisation whose offices were repaired reopened.",
    explanation: "Whose can refer to an organisation.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R2-20",
    bankId: "R2",
    level: "Apply",
    prompt: "Explain the error: The place where we visited was crowded.",
    sourceAnswer: "Use 'the place which we visited' because visited needs an object.",
    explanation: "Alternatively: the place where we stayed.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R2-21",
    bankId: "R2",
    level: "Challenge",
    prompt: "Use formal preposition + relative pronoun: The friend who I spoke to helped me.",
    sourceAnswer: "The friend to whom I spoke helped me.",
    explanation: "To is fronted before whom.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R2-22",
    bankId: "R2",
    level: "Challenge",
    prompt: "Use formal preposition + relative pronoun: The issue that we argued about was complex.",
    sourceAnswer: "The issue about which we argued was complex.",
    explanation: "About is fronted before which.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R2-23",
    bankId: "R2",
    level: "Challenge",
    prompt: "Rewrite with the preposition at the end: The person with whom I work is helpful.",
    sourceAnswer: "The person who I work with is helpful.",
    explanation: "Whom, that, or no pronoun also works in this defining clause.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R2-24",
    bankId: "R2",
    level: "Challenge",
    prompt: "Correct: The school in that she studies is nearby.",
    sourceAnswer: "The school in which she studies is nearby.",
    explanation: "That cannot follow a fronted preposition.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "R2-25",
    bankId: "R2",
    level: "Challenge",
    prompt: "Join using which to comment on the whole event: She checked the source. This improved her report.",
    sourceAnswer: "She checked the source, which improved her report.",
    explanation: "Which refers to the whole event, with a comma.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-46"
  },
  {
    id: "R2-26",
    bankId: "R2",
    level: "Challenge",
    prompt: "Join using two of whom: Five students spoke. Two of them disagreed.",
    sourceAnswer: "Five students spoke, two of whom disagreed.",
    explanation: "A quantity followed by of whom refers to people.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-46"
  },
  {
    id: "R2-27",
    bankId: "R2",
    level: "Challenge",
    prompt: "Join using all of which: I read three articles. All of them were useful.",
    sourceAnswer: "I read three articles, all of which were useful.",
    explanation: "Of which refers to things.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-46"
  },
  {
    id: "R2-28",
    bankId: "R2",
    level: "Challenge",
    prompt: "Explain the difference: 'The students who revised passed' / 'The students, who revised, passed'.",
    sourceAnswer: "The first identifies the students who revised; the second adds that all the students being discussed revised and passed.",
    explanation: "Commas change the meaning.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "R2-29",
    bankId: "R2",
    level: "Challenge",
    prompt: "Correct the relative clause, then explain whether it must be removed: The woman to that I sent the email replied to it yesterday.",
    sourceAnswer: "The woman to whom I sent the email replied to it yesterday. Keep it in the main clause.",
    explanation: "It belongs to the main clause and refers to the email; do not remove it mechanically.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-44"
  },
  {
    id: "R2-30",
    bankId: "R2",
    level: "Challenge",
    prompt: "Write one sentence with whose referring to a thing and explain its meaning.",
    sourceAnswer: "The school whose library opens late supports readers. Whose shows that the library belongs to the school.",
    explanation: "Accept any accurate sentence and explanation.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-43"
  },

  // ==========================================
  // P1: Participles: meaning and safe reduction (30 items)
  // ==========================================
  {
    id: "P1-01",
    bankId: "P1",
    level: "Foundation",
    prompt: "The boy _____ by the door is my brother.",
    options: [
      { id: "A", text: "stood" },
      { id: "B", text: "standing" },
      { id: "C", text: "stands" },
      { id: "D", text: "stand" }
    ],
    sourceAnswer: "B. standing",
    correctOptionId: "B",
    explanation: "The boy performs the action.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "P1-02",
    bankId: "P1",
    level: "Foundation",
    prompt: "The books _____ by the class are on display.",
    options: [
      { id: "A", text: "written" },
      { id: "B", text: "writing" },
      { id: "C", text: "wrote" },
      { id: "D", text: "writes" }
    ],
    sourceAnswer: "A. written",
    correctOptionId: "A",
    explanation: "The books receive the action.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "P1-03",
    bankId: "P1",
    level: "Foundation",
    prompt: "The girl _____ the poster is Salma.",
    options: [
      { id: "A", text: "designed" },
      { id: "B", text: "designs" },
      { id: "C", text: "design" },
      { id: "D", text: "designing" }
    ],
    sourceAnswer: "D. designing",
    correctOptionId: "D",
    explanation: "Active -ing phrase modifies girl.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "P1-04",
    bankId: "P1",
    level: "Foundation",
    prompt: "The poster _____ yesterday looks clear.",
    options: [
      { id: "A", text: "printing" },
      { id: "B", text: "prints" },
      { id: "C", text: "printed" },
      { id: "D", text: "print" }
    ],
    sourceAnswer: "C. printed",
    correctOptionId: "C",
    explanation: "Passive past participle modifies poster.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "P1-05",
    bankId: "P1",
    level: "Foundation",
    prompt: "The students _____ in the hall are ready.",
    options: [
      { id: "A", text: "waited" },
      { id: "B", text: "waiting" },
      { id: "C", text: "waits" },
      { id: "D", text: "wait" }
    ],
    sourceAnswer: "B. waiting",
    correctOptionId: "B",
    explanation: "Active -ing phrase.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "P1-06",
    bankId: "P1",
    level: "Foundation",
    prompt: "The forms _____ by the teacher need signatures.",
    options: [
      { id: "A", text: "prepared" },
      { id: "B", text: "preparing" },
      { id: "C", text: "prepares" },
      { id: "D", text: "prepare" }
    ],
    sourceAnswer: "A. prepared",
    correctOptionId: "A",
    explanation: "Passive past participle.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "P1-07",
    bankId: "P1",
    level: "Foundation",
    prompt: "_____ tired, Omar took a short break.",
    options: [
      { id: "A", text: "Felt" },
      { id: "B", text: "Feels" },
      { id: "C", text: "Feel" },
      { id: "D", text: "Feeling" }
    ],
    sourceAnswer: "D. Feeling",
    correctOptionId: "D",
    explanation: "Omar is the person feeling tired.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "P1-08",
    bankId: "P1",
    level: "Foundation",
    prompt: "_____ by the noise, the baby woke up.",
    options: [
      { id: "A", text: "Disturbing" },
      { id: "B", text: "Disturbs" },
      { id: "C", text: "Disturbed" },
      { id: "D", text: "Disturb" }
    ],
    sourceAnswer: "C. Disturbed",
    correctOptionId: "C",
    explanation: "The baby receives the disturbance.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "P1-09",
    bankId: "P1",
    level: "Foundation",
    prompt: "The road _____ to school is closed.",
    options: [
      { id: "A", text: "led" },
      { id: "B", text: "leading" },
      { id: "C", text: "leads" },
      { id: "D", text: "lead" }
    ],
    sourceAnswer: "B. leading",
    correctOptionId: "B",
    explanation: "Leading describes what the road does.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "P1-10",
    bankId: "P1",
    level: "Foundation",
    prompt: "The photo _____ on the wall is old.",
    options: [
      { id: "A", text: "displayed" },
      { id: "B", text: "displaying" },
      { id: "C", text: "displays" },
      { id: "D", text: "display" }
    ],
    sourceAnswer: "A. displayed",
    correctOptionId: "A",
    explanation: "The photo receives the action.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "P1-11",
    bankId: "P1",
    level: "Apply",
    prompt: "'The students who are discussing the issue' can become _____.",
    options: [
      { id: "A", text: "the students discussed the issue" },
      { id: "B", text: "the students discuss the issue" },
      { id: "C", text: "the students who discussing the issue" },
      { id: "D", text: "the students discussing the issue" }
    ],
    sourceAnswer: "D. the students discussing the issue",
    correctOptionId: "D",
    explanation: "Remove who are; keep discussing.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "P1-12",
    bankId: "P1",
    level: "Apply",
    prompt: "'The report which was published yesterday' can become _____.",
    options: [
      { id: "A", text: "the report publishing yesterday" },
      { id: "B", text: "the report was published yesterday" },
      { id: "C", text: "the report published yesterday" },
      { id: "D", text: "the report which published yesterday" }
    ],
    sourceAnswer: "C. the report published yesterday",
    correctOptionId: "C",
    explanation: "Remove which was in this passive clause.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "P1-13",
    bankId: "P1",
    level: "Apply",
    prompt: "Which clause cannot be reduced by simply making its verb -ing?",
    options: [
      { id: "A", text: "The boy who is running is fast." },
      { id: "B", text: "The book that I bought is useful." },
      { id: "C", text: "The pupils who are waiting are quiet." },
      { id: "D", text: "The students who are working are busy." }
    ],
    sourceAnswer: "B. The book that I bought is useful.",
    correctOptionId: "B",
    explanation: "That is an object in the first clause.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "P1-14",
    bankId: "P1",
    level: "Apply",
    prompt: "Which sentence avoids a dangling participle?",
    options: [
      { id: "A", text: "Walking to school, I saw a bus." },
      { id: "B", text: "Walking to school, a bus passed me." },
      { id: "C", text: "Walking to school, my bag broke." },
      { id: "D", text: "Walking to school, the rain began." }
    ],
    sourceAnswer: "A. Walking to school, I saw a bus.",
    correctOptionId: "A",
    explanation: "The main subject I is doing the walking.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-49"
  },
  {
    id: "P1-15",
    bankId: "P1",
    level: "Apply",
    prompt: "Which sentence uses an introductory passive phrase correctly?",
    options: [
      { id: "A", text: "Written clearly, I followed the report." },
      { id: "B", text: "Written clearly, the teacher read the report." },
      { id: "C", text: "Written clearly, we understood the report." },
      { id: "D", text: "Written clearly, the report was easy to follow." }
    ],
    sourceAnswer: "D. Written clearly, the report was easy to follow.",
    correctOptionId: "D",
    explanation: "The report is what was written.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "P1-16",
    bankId: "P1",
    level: "Apply",
    prompt: "_____ the task, she submitted her answers. [Use a perfect participle.]",
    options: [
      { id: "A", text: "Completing" },
      { id: "B", text: "Completed" },
      { id: "C", text: "Having completed" },
      { id: "D", text: "Complete" }
    ],
    sourceAnswer: "C. Having completed",
    correctOptionId: "C",
    explanation: "Having + past participle shows an earlier action.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-49"
  },
  {
    id: "P1-17",
    bankId: "P1",
    level: "Apply",
    prompt: "_____ by the committee, the plan was announced. [Perfect passive participle.]",
    options: [
      { id: "A", text: "Having approved" },
      { id: "B", text: "Having been approved" },
      { id: "C", text: "Approving" },
      { id: "D", text: "Had approved" }
    ],
    sourceAnswer: "B. Having been approved",
    correctOptionId: "B",
    explanation: "The plan had received approval.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-49"
  },
  {
    id: "P1-18",
    bankId: "P1",
    level: "Apply",
    prompt: "_____ the answer, he asked for help.",
    options: [
      { id: "A", text: "Not knowing" },
      { id: "B", text: "Not known" },
      { id: "C", text: "Not knows" },
      { id: "D", text: "Not know" }
    ],
    sourceAnswer: "A. Not knowing",
    correctOptionId: "A",
    explanation: "Not precedes the active participle.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-49"
  },
  {
    id: "P1-19",
    bankId: "P1",
    level: "Apply",
    prompt: "Which punctuation is correct?",
    options: [
      { id: "A", text: "Feeling, nervous Salma took a breath." },
      { id: "B", text: "Feeling nervous Salma, took a breath." },
      { id: "C", text: "Feeling nervous Salma took, a breath." },
      { id: "D", text: "Feeling nervous, Salma took a breath." }
    ],
    sourceAnswer: "D. Feeling nervous, Salma took a breath.",
    correctOptionId: "D",
    explanation: "Place a comma after the introductory phrase.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "P1-20",
    bankId: "P1",
    level: "Apply",
    prompt: "In 'The students working outside are volunteers', working describes _____.",
    options: [
      { id: "A", text: "the speaker" },
      { id: "B", text: "the volunteers' teacher" },
      { id: "C", text: "the students" },
      { id: "D", text: "an unstated bus" }
    ],
    sourceAnswer: "C. the students",
    correctOptionId: "C",
    explanation: "The phrase follows and modifies students.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "P1-21",
    bankId: "P1",
    level: "Challenge",
    prompt: "Which rewrite preserves the completed past event most clearly: 'The girl who won the race last year is here'?",
    options: [
      { id: "A", text: "The girl winning the race last year is here." },
      { id: "B", text: "The girl who won the race last year is here." },
      { id: "C", text: "The girl win the race last year is here." },
      { id: "D", text: "The girl having win the race last year is here." }
    ],
    sourceAnswer: "B. The girl who won the race last year is here.",
    correctOptionId: "B",
    explanation: "Keep the finite clause when reduction would blur the completed past meaning.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "P1-22",
    bankId: "P1",
    level: "Challenge",
    prompt: "Which sentence describes work in progress on the bridge?",
    options: [
      { id: "A", text: "The bridge being repaired is closed." },
      { id: "B", text: "The bridge repaired last year is closed." },
      { id: "C", text: "The bridge repairs the road." },
      { id: "D", text: "The bridge has repair." }
    ],
    sourceAnswer: "A. The bridge being repaired is closed.",
    correctOptionId: "A",
    explanation: "Being + past participle gives a passive action in progress.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "P1-23",
    bankId: "P1",
    level: "Challenge",
    prompt: "Which sentence correctly uses an earlier active action?",
    options: [
      { id: "A", text: "Having been read the article, Mona questioned the claim." },
      { id: "B", text: "Having reading the article, Mona questioned the claim." },
      { id: "C", text: "Have read the article, Mona questioned the claim." },
      { id: "D", text: "Having read the article, Mona questioned the claim." }
    ],
    sourceAnswer: "D. Having read the article, Mona questioned the claim.",
    correctOptionId: "D",
    explanation: "Mona both read and questioned.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-49"
  },
  {
    id: "P1-24",
    bankId: "P1",
    level: "Challenge",
    prompt: "Which sentence preserves 'After the team had collected the data, it wrote the report'?",
    options: [
      { id: "A", text: "Having collected the data, the report was written." },
      { id: "B", text: "Collected the data, the team wrote the report." },
      { id: "C", text: "Having collected the data, the team wrote the report." },
      { id: "D", text: "Having been collected, the team wrote the report." }
    ],
    sourceAnswer: "C. Having collected the data, the team wrote the report.",
    correctOptionId: "C",
    explanation: "The same subject must perform both actions.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-49"
  },
  {
    id: "P1-25",
    bankId: "P1",
    level: "Challenge",
    prompt: "Which rewrite avoids changing 'The teacher whom I thanked smiled'?",
    options: [
      { id: "A", text: "The teacher thanking smiled." },
      { id: "B", text: "The teacher I thanked smiled." },
      { id: "C", text: "The teacher thanked smiled." },
      { id: "D", text: "The teacher whom thanking smiled." }
    ],
    sourceAnswer: "B. The teacher I thanked smiled.",
    correctOptionId: "B",
    explanation: "Omit an object pronoun; do not force participial reduction.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "P1-26",
    bankId: "P1",
    level: "Challenge",
    prompt: "Choose the clearest repair of 'Reading the survey, several errors became obvious'.",
    options: [
      { id: "A", text: "Reading the survey, I noticed several errors." },
      { id: "B", text: "Reading the survey, several errors were noticed." },
      { id: "C", text: "Reading the survey, the errors stood out." },
      { id: "D", text: "Reading the survey, my notes were useful." }
    ],
    sourceAnswer: "A. Reading the survey, I noticed several errors.",
    correctOptionId: "A",
    explanation: "Name the reader as the main subject.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-49"
  },
  {
    id: "P1-27",
    bankId: "P1",
    level: "Challenge",
    prompt: "In 'The results, published yesterday, attracted attention', commas show _____.",
    options: [
      { id: "A", text: "a question" },
      { id: "B", text: "a missing subject" },
      { id: "C", text: "future time" },
      { id: "D", text: "additional information" }
    ],
    sourceAnswer: "D. additional information",
    correctOptionId: "D",
    explanation: "The phrase adds non-essential information.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "P1-28",
    bankId: "P1",
    level: "Challenge",
    prompt: "Which statement about -ing participles is correct?",
    options: [
      { id: "A", text: "They always refer to the present moment." },
      { id: "B", text: "They always refer to the future." },
      { id: "C", text: "Their time is interpreted from the sentence context." },
      { id: "D", text: "They are always passive." }
    ],
    sourceAnswer: "C. Their time is interpreted from the sentence context.",
    correctOptionId: "C",
    explanation: "An -ing form does not by itself fix tense.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "P1-29",
    bankId: "P1",
    level: "Challenge",
    prompt: "Which rewrite best keeps the modal meaning in 'Students who must submit forms should wait'?",
    options: [
      { id: "A", text: "Students submitting forms must wait." },
      { id: "B", text: "Students who must submit forms should wait." },
      { id: "C", text: "Students submitted forms should wait." },
      { id: "D", text: "Students must submitting forms should wait." }
    ],
    sourceAnswer: "B. Students who must submit forms should wait.",
    correctOptionId: "B",
    explanation: "Mechanical reduction may lose obligation.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "P1-30",
    bankId: "P1",
    level: "Challenge",
    prompt: "Which pair accurately contrasts active and passive meanings?",
    options: [
      { id: "A", text: "students interviewing / students interviewed" },
      { id: "B", text: "students interviewed / students interview" },
      { id: "C", text: "students interviews / students interviewed" },
      { id: "D", text: "students interview / students interviewing" }
    ],
    sourceAnswer: "A. students interviewing / students interviewed",
    correctOptionId: "A",
    explanation: "Interviewing students conduct interviews; interviewed students receive them.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },

  // ==========================================
  // C1: Conditionals: core meaning and form (30 items)
  // ==========================================
  {
    id: "C1-01",
    bankId: "C1",
    level: "Foundation",
    prompt: "If I need a definition, I _____ a dictionary. [Describe a regular habit.]",
    options: [
      { id: "A", text: "used" },
      { id: "B", text: "use" },
      { id: "C", text: "would use" },
      { id: "D", text: "had used" }
    ],
    sourceAnswer: "B. use",
    correctOptionId: "B",
    explanation: "Present + present gives this habitual conditional.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-02",
    bankId: "C1",
    level: "Foundation",
    prompt: "If she _____ tomorrow, we will discuss the project.",
    options: [
      { id: "A", text: "comes" },
      { id: "B", text: "came" },
      { id: "C", text: "had come" },
      { id: "D", text: "will comes" }
    ],
    sourceAnswer: "A. comes",
    correctOptionId: "A",
    explanation: "Present simple in the future condition.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-03",
    bankId: "C1",
    level: "Foundation",
    prompt: "If you need help, _____ the teacher.",
    options: [
      { id: "A", text: "asked" },
      { id: "B", text: "asking" },
      { id: "C", text: "to ask" },
      { id: "D", text: "ask" }
    ],
    sourceAnswer: "D. ask",
    correctOptionId: "D",
    explanation: "The main clause can be an imperative.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-04",
    bankId: "C1",
    level: "Foundation",
    prompt: "If we leave now, we _____ arrive on time.",
    options: [
      { id: "A", text: "would" },
      { id: "B", text: "had" },
      { id: "C", text: "will" },
      { id: "D", text: "were" }
    ],
    sourceAnswer: "C. will",
    correctOptionId: "C",
    explanation: "First conditional prediction.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-05",
    bankId: "C1",
    level: "Foundation",
    prompt: "If I had more free time now, I _____ join the club.",
    options: [
      { id: "A", text: "will" },
      { id: "B", text: "would" },
      { id: "C", text: "have" },
      { id: "D", text: "am" }
    ],
    sourceAnswer: "B. would",
    correctOptionId: "B",
    explanation: "Unreal present: would + base verb.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-06",
    bankId: "C1",
    level: "Foundation",
    prompt: "If I _____ you, I would check the source.",
    options: [
      { id: "A", text: "were" },
      { id: "B", text: "am" },
      { id: "C", text: "will be" },
      { id: "D", text: "had been" }
    ],
    sourceAnswer: "A. were",
    correctOptionId: "A",
    explanation: "Were is the usual formal advice pattern.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-07",
    bankId: "C1",
    level: "Foundation",
    prompt: "If she had revised, she _____ have answered better.",
    options: [
      { id: "A", text: "will" },
      { id: "B", text: "can" },
      { id: "C", text: "is" },
      { id: "D", text: "would" }
    ],
    sourceAnswer: "D. would",
    correctOptionId: "D",
    explanation: "Third conditional main clause.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-08",
    bankId: "C1",
    level: "Foundation",
    prompt: "If they _____ earlier yesterday, they would have caught the bus.",
    options: [
      { id: "A", text: "leave" },
      { id: "B", text: "have left" },
      { id: "C", text: "had left" },
      { id: "D", text: "will leave" }
    ],
    sourceAnswer: "C. had left",
    correctOptionId: "C",
    explanation: "Past perfect in the unreal past condition.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-09",
    bankId: "C1",
    level: "Foundation",
    prompt: "If the library is open, I may _____ there.",
    options: [
      { id: "A", text: "studied" },
      { id: "B", text: "study" },
      { id: "C", text: "studies" },
      { id: "D", text: "studying" }
    ],
    sourceAnswer: "B. study",
    correctOptionId: "B",
    explanation: "A modal takes a base verb.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-10",
    bankId: "C1",
    level: "Foundation",
    prompt: "We will wait if he _____ late.",
    options: [
      { id: "A", text: "is" },
      { id: "B", text: "will" },
      { id: "C", text: "was being yesterday" },
      { id: "D", text: "had" }
    ],
    sourceAnswer: "A. is",
    correctOptionId: "A",
    explanation: "Use present simple for this future condition.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-11",
    bankId: "C1",
    level: "Apply",
    prompt: "If schools offer support, some students _____ feel less isolated.",
    options: [
      { id: "A", text: "must always" },
      { id: "B", text: "cannot ever" },
      { id: "C", text: "had" },
      { id: "D", text: "may" }
    ],
    sourceAnswer: "D. may",
    correctOptionId: "D",
    explanation: "May expresses a cautious possibility.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-52"
  },
  {
    id: "C1-12",
    bankId: "C1",
    level: "Apply",
    prompt: "If our school had a larger hall, we _____ hold more activities.",
    options: [
      { id: "A", text: "can" },
      { id: "B", text: "will" },
      { id: "C", text: "could" },
      { id: "D", text: "have" }
    ],
    sourceAnswer: "C. could",
    correctOptionId: "C",
    explanation: "Could expresses hypothetical ability.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-13",
    bankId: "C1",
    level: "Apply",
    prompt: "If the researchers had used a larger sample, the results _____ have been more reliable.",
    options: [
      { id: "A", text: "may yesterday" },
      { id: "B", text: "might" },
      { id: "C", text: "will" },
      { id: "D", text: "can" }
    ],
    sourceAnswer: "B. might",
    correctOptionId: "B",
    explanation: "Might have expresses cautious unreal past possibility.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-14",
    bankId: "C1",
    level: "Apply",
    prompt: "'If I had enough money, I would buy it' describes _____.",
    options: [
      { id: "A", text: "an unreal or unlikely present situation" },
      { id: "B", text: "a completed purchase yesterday" },
      { id: "C", text: "a fixed scientific fact" },
      { id: "D", text: "a command" }
    ],
    sourceAnswer: "A. an unreal or unlikely present situation",
    correctOptionId: "A",
    explanation: "The past form expresses distance from present reality.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-15",
    bankId: "C1",
    level: "Apply",
    prompt: "'If I had saved enough, I would have bought it' describes _____.",
    options: [
      { id: "A", text: "a future plan" },
      { id: "B", text: "a repeated habit" },
      { id: "C", text: "an instruction" },
      { id: "D", text: "an unreal past situation" }
    ],
    sourceAnswer: "D. an unreal past situation",
    correctOptionId: "D",
    explanation: "Both clauses point to an alternative past.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C1-16",
    bankId: "C1",
    level: "Apply",
    prompt: "Unless you check the source, you _____ know whether it is reliable.",
    options: [
      { id: "A", text: "would had" },
      { id: "B", text: "had not" },
      { id: "C", text: "will not" },
      { id: "D", text: "not" }
    ],
    sourceAnswer: "C. will not",
    correctOptionId: "C",
    explanation: "Unless means if not in this context.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "C1-17",
    bankId: "C1",
    level: "Apply",
    prompt: "You may borrow the book _____ you return it tomorrow.",
    options: [
      { id: "A", text: "in case of" },
      { id: "B", text: "provided that" },
      { id: "C", text: "without" },
      { id: "D", text: "despite" }
    ],
    sourceAnswer: "B. provided that",
    correctOptionId: "B",
    explanation: "Provided that introduces a required condition.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "C1-18",
    bankId: "C1",
    level: "Apply",
    prompt: "I will save a copy now _____ the original gets deleted later.",
    options: [
      { id: "A", text: "in case" },
      { id: "B", text: "unless" },
      { id: "C", text: "in case of" },
      { id: "D", text: "without" }
    ],
    sourceAnswer: "A. in case",
    correctOptionId: "A",
    explanation: "Saving first is a precaution.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "C1-19",
    bankId: "C1",
    level: "Apply",
    prompt: "_____ an emergency, use this exit.",
    options: [
      { id: "A", text: "In case" },
      { id: "B", text: "If" },
      { id: "C", text: "Unless" },
      { id: "D", text: "In case of" }
    ],
    sourceAnswer: "D. In case of",
    correctOptionId: "D",
    explanation: "In case of is followed by a noun phrase.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "C1-20",
    bankId: "C1",
    level: "Apply",
    prompt: "Without your help last night, I _____ have finished the task.",
    options: [
      { id: "A", text: "will not" },
      { id: "B", text: "cannot" },
      { id: "C", text: "would not" },
      { id: "D", text: "do not" }
    ],
    sourceAnswer: "C. would not",
    correctOptionId: "C",
    explanation: "A counterfactual past result takes would not have.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-52"
  },
  {
    id: "C1-21",
    bankId: "C1",
    level: "Challenge",
    prompt: "_____ you need further information, contact the office.",
    options: [
      { id: "A", text: "Had" },
      { id: "B", text: "Should" },
      { id: "C", text: "Were" },
      { id: "D", text: "Unless" }
    ],
    sourceAnswer: "B. Should",
    correctOptionId: "B",
    explanation: "Formal inversion: should + subject + base verb.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-53"
  },
  {
    id: "C1-22",
    bankId: "C1",
    level: "Challenge",
    prompt: "_____ I in your position, I would ask for evidence.",
    options: [
      { id: "A", text: "Were" },
      { id: "B", text: "Had" },
      { id: "C", text: "Should" },
      { id: "D", text: "If" }
    ],
    sourceAnswer: "A. Were",
    correctOptionId: "A",
    explanation: "Were + subject + complement.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-53"
  },
  {
    id: "C1-23",
    bankId: "C1",
    level: "Challenge",
    prompt: "_____ they checked the figures, they would have found the error.",
    options: [
      { id: "A", text: "Were" },
      { id: "B", text: "Should" },
      { id: "C", text: "Unless" },
      { id: "D", text: "Had" }
    ],
    sourceAnswer: "D. Had",
    correctOptionId: "D",
    explanation: "Had + subject + past participle.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-53"
  },
  {
    id: "C1-24",
    bankId: "C1",
    level: "Challenge",
    prompt: "Were she _____ the role, she would need training.",
    options: [
      { id: "A", text: "accepted" },
      { id: "B", text: "accepts" },
      { id: "C", text: "to accept" },
      { id: "D", text: "accepting to" }
    ],
    sourceAnswer: "C. to accept",
    correctOptionId: "C",
    explanation: "Were + subject + to-infinitive.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-53"
  },
  {
    id: "C1-25",
    bankId: "C1",
    level: "Challenge",
    prompt: "If I had slept earlier last night, I _____ less tired now.",
    options: [
      { id: "A", text: "would have been yesterday" },
      { id: "B", text: "would be" },
      { id: "C", text: "will have" },
      { id: "D", text: "had been" }
    ],
    sourceAnswer: "B. would be",
    correctOptionId: "B",
    explanation: "Past condition with a present result: mixed conditional.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-53"
  },
  {
    id: "C1-26",
    bankId: "C1",
    level: "Challenge",
    prompt: "If he were more careful in general, he _____ that error yesterday.",
    options: [
      { id: "A", text: "might not have made" },
      { id: "B", text: "will not make" },
      { id: "C", text: "does not make" },
      { id: "D", text: "had not make" }
    ],
    sourceAnswer: "A. might not have made",
    correctOptionId: "A",
    explanation: "Present trait with a past result.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-53"
  },
  {
    id: "C1-27",
    bankId: "C1",
    level: "Challenge",
    prompt: "Choose the accurate rewrite: 'Unless you hurry, you will miss the bus.'",
    options: [
      { id: "A", text: "If you hurry, you will miss the bus." },
      { id: "B", text: "Unless you do not hurry, you will miss the bus." },
      { id: "C", text: "If you did not hurry, you missed the bus." },
      { id: "D", text: "If you do not hurry, you will miss the bus." }
    ],
    sourceAnswer: "D. If you do not hurry, you will miss the bus.",
    correctOptionId: "D",
    explanation: "Preserve the negative condition.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "C1-28",
    bankId: "C1",
    level: "Challenge",
    prompt: "Which claim is appropriately cautious?",
    options: [
      { id: "A", text: "If access improved, everyone would certainly be cured." },
      { id: "B", text: "If access improved, all problems would disappear." },
      { id: "C", text: "If access improved, participation might increase." },
      { id: "D", text: "If access improved, no student would ever struggle." }
    ],
    sourceAnswer: "C. If access improved, participation might increase.",
    correctOptionId: "C",
    explanation: "Might avoids a guaranteed universal result.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-52"
  },
  {
    id: "C1-29",
    bankId: "C1",
    level: "Challenge",
    prompt: "Which sentence uses future time after as soon as correctly?",
    options: [
      { id: "A", text: "I will call as soon as I will arrive." },
      { id: "B", text: "I will call as soon as I arrive." },
      { id: "C", text: "I will call as soon as I would arrive." },
      { id: "D", text: "I will call as soon as I had arrive." }
    ],
    sourceAnswer: "B. I will call as soon as I arrive.",
    correctOptionId: "B",
    explanation: "Future time clauses normally use a present form.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "C1-30",
    bankId: "C1",
    level: "Challenge",
    prompt: "Which statement correctly describes a conditional?",
    options: [
      { id: "A", text: "It links a condition to a result; meaning guides the form." },
      { id: "B", text: "Every if-clause must describe the past." },
      { id: "C", text: "Every conditional guarantees its result." },
      { id: "D", text: "Unless and in case always mean the same thing." }
    ],
    sourceAnswer: "A. It links a condition to a result; meaning guides the form.",
    correctOptionId: "A",
    explanation: "Conditionals vary with time and likelihood.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },

  // ==========================================
  // C2: Conditionals and participles: written application (30 items)
  // ==========================================
  {
    id: "C2-01",
    bankId: "C2",
    level: "Foundation",
    prompt: "Complete: If we have time tomorrow, we _____ (visit) the library.",
    sourceAnswer: "will visit",
    explanation: "Future possibility: first conditional.",
    grading: "guided_exact_match",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C2-02",
    bankId: "C2",
    level: "Foundation",
    prompt: "Complete: If I were you, I _____ (ask) for feedback.",
    sourceAnswer: "would ask",
    explanation: "Advice: second conditional.",
    grading: "guided_exact_match",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C2-03",
    bankId: "C2",
    level: "Foundation",
    prompt: "Complete: If she had called, I _____ (help) her.",
    sourceAnswer: "would have helped",
    explanation: "Unreal past: third conditional.",
    grading: "guided_exact_match",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C2-04",
    bankId: "C2",
    level: "Foundation",
    prompt: "Rewrite using Unless: If you do not practise, you will not improve.",
    sourceAnswer: "Unless you practise, you will not improve.",
    explanation: "Avoid adding another negative to practise.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "C2-05",
    bankId: "C2",
    level: "Foundation",
    prompt: "Rewrite using If: Unless the shop is open, we cannot buy notebooks.",
    sourceAnswer: "If the shop is not open, we cannot buy notebooks.",
    explanation: "Unless = if not in this sentence.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "C2-06",
    bankId: "C2",
    level: "Foundation",
    prompt: "Correct: If he will arrive early tomorrow, we will start.",
    sourceAnswer: "If he arrives early tomorrow, we will start.",
    explanation: "Use present simple in the condition.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C2-07",
    bankId: "C2",
    level: "Foundation",
    prompt: "Correct: If I was you, I will check it. [Use formal advice.]",
    sourceAnswer: "If I were you, I would check it.",
    explanation: "Were + would is the expected formal pattern.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C2-08",
    bankId: "C2",
    level: "Foundation",
    prompt: "Correct: If she had studied, she would pass yesterday.",
    sourceAnswer: "If she had studied, she would have passed yesterday.",
    explanation: "The result is in the unreal past.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C2-09",
    bankId: "C2",
    level: "Foundation",
    prompt: "Join using in case: I will take a spare pen. My pen may stop working.",
    sourceAnswer: "I will take a spare pen in case my pen stops working.",
    explanation: "Taking a spare is a precaution.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "C2-10",
    bankId: "C2",
    level: "Foundation",
    prompt: "Rewrite using In case of: If there is a fire, use the stairs.",
    sourceAnswer: "In case of fire, use the stairs.",
    explanation: "Use a noun phrase after of.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "C2-11",
    bankId: "C2",
    level: "Apply",
    prompt: "Join using provided that: You may join the trip. You must bring permission.",
    sourceAnswer: "You may join the trip provided that you bring permission.",
    explanation: "Preserve the required condition.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "C2-12",
    bankId: "C2",
    level: "Apply",
    prompt: "Rewrite using If: I do not have enough time now, so I cannot volunteer.",
    sourceAnswer: "If I had enough time now, I could volunteer.",
    explanation: "Imaginary present situation.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C2-13",
    bankId: "C2",
    level: "Apply",
    prompt: "Rewrite using If: She missed the meeting because she did not see the message.",
    sourceAnswer: "If she had seen the message, she would not have missed the meeting.",
    explanation: "Alternative past cause and result.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "C2-14",
    bankId: "C2",
    level: "Apply",
    prompt: "Use might to soften: If the school offers the service, every student will feel better.",
    sourceAnswer: "If the school offers the service, some students might feel better.",
    explanation: "Notice: C2-14 source model also changes 'every' to 'some'. Label this as cautious claim rewriting, not a strict meaning-preserving rewrite.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-52"
  },
  {
    id: "C2-15",
    bankId: "C2",
    level: "Apply",
    prompt: "Explain the difference: I will call if I need help / I will save your number in case I need help.",
    sourceAnswer: "The first action depends on needing help; the second is preparation for a possible need.",
    explanation: "If introduces a condition; in case introduces a precaution.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "C2-16",
    bankId: "C2",
    level: "Apply",
    prompt: "Reduce: The students who are planning the event need a room.",
    sourceAnswer: "The students planning the event need a room.",
    explanation: "Active subject-relative reduction.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "C2-17",
    bankId: "C2",
    level: "Apply",
    prompt: "Reduce: The report which was written by Salma is clear.",
    sourceAnswer: "The report written by Salma is clear.",
    explanation: "Passive reduction.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "C2-18",
    bankId: "C2",
    level: "Apply",
    prompt: "Begin Having: After Omar had checked the data, he wrote the conclusion.",
    sourceAnswer: "Having checked the data, Omar wrote the conclusion.",
    explanation: "Earlier action and same subject.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-49"
  },
  {
    id: "C2-19",
    bankId: "C2",
    level: "Apply",
    prompt: "Correct: Walking into class, my notebook fell.",
    sourceAnswer: "As I was walking into class, my notebook fell.",
    explanation: "Alternatively: Walking into class, I dropped my notebook.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-49"
  },
  {
    id: "C2-20",
    bankId: "C2",
    level: "Apply",
    prompt: "Correct: The advice giving by the teacher was helpful.",
    sourceAnswer: "The advice given by the teacher was helpful.",
    explanation: "Advice receives the action.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "C2-21",
    bankId: "C2",
    level: "Challenge",
    prompt: "Begin Should: If you need help, contact us.",
    sourceAnswer: "Should you need help, contact us.",
    explanation: "Formal possible condition.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-53"
  },
  {
    id: "C2-22",
    bankId: "C2",
    level: "Challenge",
    prompt: "Begin Were: If I were the organiser, I would change the time.",
    sourceAnswer: "Were I the organiser, I would change the time.",
    explanation: "Invert were and subject.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-53"
  },
  {
    id: "C2-23",
    bankId: "C2",
    level: "Challenge",
    prompt: "Begin Had: If they had checked the source, they would have noticed the mistake.",
    sourceAnswer: "Had they checked the source, they would have noticed the mistake.",
    explanation: "Invert past-perfect had and subject.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-53"
  },
  {
    id: "C2-24",
    bankId: "C2",
    level: "Challenge",
    prompt: "Begin Were: If she were to accept, we would welcome her.",
    sourceAnswer: "Were she to accept, we would welcome her.",
    explanation: "Retain to + base verb.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-53"
  },
  {
    id: "C2-25",
    bankId: "C2",
    level: "Challenge",
    prompt: "Rewrite using But for: If you had not encouraged me, I would have stopped.",
    sourceAnswer: "But for your encouragement, I would have stopped.",
    explanation: "But for + noun phrase expresses the unreal condition.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-52"
  },
  {
    id: "C2-26",
    bankId: "C2",
    level: "Challenge",
    prompt: "Complete: If I had taken notes yesterday, I _____ (know) the answer now.",
    sourceAnswer: "would know",
    explanation: "Past condition; present result.",
    grading: "guided_exact_match",
    relatedGrammarId: "GRAM-53"
  },
  {
    id: "C2-27",
    bankId: "C2",
    level: "Challenge",
    prompt: "Explain why 'If they had support, they would succeed' does not prove that support guarantees success.",
    sourceAnswer: "It describes a hypothetical relationship; the claim still needs evidence and may be too certain.",
    explanation: "Could or might may be more cautious depending on context.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-52"
  },
  {
    id: "C2-28",
    bankId: "C2",
    level: "Challenge",
    prompt: "Begin Having been: After the plan had been approved, it was published.",
    sourceAnswer: "Having been approved, the plan was published.",
    explanation: "Perfect passive; the plan receives both actions.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-49"
  },
  {
    id: "C2-29",
    bankId: "C2",
    level: "Challenge",
    prompt: "Keep the meaning and explain why you do not reduce: The student who won yesterday is absent.",
    sourceAnswer: "The student who won yesterday is absent. A mechanical change to winning may blur the completed past event.",
    explanation: "Keeping the finite clause is the clearest choice.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "C2-30",
    bankId: "C2",
    level: "Challenge",
    prompt: "Write a cautious recommendation with a second conditional and a relative clause.",
    sourceAnswer: "If schools provided spaces where students could talk, some learners might feel better supported.",
    explanation: "Accept any grammatical answer with both structures and cautious meaning.",
    grading: "teacher_review",
    relatedGrammarId: "GRAM-52"
  },

  // ==========================================
  // S1: Reading: identify, analyse, evaluate (30 items)
  // ==========================================
  {
    id: "S1-01",
    bankId: "S1",
    level: "Foundation",
    prompt: "A1: Name two activities mentioned as ways of being physically active.",
    sourceAnswer: "Cycling, swimming or brisk walking (any two).",
    explanation: "Locate explicit details.",
    grading: "teacher_review",
    relatedPassageId: "A1"
  },
  {
    id: "S1-02",
    bankId: "S1",
    level: "Foundation",
    prompt: "A1: According to the passage, how much daily activity is recommended?",
    sourceAnswer: "At least 60 minutes of moderate-to-hard activity a day.",
    explanation: "This is a reading-comprehension answer based on the supplied text.",
    grading: "teacher_review",
    relatedPassageId: "A1"
  },
  {
    id: "S1-03",
    bankId: "S1",
    level: "Foundation",
    prompt: "A2: How many hours of sleep does the passage recommend for teenagers?",
    sourceAnswer: "Eight to ten hours per night.",
    explanation: "Quote the range accurately.",
    grading: "teacher_review",
    relatedPassageId: "A2"
  },
  {
    id: "S1-04",
    bankId: "S1",
    level: "Foundation",
    prompt: "A3: Define mindfulness in your own words.",
    sourceAnswer: "Paying deliberate attention to the present moment.",
    explanation: "Accept a clear paraphrase.",
    grading: "teacher_review",
    relatedPassageId: "A3"
  },
  {
    id: "S1-05",
    bankId: "S1",
    level: "Foundation",
    prompt: "A3: Name two forms of mindfulness mentioned.",
    sourceAnswer: "Meditation, slow breathing, yoga or sitting quietly without a device (any two).",
    explanation: "Use details from the text.",
    grading: "teacher_review",
    relatedPassageId: "A3"
  },
  {
    id: "S1-06",
    bankId: "S1",
    level: "Foundation",
    prompt: "B1: What does agency mean?",
    sourceAnswer: "The capacity to choose and act.",
    explanation: "Do not confuse this meaning with a business agency.",
    grading: "teacher_review",
    relatedPassageId: "B1"
  },
  {
    id: "S1-07",
    bankId: "S1",
    level: "Foundation",
    prompt: "B1: What does self-efficacy mean?",
    sourceAnswer: "Believing in your ability to make positive changes or achieve a task.",
    explanation: "Distinguish ability from personal worth.",
    grading: "teacher_review",
    relatedPassageId: "B1"
  },
  {
    id: "S1-08",
    bankId: "S1",
    level: "Foundation",
    prompt: "B2: Give two examples of structural barriers.",
    sourceAnswer: "No safe parks or affordable sports facilities; limited money for fresh food.",
    explanation: "Any two supported examples.",
    grading: "teacher_review",
    relatedPassageId: "B2"
  },
  {
    id: "S1-09",
    bankId: "S1",
    level: "Foundation",
    prompt: "B3: Who shares responsibility for well-being?",
    sourceAnswer: "Individuals, governments, schools, families and communities.",
    explanation: "Use the passage's shared-responsibility view.",
    grading: "teacher_review",
    relatedPassageId: "B3"
  },
  {
    id: "S1-10",
    bankId: "S1",
    level: "Foundation",
    prompt: "B3: What is a nudge in this passage?",
    sourceAnswer: "A small change to the choice environment that encourages behaviour without removing freedom.",
    explanation: "Include preserved choice.",
    grading: "teacher_review",
    relatedPassageId: "B3"
  },
  {
    id: "S1-11",
    bankId: "S1",
    level: "Apply",
    prompt: "A1: Explain why the figure 'more than 80%' is surprising in the argument.",
    sourceAnswer: "Most teenagers fail to meet activity targets despite the benefits described.",
    explanation: "Link data to the contrast in the passage.",
    grading: "teacher_review",
    relatedPassageId: "A1"
  },
  {
    id: "S1-12",
    bankId: "S1",
    level: "Apply",
    prompt: "A2: Explain the link the writer makes between sleep and learning.",
    sourceAnswer: "Sleep supports brain development; inadequate sleep can accompany difficulty concentrating.",
    explanation: "Attribute the claim to the passage.",
    grading: "teacher_review",
    relatedPassageId: "A2"
  },
  {
    id: "S1-13",
    bankId: "S1",
    level: "Apply",
    prompt: "A3: Why is mindful consumption wider than diet?",
    sourceAnswer: "It includes the media, products and information people take in.",
    explanation: "Identify the wider scope.",
    grading: "teacher_review",
    relatedPassageId: "A3"
  },
  {
    id: "S1-14",
    bankId: "S1",
    level: "Apply",
    prompt: "B1: Explain the phrase 'internal locus of control'.",
    sourceAnswer: "Belief that one's actions influence outcomes rather than outcomes being entirely controlled externally.",
    explanation: "Do not claim that people control every circumstance.",
    grading: "teacher_review",
    relatedPassageId: "B1"
  },
  {
    id: "S1-15",
    bankId: "S1",
    level: "Apply",
    prompt: "B2: How can advertising complicate personal responsibility?",
    sourceAnswer: "It shapes preferences and puts pressure on people, influencing the choices they make.",
    explanation: "Explain influence rather than removing all agency.",
    grading: "teacher_review",
    relatedPassageId: "B2"
  },
  {
    id: "S1-16",
    bankId: "S1",
    level: "Apply",
    prompt: "B3: How does the third viewpoint connect the first two?",
    sourceAnswer: "It recognises individual decisions and the social conditions that make those decisions possible.",
    explanation: "Synthesis of perspectives.",
    grading: "teacher_review",
    relatedPassageId: "B3"
  },
  {
    id: "S1-17",
    bankId: "S1",
    level: "Apply",
    prompt: "A: True, False or Not Given: Every teenager prefers cycling to swimming. Give a reason.",
    sourceAnswer: "Not Given. The passage lists activities but does not compare teenagers' preferences.",
    explanation: "State what evidence would be needed.",
    grading: "teacher_review",
    relatedPassageId: "A1"
  },
  {
    id: "S1-18",
    bankId: "S1",
    level: "Apply",
    prompt: "B: True, False or Not Given: The passage says governments have no role. Give a reason.",
    sourceAnswer: "False. It explicitly assigns governments a role in creating supportive conditions.",
    explanation: "Use textual evidence.",
    grading: "teacher_review",
    relatedPassageId: "B3"
  },
  {
    id: "S1-19",
    bankId: "S1",
    level: "Apply",
    prompt: "A: True, False or Not Given: Mindful consumption concerns only food. Give a reason.",
    sourceAnswer: "False. It also concerns media, products and information.",
    explanation: "Correct the false claim.",
    grading: "teacher_review",
    relatedPassageId: "A3"
  },
  {
    id: "S1-20",
    bankId: "S1",
    level: "Apply",
    prompt: "B: True, False or Not Given: All families in the same country have identical values. Give a reason.",
    sourceAnswer: "Not Given. The passage does not establish identical values in every family.",
    explanation: "Avoid stereotyping or importing assumptions.",
    grading: "teacher_review",
    relatedPassageId: "B2"
  },
  {
    id: "S1-21",
    bankId: "S1",
    level: "Challenge",
    prompt: "A2: Does 'more likely to report' prove that one factor caused the other? Explain.",
    sourceAnswer: "No. It reports an association; other factors and the study design must be considered.",
    explanation: "Association is not sufficient proof of causation.",
    grading: "teacher_review",
    relatedPassageId: "A2"
  },
  {
    id: "S1-22",
    bankId: "S1",
    level: "Challenge",
    prompt: "B1: What missing study detail would help you judge the evidence about self-efficacy?",
    sourceAnswer: "For example: sample size, sampling method, measures, duration or controls.",
    explanation: "Explain how the chosen detail helps evaluation.",
    grading: "teacher_review",
    relatedPassageId: "B1"
  },
  {
    id: "S1-23",
    bankId: "S1",
    level: "Challenge",
    prompt: "B3: Propose a school nudge and explain why it preserves choice.",
    sourceAnswer: "Place fruit at eye level while retaining other options, making it easier to choose without a ban.",
    explanation: "Accept another feasible example with genuine choice.",
    grading: "teacher_review",
    relatedPassageId: "B3"
  },
  {
    id: "S1-24",
    bankId: "S1",
    level: "Challenge",
    prompt: "B: Evaluate the statement 'Health is entirely an individual's responsibility'.",
    sourceAnswer: "A defensible answer weighs agency against barriers such as cost and safe facilities, then gives a qualified judgment.",
    explanation: "Award for reasoning and evidence, not agreement with one view.",
    grading: "teacher_review",
    relatedPassageId: "B1"
  },
  {
    id: "S1-25",
    bankId: "S1",
    level: "Challenge",
    prompt: "A and B: Compare one lifestyle factor with one social factor.",
    sourceAnswer: "For example, sleep habits involve personal routines, while safe facilities affect opportunities to be active; both can matter.",
    explanation: "Use a comparison and a supported conclusion.",
    grading: "teacher_review",
    relatedPassageId: "A1"
  },
  {
    id: "S1-26",
    bankId: "S1",
    level: "Challenge",
    prompt: "A3: Suggest a cautious conclusion about social connection.",
    sourceAnswer: "Face-to-face support may help some people feel less isolated; the passage does not show that every person responds identically.",
    explanation: "Use a hedge and avoid a universal claim.",
    grading: "teacher_review",
    relatedPassageId: "A3"
  },
  {
    id: "S1-27",
    bankId: "S1",
    level: "Challenge",
    prompt: "B2: Challenge the claim 'A person without a park has no agency at all'.",
    sourceAnswer: "A barrier limits options but does not necessarily remove all choices; alternatives may exist, depending on safety and resources.",
    explanation: "Recognise constraints without an absolute conclusion.",
    grading: "teacher_review",
    relatedPassageId: "B2"
  },
  {
    id: "S1-28",
    bankId: "S1",
    level: "Challenge",
    prompt: "A or B: Give a JRE response on one way schools could support well-being.",
    sourceAnswer: "Judgment: schools should improve access to activities. Reason: barriers can prevent participation. Evidence: B2 identifies unavailable or unaffordable facilities. Explain the link.",
    explanation: "Accept a different supported response.",
    grading: "teacher_review",
    relatedPassageId: "B2"
  },
  {
    id: "S1-29",
    bankId: "S1",
    level: "Challenge",
    prompt: "B3: Distinguish a nudge from a ban using an original example.",
    sourceAnswer: "Prominent reminders encourage a choice; banning an option removes it. For example, a visible water station versus prohibiting all other drinks.",
    explanation: "The difference is freedom of choice.",
    grading: "teacher_review",
    relatedPassageId: "B3"
  },
  {
    id: "S1-30",
    bankId: "S1",
    level: "Challenge",
    prompt: "Across both texts, identify one question that would require further evidence.",
    sourceAnswer: "For example, which intervention works best for this school, because the passages do not compare local outcomes directly.",
    explanation: "State why the present evidence is insufficient.",
    grading: "teacher_review",
    relatedPassageId: "A1"
  },

  // ==========================================
  // L1: Listening: two recordings, three levels (30 items)
  // ==========================================
  {
    id: "L1-01",
    bankId: "L1",
    level: "Foundation",
    prompt: "Recording 1: What general topic is discussed?",
    sourceAnswer: "Social media and teenagers' self-image.",
    explanation: "Listen for the overall topic.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-02",
    bankId: "L1",
    level: "Foundation",
    prompt: "Recording 1: Name the two image-based platforms mentioned.",
    sourceAnswer: "Instagram and TikTok.",
    explanation: "Listen for proper names.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-03",
    bankId: "L1",
    level: "Foundation",
    prompt: "Recording 1: Which age group is the main focus?",
    sourceAnswer: "Teenagers.",
    explanation: "Identify the target group.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-04",
    bankId: "L1",
    level: "Foundation",
    prompt: "Recording 1: Which effect describes showing only selected best moments?",
    sourceAnswer: "The highlight-reel effect.",
    explanation: "Listen for the named concept.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-05",
    bankId: "L1",
    level: "Foundation",
    prompt: "Recording 1: Give one group teenagers compare themselves with.",
    sourceAnswer: "Classmates, acquaintances, influencers or celebrities.",
    explanation: "Any one group from the supplied script.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-06",
    bankId: "L1",
    level: "Foundation",
    prompt: "Recording 4: How many teenagers were in the sample?",
    sourceAnswer: "450.",
    explanation: "Listen for the sample size.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-07",
    bankId: "L1",
    level: "Foundation",
    prompt: "Recording 4: What was the age range?",
    sourceAnswer: "14 to 17.",
    explanation: "Keep both ends of the range.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-08",
    bankId: "L1",
    level: "Foundation",
    prompt: "Recording 4: Which source of stress was ranked first?",
    sourceAnswer: "Academic pressure.",
    explanation: "Identify the highest-ranked cause.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-09",
    bankId: "L1",
    level: "Foundation",
    prompt: "Recording 4: What percentage cited academic pressure?",
    sourceAnswer: "82%.",
    explanation: "Distinguish this from the overall stress figure.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-10",
    bankId: "L1",
    level: "Foundation",
    prompt: "Recording 4: Which schools had greater access to counselling: urban or rural?",
    sourceAnswer: "Urban schools.",
    explanation: "Listen for the comparison.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-11",
    bankId: "L1",
    level: "Apply",
    prompt: "Recording 1: Explain why an online profile is not necessarily a complete picture of life.",
    sourceAnswer: "It selects and filters particular moments while leaving other experiences out.",
    explanation: "Interpret the explanation.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-12",
    bankId: "L1",
    level: "Apply",
    prompt: "Recording 1: What does the comparison with traditional media suggest?",
    sourceAnswer: "Social media can make the boundary between ordinary lives and idealised images less obvious.",
    explanation: "Explain the contrast.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-13",
    bankId: "L1",
    level: "Apply",
    prompt: "Recording 1: Explain 'twice as likely' without calling it proof of causation.",
    sourceAnswer: "One group reported the outcome at twice the rate of another; that comparison alone does not prove the app caused it.",
    explanation: "Use cautious interpretation.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-14",
    bankId: "L1",
    level: "Apply",
    prompt: "Recording 1: Why might comparing yourself with classmates feel different from comparing yourself with celebrities?",
    sourceAnswer: "Classmates seem more similar and relatable, making the comparison feel more personally relevant.",
    explanation: "A supported inference; accept another defensible explanation.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-15",
    bankId: "L1",
    level: "Apply",
    prompt: "Recording 1: Suggest a neutral paraphrase of 'online lives are easily perfect'.",
    sourceAnswer: "Online posts may present selected moments that seem unusually successful or trouble-free.",
    explanation: "Avoid accepting apparent perfection as fact.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-16",
    bankId: "L1",
    level: "Apply",
    prompt: "Recording 4: What proportion reported moderate to high stress during exams?",
    sourceAnswer: "68%.",
    explanation: "Use the wording in the supplied sheet transcript.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-17",
    bankId: "L1",
    level: "Apply",
    prompt: "Recording 4: List the other three reported sources of stress and their percentages.",
    sourceAnswer: "Social media comparison 61%; insufficient sleep 57%; family expectations 49%.",
    explanation: "One mark for each correct pair if scoring this item analytically.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-18",
    bankId: "L1",
    level: "Apply",
    prompt: "Recording 4: What does controlling for academic performance variables mean?",
    sourceAnswer: "Trying to account for differences in academic performance when comparing groups.",
    explanation: "It does not eliminate every possible explanation.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-19",
    bankId: "L1",
    level: "Apply",
    prompt: "Recording 4: Compare the coping approaches described.",
    sourceAnswer: "Some students sought family support; others used individual activities such as music, exercise or nature.",
    explanation: "Avoid turning group tendencies into universal rules.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-20",
    bankId: "L1",
    level: "Apply",
    prompt: "Recording 4: Calculate the gap between 74% and 31%. State the unit.",
    sourceAnswer: "43 percentage points.",
    explanation: "This is not the same as a 43% relative increase.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-21",
    bankId: "L1",
    level: "Challenge",
    prompt: "Recording 1: Identify one detail about the research you would need before trusting a broad conclusion.",
    sourceAnswer: "Sampling method, sample size, measures, comparison groups or how other factors were controlled.",
    explanation: "Explain why the chosen detail matters.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-22",
    bankId: "L1",
    level: "Challenge",
    prompt: "Recording 1: Is showing a successful moment necessarily dishonest? Give a qualified answer.",
    sourceAnswer: "Not necessarily; a genuine moment can still give a misleading impression if audiences assume it represents the whole life.",
    explanation: "Distinguish accuracy of a moment from completeness.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-23",
    bankId: "L1",
    level: "Challenge",
    prompt: "Recording 1: Give a short JRE response about evaluating online lifestyle claims.",
    sourceAnswer: "A defensible judgment is to check sources and context because posts are selective; cite the highlight-reel explanation.",
    explanation: "Accept supported alternative judgments.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-24",
    bankId: "L1",
    level: "Challenge",
    prompt: "Recording 1: Rewrite 'All social media destroys confidence' with appropriate caution.",
    sourceAnswer: "Some forms of social media use may negatively affect some teenagers' confidence.",
    explanation: "Hedge both the subject and the effect.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-25",
    bankId: "L1",
    level: "Challenge",
    prompt: "Recording 1: Suggest a question for a follow-up interview with teenagers.",
    sourceAnswer: "For example: How does the type of content you view affect how you feel about yourself?",
    explanation: "The question should investigate rather than assume a result.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },
  {
    id: "L1-26",
    bankId: "L1",
    level: "Challenge",
    prompt: "Recording 4: Why should findings from 450 students not automatically describe every Egyptian teenager?",
    sourceAnswer: "Representativeness and sampling matter; age, location and school differences may limit generalisation.",
    explanation: "A large-sounding number alone is not enough.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-27",
    bankId: "L1",
    level: "Challenge",
    prompt: "Recording 4: Does the reported 34% difference prove exercise caused lower stress? Explain.",
    sourceAnswer: "No. Other differences may remain, and an association does not alone prove causation.",
    explanation: "Do not erase the reported association either.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-28",
    bankId: "L1",
    level: "Challenge",
    prompt: "Recording 4: The percentages for stress causes total more than 100%. Give a possible explanation and a question to check it.",
    sourceAnswer: "Respondants may have selected several causes. Check whether the survey allowed multiple responses.",
    explanation: "Label the explanation as possible, not certain.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-29",
    bankId: "L1",
    level: "Challenge",
    prompt: "Recording 4: Propose a follow-up study addressing one limitation.",
    sourceAnswer: "For example, include a representative range of schools and follow students over time to examine changes and other influences.",
    explanation: "State the limitation and how the proposal addresses it.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },
  {
    id: "L1-30",
    bankId: "L1",
    level: "Challenge",
    prompt: "Both recordings: Give one cautious recommendation for schools, with a reason and a source detail.",
    sourceAnswer: "Schools could teach media literacy and improve access to support; selective online images and unequal counselling access give reasons to investigate these steps.",
    explanation: "Accept a justified recommendation without claiming guaranteed effects.",
    grading: "teacher_review",
    relatedAudioId: "REC-01"
  },

  // ==========================================
  // D1: Supported practice: small steps (30 items)
  // 19 bracket-choice conversions + 5 guided exact match + 6 teacher review
  // ==========================================
  {
    id: "D1-01",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: The teacher [who / which] helps me is kind.",
    options: [
      { id: "A", text: "who" },
      { id: "B", text: "which" }
    ],
    sourceAnswer: "who",
    correctOptionId: "A",
    explanation: "A person doing the action: who.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "D1-02",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: The book [who / which] is on the desk is mine.",
    options: [
      { id: "A", text: "who" },
      { id: "B", text: "which" }
    ],
    sourceAnswer: "which",
    correctOptionId: "B",
    explanation: "A thing: which.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "D1-03",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: The girl [whose / whom] bag is red is here.",
    options: [
      { id: "A", text: "whose" },
      { id: "B", text: "whom" }
    ],
    sourceAnswer: "whose",
    correctOptionId: "A",
    explanation: "Whose comes before a possessed noun.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-43"
  },
  {
    id: "D1-04",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: This is the room [where / who] we study.",
    options: [
      { id: "A", text: "where" },
      { id: "B", text: "who" }
    ],
    sourceAnswer: "where",
    correctOptionId: "A",
    explanation: "A place where an activity happens.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-45"
  },
  {
    id: "D1-05",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Complete with who: I have a friend _____ likes reading.",
    sourceAnswer: "who",
    explanation: "The friend does the action.",
    grading: "guided_exact_match",
    relatedGrammarId: "GRAM-42"
  },
  {
    id: "D1-06",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: The boy [playing / played] football is my brother.",
    options: [
      { id: "A", text: "playing" },
      { id: "B", text: "played" }
    ],
    sourceAnswer: "playing",
    correctOptionId: "A",
    explanation: "The boy does the action.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "D1-07",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: The letter [writing / written] by Salma is clear.",
    options: [
      { id: "A", text: "writing" },
      { id: "B", text: "written" }
    ],
    sourceAnswer: "written",
    correctOptionId: "B",
    explanation: "The letter receives the action.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "D1-08",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: [Feeling / Felt] tired, Ali sat down.",
    options: [
      { id: "A", text: "Feeling" },
      { id: "B", text: "Felt" }
    ],
    sourceAnswer: "Feeling",
    correctOptionId: "A",
    explanation: "Ali feels tired.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-48"
  },
  {
    id: "D1-09",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Complete with given: The advice _____ by the teacher helped me.",
    sourceAnswer: "given",
    explanation: "Passive meaning.",
    grading: "guided_exact_match",
    relatedGrammarId: "GRAM-47"
  },
  {
    id: "D1-10",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Find the person doing both actions: Walking home, Mona saw a cat.",
    sourceAnswer: "Mona",
    explanation: "The opening phrase and main clause share a subject.",
    grading: "guided_exact_match",
    relatedGrammarId: "GRAM-49"
  },
  {
    id: "D1-11",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: If I have time tomorrow, I [will / would] read.",
    options: [
      { id: "A", text: "will" },
      { id: "B", text: "would" }
    ],
    sourceAnswer: "will",
    correctOptionId: "A",
    explanation: "A possible future situation.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "D1-12",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: If I were you, I [will / would] ask.",
    options: [
      { id: "A", text: "will" },
      { id: "B", text: "would" }
    ],
    sourceAnswer: "would",
    correctOptionId: "B",
    explanation: "Advice about an imaginary situation.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "D1-13",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: If she had called, I [would help / would have helped].",
    options: [
      { id: "A", text: "would help" },
      { id: "B", text: "would have helped" }
    ],
    sourceAnswer: "would have helped",
    correctOptionId: "B",
    explanation: "An unreal past result.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "D1-14",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: If you need help, [ask / asking] me.",
    options: [
      { id: "A", text: "ask" },
      { id: "B", text: "asking" }
    ],
    sourceAnswer: "ask",
    correctOptionId: "A",
    explanation: "Use an imperative.",
    grading: "deterministic_choice",
    relatedGrammarId: "GRAM-50"
  },
  {
    id: "D1-15",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Complete with not: Unless you hurry means If you do _____ hurry.",
    sourceAnswer: "not",
    explanation: "Unless means if not here.",
    grading: "guided_exact_match",
    relatedGrammarId: "GRAM-51"
  },
  {
    id: "D1-16",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: A sibling is [a brother or sister / an online app].",
    options: [
      { id: "A", text: "a brother or sister" },
      { id: "B", text: "an online app" }
    ],
    sourceAnswer: "a brother or sister",
    correctOptionId: "A",
    explanation: "Learn the word in a short phrase.",
    grading: "deterministic_choice"
  },
  {
    id: "D1-17",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: Rural means [countryside / city].",
    options: [
      { id: "A", text: "countryside" },
      { id: "B", text: "city" }
    ],
    sourceAnswer: "countryside",
    correctOptionId: "A",
    explanation: "Rural refers to the countryside.",
    grading: "deterministic_choice"
  },
  {
    id: "D1-18",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: Sedentary means [sitting a lot / moving a lot].",
    options: [
      { id: "A", text: "sitting a lot" },
      { id: "B", text: "moving a lot" }
    ],
    sourceAnswer: "sitting a lot",
    correctOptionId: "A",
    explanation: "Sedentary describes little movement.",
    grading: "deterministic_choice"
  },
  {
    id: "D1-19",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose: Accurate means [correct / tired].",
    options: [
      { id: "A", text: "correct" },
      { id: "B", text: "tired" }
    ],
    sourceAnswer: "correct",
    correctOptionId: "A",
    explanation: "Accurate information is correct.",
    grading: "deterministic_choice"
  },
  {
    id: "D1-20",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Complete with support: Friends can offer emotional _____.",
    sourceAnswer: "support",
    explanation: "The collocation is emotional support.",
    grading: "guided_exact_match"
  },
  {
    id: "D1-21",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Read: 'Mona studies in the library. It is quiet.' Where does Mona study?",
    sourceAnswer: "In the library.",
    explanation: "Find a stated detail.",
    grading: "teacher_review"
  },
  {
    id: "D1-22",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Read: 'Ali took a spare pen in case his pen stopped working.' Why did he take it?",
    sourceAnswer: "As a precaution, in case his pen stopped working.",
    explanation: "Use the reason given.",
    grading: "teacher_review"
  },
  {
    id: "D1-23",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Read: 'Some posts show only happy moments.' Do they necessarily show a whole life? [Yes / No]",
    sourceAnswer: "No.",
    explanation: "Only some moments are shown.",
    grading: "teacher_review"
  },
  {
    id: "D1-24",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Choose the careful claim: [The plan may help some students / The plan solves every problem].",
    sourceAnswer: "The plan may help some students.",
    explanation: "May and some make the claim cautious.",
    grading: "teacher_review"
  },
  {
    id: "D1-25",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Complete the frame: I think the library is useful because _____.",
    sourceAnswer: "Possible answer: it gives us a quiet place to read.",
    explanation: "Accept another relevant reason.",
    grading: "teacher_review"
  },
  {
    id: "D1-26",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Recording 1: Listen for the topic. Choose [social media / cooking].",
    options: [
      { id: "A", text: "social media" },
      { id: "B", text: "cooking" }
    ],
    sourceAnswer: "social media",
    correctOptionId: "A",
    explanation: "Allow a replay before choosing.",
    grading: "deterministic_choice",
    relatedAudioId: "REC-01"
  },
  {
    id: "D1-27",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Recording 1: Listen for the word. Choose [teenagers / farmers].",
    options: [
      { id: "A", text: "teenagers" },
      { id: "B", text: "farmers" }
    ],
    sourceAnswer: "teenagers",
    correctOptionId: "A",
    explanation: "Use a short replay or transcript support if needed.",
    grading: "deterministic_choice",
    relatedAudioId: "REC-01"
  },
  {
    id: "D1-28",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Recording 4: Choose the sample size [450 / 45].",
    options: [
      { id: "A", text: "450" },
      { id: "B", text: "45" }
    ],
    sourceAnswer: "450",
    correctOptionId: "A",
    explanation: "Pause after the number when practising.",
    grading: "deterministic_choice",
    relatedAudioId: "REC-04"
  },
  {
    id: "D1-29",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Recording 4: Choose the main pressure [academic pressure / traffic noise].",
    options: [
      { id: "A", text: "academic pressure" },
      { id: "B", text: "traffic noise" }
    ],
    sourceAnswer: "academic pressure",
    correctOptionId: "A",
    explanation: "Listen for the highest-ranked cause.",
    grading: "deterministic_choice",
    relatedAudioId: "REC-04"
  },
  {
    id: "D1-30",
    bankId: "D1",
    level: "Supported practice",
    prompt: "Complete a claim with evidence: The recording discusses school stress. One detail is _____.",
    sourceAnswer: "Possible answer: academic pressure is the highest-ranked source of stress.",
    explanation: "Accept a relevant detail; allow spoken or written response in practice.",
    grading: "teacher_review",
    relatedAudioId: "REC-04"
  },

  // ==========================================
  // N1: The Lost World | Chapter 1 (30 items)
  // ==========================================
  {
    id: "N1-01",
    bankId: "N1",
    level: "Foundation",
    prompt: "Name the narrator and give his age.",
    sourceAnswer: "Edward Malone; he is twenty-three.",
    explanation: "p. 4: Malone introduces himself and his age.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-02",
    bankId: "N1",
    level: "Foundation",
    prompt: "What is Malone's job, and where does he work?",
    sourceAnswer: "He is a reporter on the Daily Gazette in London.",
    explanation: "p. 4: narrator, occupation, newspaper and city.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-03",
    bankId: "N1",
    level: "Foundation",
    prompt: "How does Gladys respond to Malone's proposal?",
    sourceAnswer: "She values his friendship but does not love him in the way he hopes.",
    explanation: "p. 4: her refusal is serious, not mocking or angry.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-04",
    bankId: "N1",
    level: "Foundation",
    prompt: "What kind of person does Gladys admire?",
    sourceAnswer: "Someone who faces danger and acts bravely because courage is part of his character.",
    explanation: "p. 4: distinguish genuine courage from trying to impress her.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-05",
    bankId: "N1",
    level: "Foundation",
    prompt: "Who is Mr McArdle?",
    sourceAnswer: "Malone's editor, an experienced newspaper man.",
    explanation: "p. 4.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-06",
    bankId: "N1",
    level: "Foundation",
    prompt: "What is Professor Challenger's field of study?",
    sourceAnswer: "Zoology; he is a zoologist.",
    explanation: "p. 5.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-07",
    bankId: "N1",
    level: "Foundation",
    prompt: "From which continent has Challenger returned?",
    sourceAnswer: "South America.",
    explanation: "p. 5; do not replace the continent with an unsupported specific location.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-08",
    bankId: "N1",
    level: "Foundation",
    prompt: "Where does Malone meet Tarp Henry?",
    sourceAnswer: "At the Savage Club.",
    explanation: "p. 5.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-09",
    bankId: "N1",
    level: "Foundation",
    prompt: "When is Malone's appointment with Challenger?",
    sourceAnswer: "At eleven o'clock on Wednesday morning.",
    explanation: "p. 6. The reply arrives two days after the letter; the appointment is on Wednesday.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-10",
    bankId: "N1",
    level: "Foundation",
    prompt: "Who opens the door at the Kensington house?",
    sourceAnswer: "Austin, a servant.",
    explanation: "p. 6.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-11",
    bankId: "N1",
    level: "Apply",
    prompt: "Explain the difference between Gladys's ideal of courage and merely impressing someone.",
    sourceAnswer: "Her ideal is an inner quality that leads to brave action when needed. Acting only for admiration makes approval the main motive.",
    explanation: "p. 4: explain the contrast rather than listing dangerous activities.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-12",
    bankId: "N1",
    level: "Apply",
    prompt: "Why does Malone ask for a dangerous assignment after speaking to Gladys?",
    sourceAnswer: "Her words unsettle him and awaken his wish for a challenge and a clearer purpose. His admiration for her also influences him.",
    explanation: "p. 4: he feels disappointed and excited, and London seems too safe.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-13",
    bankId: "N1",
    level: "Apply",
    prompt: "What does McArdle's surprise suggest about Malone's request?",
    sourceAnswer: "It suggests that actively seeking danger is unusual and that Malone is eager for an exceptional challenge.",
    explanation: "p. 4: McArdle contrasts the request with sensible people avoiding danger.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-14",
    bankId: "N1",
    level: "Apply",
    prompt: "Why does Challenger seem a suitable subject for Malone's assignment?",
    sourceAnswer: "His extraordinary claims need investigation, while his difficult behaviour makes interviewing him challenging.",
    explanation: "pp. 4-5: combine professional interest and personal risk.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-15",
    bankId: "N1",
    level: "Apply",
    prompt: "What evidence does McArdle say Challenger brought back?",
    sourceAnswer: "Damaged photographs, strange sketches and a few pieces of evidence.",
    explanation: "p. 5: do not add the detailed explanations introduced in Chapter 2.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-16",
    bankId: "N1",
    level: "Apply",
    prompt: "Why does Malone hide his occupation in his letter?",
    sourceAnswer: "He believes Challenger would reject a journalist, so he pretends to be a student to gain access.",
    explanation: "p. 5: explain both the obstacle and the strategy.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-17",
    bankId: "N1",
    level: "Apply",
    prompt: "How does Tarp Henry both help Malone and warn him?",
    sourceAnswer: "He helps him find Challenger's paper, but warns that Challenger may immediately notice Malone's lack of scientific knowledge.",
    explanation: "p. 5.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-18",
    bankId: "N1",
    level: "Apply",
    prompt: "How does Challenger's reply reveal both criticism and willingness to meet?",
    sourceAnswer: "He criticises Malone's understanding but offers to explain the matter in person at an appointment.",
    explanation: "p. 6: both details are needed.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-19",
    bankId: "N1",
    level: "Apply",
    prompt: "How do Mrs Challenger's warning and the voice behind the door build suspense?",
    sourceAnswer: "Her serious warning suggests danger, and the roaring voice makes that warning feel immediate before the meeting begins.",
    explanation: "p. 6: link each detail to the reader's expectation.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-20",
    bankId: "N1",
    level: "Apply",
    prompt: "Give two details of the study or Challenger's appearance and explain their effect.",
    sourceAnswer: "The desk holds books, maps and fossils, suggesting scientific work; Challenger's broad body, black beard and sharp eyes make him intimidating.",
    explanation: "p. 6: accept any two accurate details with a reasonable explanation.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-21",
    bankId: "N1",
    level: "Challenge",
    prompt: "Is Gladys a positive influence on Malone? Give a judgment and two details from the chapter.",
    sourceAnswer: "A defensible view is that she encourages genuine courage and gives him a sense of purpose. A contrasting view may stress that he responds by seeking danger and using deception.",
    explanation: "pp. 4-5: accept either judgment when supported by two accurate details.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-22",
    bankId: "N1",
    level: "Challenge",
    prompt: "Is Malone ready for the adventure he seeks? Use evidence from his dealings with McArdle or Tarp Henry.",
    sourceAnswer: "He shows initiative by seeking work and finding a way to obtain an interview, but his limited scientific understanding and willingness to take an uncertain risk suggest incomplete preparation.",
    explanation: "pp. 4-5: distinguish willingness from readiness.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-23",
    bankId: "N1",
    level: "Challenge",
    prompt: "Was the misleading letter acceptable? Give a judgment, reason and chapter detail.",
    sourceAnswer: "One view rejects it because he falsely presents himself as a student; another may defend investigation of a disputed public claim while acknowledging the dishonesty and risk.",
    explanation: "p. 5: accept a reasoned position; no single moral judgment is required.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-24",
    bankId: "N1",
    level: "Challenge",
    prompt: "Does Challenger's rude behaviour prove that his claims are false? Explain.",
    sourceAnswer: "No. His behaviour affects access and trust, but the claims require evaluation of evidence. In Chapter 1 the evidence is described but not independently checked.",
    explanation: "p. 5: separate personality from proof.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-25",
    bankId: "N1",
    level: "Challenge",
    prompt: "Does Malone show courage, impulsiveness, or both? Support your judgment.",
    sourceAnswer: "Both is a reasonable judgment: he willingly faces a difficult interview, but relies on a copied sentence he barely understands and postpones planning until he gets inside.",
    explanation: "p. 5: accept another supported judgment.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-26",
    bankId: "N1",
    level: "Challenge",
    prompt: "How might first-person narration affect our understanding of Malone?",
    sourceAnswer: "We learn his disappointment, excitement and hopes directly, but see the other characters mainly through his observations and interpretation.",
    explanation: "pp. 4-6: explain both access to feelings and limits of perspective.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-27",
    bankId: "N1",
    level: "Challenge",
    prompt: "Explain how the letter creates a risk that the reader expects to matter later.",
    sourceAnswer: "Malone claims scientific understanding that he lacks. Henry warns that he may be exposed, and Challenger's opening question puts that weak point under pressure.",
    explanation: "pp. 5-6: connect the setup with the chapter ending, without narrating Chapter 2.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-28",
    bankId: "N1",
    level: "Challenge",
    prompt: "What does the final encounter suggest about the gap between imagined and real adventure?",
    sourceAnswer: "Malone wants excitement in the abstract, but the intimidating study and demanding professor bring him face to face with an immediate personal challenge.",
    explanation: "p. 6: connect his earlier hopes to the actual encounter.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-29",
    bankId: "N1",
    level: "Challenge",
    prompt: "Suggest two questions a careful reporter should ask about Challenger's claim, and explain why.",
    sourceAnswer: "Where were the observations made? What records can another investigator check? These questions address location and independent verification.",
    explanation: "p. 5: other questions about dates, specimens or methods are acceptable; identify them as proposed questions.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  },
  {
    id: "N1-30",
    bankId: "N1",
    level: "Challenge",
    prompt: "Choose the main turning point in Chapter 1 and defend your choice with two details.",
    sourceAnswer: "Gladys's conversation is a strong choice because it changes Malone's view of his safe life and leads him to request dangerous work. The letter is another defensible choice because it secures entry and creates a risk of exposure.",
    explanation: "pp. 4-6: assess the quality of support rather than requiring one event.",
    grading: "teacher_review",
    relatedPassageId: "STORY-CH1"
  }
];

export const BANK_METADATA = [
  { id: 'V1', name: 'Vocabulary in Context', count: 30, description: 'Core vocabulary recognition and nuance from Unit 1' },
  { id: 'V2', name: 'Collocations & Prepositions', count: 30, description: 'Collocations, prepositions, word forms, and hedging' },
  { id: 'R1', name: 'Relative Clauses (MCQ)', count: 30, description: 'Pronouns, adverbs, defining vs non-defining clauses' },
  { id: 'R2', name: 'Relative Clauses (Written)', count: 30, description: 'Clause joining, preposition fronting, editing and explanations' },
  { id: 'P1', name: 'Participles & Safe Reduction', count: 30, description: 'Active -ing vs passive past participles and introductory phrases' },
  { id: 'C1', name: 'Conditionals (Core & Form)', count: 30, description: 'Zero, First, Second, Third, mixed, and inversion rules' },
  { id: 'C2', name: 'Conditionals & Participles (Written)', count: 30, description: 'Fill-ins, unless/in case rewrites, and model reconstructions' },
  { id: 'S1', name: 'Reading Passages (A1-B3)', count: 30, description: 'Evidence extraction, analytical reasoning, and true/false/not given' },
  { id: 'L1', name: 'Listening Lab (Rec 1 & 4)', count: 30, description: 'Listening comprehension across 3 difficulty tiers' },
  { id: 'D1', name: 'Supported Small Steps', count: 30, description: 'Scaffolded practice, bracket choices, and guided foundations' },
  { id: 'N1', name: 'The Lost World: Chapter 1', count: 30, description: 'Narrative reading, character motives, and evidence up to Challenger\'s study' }
] as const;
