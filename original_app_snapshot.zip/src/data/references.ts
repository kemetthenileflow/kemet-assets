import { ReadingPassage, GrammarReference } from '../types';

export const READING_PASSAGES: ReadingPassage[] = [
  {
    id: "A1",
    title: "Exercise and physical activity",
    cluster: "A",
    paragraphs: [
      "Health experts regularly recommend that teenagers do at least 60 minutes of moderate-to-hard physical activity every day. This doesn't necessarily mean competitive sport. Activities such as cycling to school, swimming, or even a brisk walk, all count towards the daily target.",
      "What makes exercise particularly powerful is its effect on the brain: physical activity causes the release of endorphins, chemicals that reduce feelings of stress and anxiety at the same time as boosting mood and self-confidence. Furthermore, teenagers who exercise regularly tend to sleep more deeply and report higher levels of concentration during school hours. Despite these well-documented benefits, a landmark WHO-led study found that more than 80% of teenagers worldwide fail to meet the recommended daily activity levels, largely due to sedentary screen-based habits."
    ],
    disclaimer: "Research findings are claims reported in the supplied text; referring to them does not independently verify the research."
  },
  {
    id: "A2",
    title: "Nutrition, sleep and recovery",
    cluster: "A",
    paragraphs: [
      "A balanced diet is widely seen as the foundation of physical and mental well-being. Nutritionists advise that teenagers consume a varied range of fruits, vegetables, whole grains, lean proteins, and healthy fats, while limiting their intake of processed foods, too much sugar, and high-caffeine drinks. Poor nutrition has been directly linked to fatigue, difficulty concentrating, and mood changes, all of which affect academic performance.",
      "Sleep is equally important, but it is often underestimated. Teenagers require from eight to ten hours of sleep per night to support brain development, emotional control, and physical recovery. Research published in the journal Sleep Medicine found that teenagers who slept fewer than seven hours per night were more likely to report symptoms of anxiety and depression. Setting up a regular bedtime routine, such as avoiding screens for one hour before sleeping, has been shown to improve sleep quality."
    ]
  },
  {
    id: "A3",
    title: "Mindfulness and social connection",
    cluster: "A",
    paragraphs: [
      "In recent years, mindfulness has moved from specialist wellness programs into common education. Mindfulness involves paying deliberate attention to the present moment, and can take many forms: meditation, slow breathing exercises, yoga, or simply sitting quietly without a device. Studies suggest that even ten minutes of daily mindfulness practice leads to measurable reductions in stress hormones over a period of four to six weeks.",
      "Alongside mindfulness, social connection plays a very important role in emotional health. Spending quality time with friends and family face to face rather than through screens has been shown to reduce loneliness and build the emotional resilience needed to cope with life's pressures. Finally, many psychologists advise us to be conscious not only of what we eat, but also of the media, products, and information we absorb daily."
    ]
  },
  {
    id: "B1",
    title: "Personal responsibility",
    cluster: "B",
    paragraphs: [
      "Many health professionals and philosophers argue that personal responsibility lies at the heart of a well-lived life. From this perspective, every individual possesses the agency - the capacity to choose and act, and it is through the exercise of this agency that identity is formed. Choosing to exercise, to eat nutritiously, to sleep well, and to manage stress are not simply habits; they are expressions of who we are and what we value. Psychologists refer to this as having an \"internal locus of control\" - a belief that one's own actions, rather than external forces, determine outcomes.",
      "Research often supports the benefits of taking personal ownership. A landmark study published in the Journal of Health Psychology found that individuals who scored highly on self-efficacy measures - that is, those who believed in their ability to make positive changes - were significantly more likely to maintain healthy behaviors over time, regardless of their socioeconomic background.",
      "Furthermore, advocates of personal responsibility argue that framing health as someone else's problem can be disempowering. When individuals attribute their choices entirely to outside forces, they risk becoming passive. Taking ownership, by contrast, builds confidence, resilience, and a sense of purpose, qualities that are central to a positive identity."
    ]
  },
  {
    id: "B2",
    title: "Social and environmental influences",
    cluster: "B",
    paragraphs: [
      "However, the idea that individuals are entirely responsible for their own health is increasingly challenged by social scientists and public health experts. Research in sociology demonstrates that where we grow up, how much money our family has, and the cultural rules we are raised with profoundly shape the choices available to us. A teenager growing up in a neighborhood with no safe parks or affordable sports facilities cannot simply \"choose\" to exercise easily.",
      "A family with limited income may struggle to prioritize fresh vegetables over cheaper processed foods. These are not failures of willpower; they are structural barriers, obstacles built into the environment that restrict genuine choice. Moreover, advertising and social media exert enormous pressure on young people.",
      "Brands invest billions in campaigns designed to shape preferences and habits, often targeting teenagers who are at a particularly impressionable stage of development."
    ]
  },
  {
    id: "B3",
    title: "Government and shared responsibility",
    cluster: "B",
    paragraphs: [
      "A third perspective argues that responsibility is not an either-or choice; it does not belong entirely to the individual or entirely to society, but is shared. Governments, schools, families, and communities all have a role in creating the conditions that make healthy living possible and accessible. In recent decades, many governments have introduced public health policies intended to guide and encourage better choices: taxes on high-sugar drinks, restrictions on junk food advertising near schools, and national campaigns promoting physical activity.",
      "Proponents argue that these measures do not remove individual freedom - they reshape the environment so that the healthier choice becomes the easier choice. Economist Richard Thaler's concept of the \"nudge\" captures this idea precisely: small, well-designed changes to the context in which decisions are made can shift behavior without restricting freedom. From this viewpoint, responsibility is not abandoned by the individual - it is supported and shared by the structures around them."
    ]
  },
  {
    id: "STORY-CH1",
    title: "The Lost World | Chapter 1",
    cluster: "STORY",
    paragraphs: [
      "Edward Malone, a twenty-three-year-old reporter on the Daily Gazette in London, hopes to marry Gladys Hungerton.",
      "She values their friendship but does not return his love. Her ideal of courage involves facing danger because bravery is part of one's character, rather than simply impressing another person.",
      "Disappointed but excited, Malone asks his editor, Mr McArdle, for a dangerous assignment. McArdle suggests interviewing Professor George Edward Challenger, a brilliant but difficult zoologist who has returned from South America with disputed claims about unknown animals. Challenger dislikes journalists and refuses to reveal the exact location of his discovery.",
      "At the Savage Club, Tarp Henry warns Malone about Challenger and helps him obtain a scientific paper. Malone copies a technical sentence into a letter and pretends to be a student interested in Challenger's work.",
      "Two days later, Challenger offers him an appointment for eleven on Wednesday morning. At the Kensington house, Austin admits Malone and Mrs Challenger warns him to leave if her husband becomes angry. The chapter ends as Malone enters the study and faces Challenger's intimidating appearance and challenging question."
    ],
    disclaimer: "Chapter boundary: Chapter 1 ends as Malone enters the study and faces Challenger. Do not use the later fight or the detailed explanation of the evidence as Chapter 1 events."
  }
];

export const GRAMMAR_REFERENCES: GrammarReference[] = [
  {
    id: "GRAM-42",
    title: "Relative clauses | Essential choices & Person/Thing pronouns",
    category: "Relative Clauses",
    levelTag: "Core + requested expansion",
    englishRules: [
      "What does a relative clause do? It identifies a noun or adds information about it.",
      "A finite relative clause contains a finite verb. The relative word may be a subject, an object, a possessive form or a relative adverb.",
      "People (who / whom): Subject: 'The student who leads the group is here.' Object: 'The student whom I helped thanked me.' In everyday English, who is also used as an object. That is possible in defining clauses about people.",
      "Things (which / that): 'The app which reminds me to rest is useful.' 'The app that I use is free.' Which works in defining and non-defining clauses; that works in defining clauses."
    ],
    arabicRules: [
      "جملة الوصل تصف اسما. حدد أولا: هل الكلمة الناقصة فاعل أم مفعول أم ملكية أم مكان؟",
      "نستخدم ضمير الفاعل إذا كان هو الذي يقوم بالفعل. ويأتي بعد ضمير المفعول عادة فاعل آخر.",
      "نستخدم الأداة المناسبة للشيء، مع مراعاة نوع جملة الوصل."
    ],
    examples: [
      { en: "The student who leads the group is here.", note: "Subject pronoun for person" },
      { en: "The student whom I helped thanked me.", note: "Object pronoun for person" },
      { en: "The app that I use is free.", note: "Defining clause for things" }
    ]
  },
  {
    id: "GRAM-43",
    title: "Possession, Agreement & Defining vs Non-defining clauses",
    category: "Relative Clauses",
    levelTag: "Core + requested expansion",
    englishRules: [
      "Possession: whose + noun. 'The girl whose brother joined us is new.' 'The school whose roof was repaired reopened.' Whose can refer to people, animals or things. Do not add his, her or its after whose.",
      "Agreement: 'The student who knows...' / 'The students who know...'. Match the relative-clause verb to the noun described.",
      "Defining clauses (identify a group, no commas): 'Students who need help can stay.' The clause selects the students needing help; it is necessary to the intended identification.",
      "Non-defining clauses (add extra information, commas): 'Mona, who lives nearby, walks to school.' 'Our library, which opens at nine, is quiet.' Use two commas if inserted in the middle. Do not use that or omit the relative word in a non-defining clause."
    ],
    arabicRules: [
      "للملكية، ويتبعها الاسم المملوك مباشرة. لا نكرر صفة الملكية بعدها.",
      "طابق الفعل مع الاسم الذي يصفه ضمير الوصل: مفرد أو جمع.",
      "الجملة المحددة تختار شخصا أو مجموعة بعينها، ولذلك لا نفصلها بفواصل.",
      "المعلومة الإضافية تحاط بفاصلتين إذا وقعت وسط الجملة. لا نحذف الأداة هنا."
    ],
    examples: [
      { en: "The girl whose brother joined us is new.", note: "Whose replaces her" },
      { en: "Mona, who lives nearby, walks to school.", note: "Non-defining clause with commas" }
    ]
  },
  {
    id: "GRAM-44",
    title: "Omission, Repetition errors & That vs What",
    category: "Relative Clauses",
    levelTag: "Core + requested expansion",
    englishRules: [
      "Omit an object, not a subject: 'The book (which / that) I read was useful.' 'The student (who / whom / that) I met was kind.' But: 'The student who won smiled.' You cannot simply delete subject who.",
      "Do not repeat the same role: Correct: 'The film which I watched was useful.' Incorrect: 'The film which I watched it was useful.' But a pronoun in a different clause can be necessary: 'The woman to whom I sent the email replied to it.'",
      "That / what: After a noun, use a relative clause: 'the thing that I need.' What can mean the thing that without a preceding noun: 'What I need is time.' Avoid: 'the thing what I need.'"
    ],
    arabicRules: [
      "يمكن حذف ضمير المفعول في الجملة المحددة. لا تخلط بين الحذف واختصار الجملة إلى اسم فاعل.",
      "احذف الضمير المكرر داخل جملة الوصل فقط، ولا تحذف كل ضمير في الجملة بشكل آلي.",
      "الأداة التي تعني ما نحتاجه تأتي إما كاسم موصول بعد اسم أو كاسم موصول حر (what)."
    ],
    examples: [
      { en: "The article I read was useful.", note: "Object relative pronoun omitted" },
      { en: "What I need is time.", note: "What = the thing that (no preceding noun)" }
    ]
  },
  {
    id: "GRAM-45",
    title: "Relative adverbs (Where, When, Why) & Preposition placement",
    category: "Relative Clauses",
    levelTag: "Requested expansion",
    englishRules: [
      "Where / when / why: 'The room where we meet = the room in which we meet.' 'The day when we met = the day on which we met.' 'The reason why she left = the reason for which she left (formal).' These are relative adverbs.",
      "Place name does not automatically mean where: 'The museum which we visited was new' (visited needs an object). 'The museum where we met was new' (where supplies the place of meeting).",
      "Everyday position (preposition at the end): 'The person who / whom / that I spoke to helped me.' 'The topic which / that we talked about was difficult.'",
      "Formal position (preposition before the pronoun): 'The person to whom I spoke...' / 'The topic about which we spoke...'. Use whom for people and which for things. Do not use that or omit the pronoun immediately after a fronted preposition."
    ],
    arabicRules: [
      "اختر حرف الجر من معنى الجملة، وليس من حفظ ترجمة ثابتة للأداة.",
      "وجود مكان قبل الفراغ لا يكفي. اسأل: هل الفعل يحتاج مفعولا به أم ظرف مكان؟",
      "يمكن بقاء حرف الجر في نهاية جملة الوصل، ويجوز حذف ضمير المفعول في الجملة المحددة.",
      "إذا نقلنا حرف الجر قبل الضمير نستخدم الصيغة الرسمية المناسبة، ولا نحذف الضمير."
    ],
    examples: [
      { en: "The museum which we visited was new.", note: "Visited needs direct object -> which" },
      { en: "The museum where we met was new.", note: "Where = in which" },
      { en: "The person to whom I spoke helped me.", note: "Fronted preposition + whom" }
    ]
  },
  {
    id: "GRAM-46",
    title: "Preposition choice, Quantities & Whole-sentence comments",
    category: "Relative Clauses",
    levelTag: "Extension",
    englishRules: [
      "Select the correct preposition: speak to a person -> to whom; work with a person -> with whom; depend on a method -> on which; study in a school -> in which.",
      "Quantities: 'I met five students, two of whom were new.' 'I read three reports, all of which were useful.' Use a comma and of whom / of which.",
      "Comment on an entire event: 'She checked the figures, which improved the report.' Which refers to the whole previous event. Do not replace it with that here.",
      "Preposition + whose + noun: 'The writer in whose book I found the example explained it clearly.' Whose still expresses possession."
    ],
    arabicRules: [
      "ارجع إلى تركيب الفعل وحرف الجر أولا، ثم كون جملة الوصل.",
      "مع الأعداد والكميات يمكن استخدام الصيغة التي تعني عددا منهم: two of whom / all of which.",
      "قد تشير أداة الوصل إلى مضمون الجملة السابقة كله، وليس إلى اسم واحد.",
      "يمكن أن يسبق حرف الجر تركيب الملكية، ويظل الاسم بعد أداة الملكية لازما."
    ],
    examples: [
      { en: "She checked the figures, which improved the report.", note: "Which refers to entire clause" },
      { en: "Five students spoke, two of whom disagreed.", note: "two of whom" }
    ]
  },
  {
    id: "GRAM-47",
    title: "Participles: Active (-ing) vs Passive (-ed) meaning & Reduction",
    category: "Participles",
    levelTag: "Core",
    englishRules: [
      "After all, everything, the only and superlatives: That is often preferred in defining clauses: 'Everything that I need is here.' 'This is the best book that I have read.'",
      "Five checks before you answer: 1 Identify the noun. 2 Identify the missing role. 3 Check commas. 4 Check any preposition. 5 Check agreement and repeated pronouns.",
      "Active meaning (-ing): 'The pupils who are waiting -> the pupils waiting.' 'The student carrying a bag is Salma.' The noun performs the action. An -ing participle does not by itself indicate present time.",
      "Passive meaning (past participle): 'The report which was written yesterday -> the report written yesterday.' The noun receives the action. Past participles include irregular forms: written, given, seen, built."
    ],
    arabicRules: [
      "هناك استخدامات شائعة وتفضيلات أسلوبية؛ لا نحولها إلى قاعدة منع مطلقة.",
      "طبق الخطوات على المعنى، ثم راجع شكل الجملة.",
      "اسم الفاعل يوضح أن الاسم يقوم بالفعل؛ زمن الجملة يفهم من السياق.",
      "اسم المفعول يوضح أن الاسم وقع عليه الفعل، وليس شرطا أن ينتهي بالحرفين المعتادين."
    ],
    examples: [
      { en: "The pupils waiting outside are ready.", note: "Active reduction of who are waiting" },
      { en: "The report written yesterday is clear.", note: "Passive reduction of which was written" }
    ]
  },
  {
    id: "GRAM-48",
    title: "Safe Participial Reduction & Passive in Progress",
    category: "Participles",
    levelTag: "Core + extension",
    englishRules: [
      "Reduction requires care: Only a subject relative clause is a candidate for this kind of participial reduction. 'The book that I bought' -> 'the book I bought' is object-pronoun omission, not a change to buying.",
      "Keep the meaning: Do not mechanically change every finite verb to -ing. A specific completed event, a state, or a modal meaning may be lost. Keep: 'The girl who won yesterday...' / 'Students who must submit forms...'.",
      "Passive in progress: 'The bridge which is being repaired -> the bridge being repaired.' Compare: 'the bridge repaired last year', which describes completed work.",
      "Opening participial phrases: Same subject; then a comma. 'Feeling tired, Mona rested.' Mona feels tired and Mona rests. 'Worried by the news, Ali called home.' Ali receives the worry."
    ],
    arabicRules: [
      "حدد وظيفة ضمير الوصل قبل الاختصار. ضمير المفعول لا يتحول بهذه الطريقة إلى اسم فاعل.",
      "إذا تغير الزمن أو المعنى أو دلالة الإلزام، احتفظ بجملة الوصل الكاملة.",
      "الصيغة المستمرة المبنية للمجهول تختلف عن وصف فعل تم وانتهى.",
      "الفاعل في الجملة الرئيسية هو نفسه المقصود بالعبارة الافتتاحية، وبعدها فاصلة."
    ],
    examples: [
      { en: "The bridge being repaired is closed.", note: "Action in progress passive" },
      { en: "Feeling tired, Omar took a short break.", note: "Shared subject introductory participle" }
    ]
  },
  {
    id: "GRAM-49",
    title: "Dangling participles, Perfect participles & Negative placement",
    category: "Participles",
    levelTag: "Core + extension",
    englishRules: [
      "Repair a dangling participle: Incorrect: 'Walking home, the rain began.' Correct: 'Walking home, I noticed the rain.' Or: 'While I was walking home, the rain began.'",
      "Earlier completed action (perfect participle): 'Having checked the source, she revised her claim.' Form: having + past participle. The checking happened before the revision.",
      "Earlier passive action: 'Having been approved, the plan was published.' Form: having been + past participle. The plan receives approval and publication.",
      "Negative and placement: 'Not knowing the answer, he asked.' Place a modifying phrase close to the noun it describes."
    ],
    arabicRules: [
      "إذا اختلف الفاعل استخدم جملة كاملة حتى لا يبدو أن المطر هو الذي يمشي.",
      "لبيان أن فعلا اكتمل قبل فعل آخر نستخدم الصيغة التامة: having + p.p.",
      "في التام المبني للمجهول يكون الاسم قد وقع عليه الفعل الأول: having been + p.p.",
      "ضع النفي بوضوح (Not knowing)، واجعل العبارة قريبة من الاسم المقصود لتجنب اللبس."
    ],
    examples: [
      { en: "Walking to school, I saw a bus.", note: "Subject 'I' walks and sees" },
      { en: "Having checked the data, Omar wrote the conclusion.", note: "Earlier active completed action" }
    ]
  },
  {
    id: "GRAM-50",
    title: "Conditionals: Zero, First, Second & Third conditionals",
    category: "Conditionals",
    levelTag: "Core + foundation review",
    englishRules: [
      "Zero conditional (general situations and habits): If + present, present: 'If I need a word, I use a dictionary.' Describes a regular pattern.",
      "First conditional (a possible future): If + present, will / can / may / might + base verb: 'If the club opens, I will join.' 'If the service improves, some pupils may benefit.' An imperative is possible: 'If you need help, ask.'",
      "Second conditional (hypothetical present or future): If + past, would / could / might + base verb: 'If I had more time, I could volunteer.' 'If I were you, I would check.' Were is the conventional formal choice in hypothetical advice.",
      "Third conditional (an alternative past): If + had + past participle, would / could / might have + past participle: 'If she had called, I would have helped.'"
    ],
    arabicRules: [
      "الصفرية تصف عادة أو علاقة عامة: مضارع + مضارع.",
      "الأولى لاحتمال حقيقي في المستقبل: مضارع + will/can/may.",
      "الماضي هنا يعبر عن الافتراض (الثانية)، وليس بالضرورة عن زمن ماض: past + would/could.",
      "الثالثة تتخيل ماضيا مختلفا عن الذي حدث: had + p.p. + would have + p.p."
    ],
    examples: [
      { en: "If I need a definition, I use a dictionary.", note: "Zero: habitual" },
      { en: "If I were you, I would check the source.", note: "Second: hypothetical advice" },
      { en: "If she had called, I would have helped.", note: "Third: unreal past" }
    ]
  },
  {
    id: "GRAM-51",
    title: "Punctuation, Future time clauses & Alternatives (Unless, Provided that, In case)",
    category: "Conditionals",
    levelTag: "Supporting practice",
    englishRules: [
      "Punctuation and future time: Use a comma when the if-clause comes first. Future time clauses normally use a present form: 'I will call when / as soon as I arrive.'",
      "Unless: 'Unless you hurry, you will miss the bus' = 'If you do not hurry, you will miss the bus.' Do not add not automatically.",
      "Provided that / as long as / on condition that: 'You may borrow it provided that you return it.' These introduce a required condition and are followed by a clause.",
      "If versus in case: 'I will call if I need help' (the call depends on the need). 'I will save your number in case I need help' (preparation happens first). 'In case of + noun': 'In case of fire, use the stairs.'"
    ],
    arabicRules: [
      "راجع الفاصلة إذا بدأت بالشرط، واستخدم المضارع بعد أدوات الزمن المستقبلية في النمط المعتاد.",
      "راجع المعنى بعد الاستبدال ولا تضف نفيا زائدا: unless = if not.",
      "هذه أدوات شرط يتبعها فاعل وفعل: provided that / as long as.",
      "فرق بين الشرط والاحتياط (in case). الصيغة التي تنتهي بحرف الجر يتبعها اسم: in case of."
    ],
    examples: [
      { en: "Unless you hurry, you will miss the bus.", note: "Unless = if not" },
      { en: "I will save a copy in case the file gets deleted.", note: "In case = precaution" },
      { en: "In case of fire, use the stairs.", note: "In case of + noun" }
    ]
  },
  {
    id: "GRAM-52",
    title: "Without / But for & Hedging with modals",
    category: "Conditionals",
    levelTag: "Supporting practice",
    englishRules: [
      "Without / but for: 'Without your support, I would struggle.' 'But for your support last year, I would have stopped.' The context determines present or past counterfactual meaning.",
      "Hedging is part of the lesson: 'If schools offered more support, some pupils might feel less isolated.' May, might and could keep a claim proportionate to the evidence. Do not invent a study to make writing sound academic."
    ],
    arabicRules: [
      "الزمن يتحدد من السياق، ولا نساوي هذه التراكيب دائما بأداة شرط واحدة.",
      "اللغة الحذرة جزء أساسي من الوحدة. ادعم الرأي بدليل متاح، ولا تخترع مصدرا."
    ],
    examples: [
      { en: "But for your encouragement, I would have stopped.", note: "Counterfactual past with noun phrase" },
      { en: "If access improved, participation might increase.", note: "Cautious hedging with might" }
    ]
  },
  {
    id: "GRAM-53",
    title: "Advanced Inversion (Should, Were, Had) & Mixed Conditionals",
    category: "Conditionals",
    levelTag: "Advanced extension",
    englishRules: [
      "Should inversion: 'If you should need help -> Should you need help, contact us.' Use should + subject + base verb. Formal possible condition.",
      "Were inversion: 'If I were you -> Were I you...'. 'If she were to accept -> Were she to accept...'. With an action verb, preserve to + base verb.",
      "Had inversion: 'If they had checked -> Had they checked...'. Negative: 'Had they not checked...'. Teach past-perfect inversion as the main pattern.",
      "Mixed (past cause, present result): 'If I had slept earlier last night, I would be less tired now.'",
      "Mixed (present trait, past result): 'If he were more careful in general, he might not have made that error yesterday.'"
    ],
    arabicRules: [
      "القلب هنا أسلوب رسمي لاحتمال وارد: Should + فاعل + مصدر.",
      "لاحظ الفرق بين الخبر بعد الفعل وبين صيغة الفعل المسبوق بأداة المصدر: Were she to accept.",
      "التركيز الأساسي هنا على الماضي التام، مع وضع النفي بعد الفاعل: Had they checked.",
      "قد يختلف زمن الشرط عن زمن النتيجة؛ ابحث عن كلمات الزمن وحدد علاقة المعنى."
    ],
    examples: [
      { en: "Should you need further information, contact the office.", note: "Should inversion" },
      { en: "Were I in your position, I would ask for evidence.", note: "Were inversion" },
      { en: "Had they checked the figures, they would have found the error.", note: "Had inversion" },
      { en: "If I had slept earlier last night, I would be less tired now.", note: "Mixed conditional" }
    ]
  }
];

export const SHARED_TASKS = {
  writingPrompt: "To what extent should schools share responsibility for student well-being?",
  writingTargetWords: "150-180 words",
  writingRequirements: [
    "State a clear judgment on school responsibility.",
    "Give reasons supported by evidence from reading passages (e.g. A1, B2).",
    "Consider a counterargument (e.g. personal willpower/agency).",
    "Acknowledge a limit to the evidence (association is not causation).",
    "Use at least one relative clause and one conditional structure naturally."
  ],
  modelParagraph: "Schools should share responsibility for young people's well-being, although students also need opportunities to make their own decisions. Personal effort matters because habits are influenced by repeated choices, including how learners organise their time and seek support. However, advice alone may be insufficient when the surrounding conditions make a choice difficult. The reading on responsibility gives the example of teenagers who lack safe parks or affordable sports facilities. This example suggests that motivation cannot remove every practical barrier. Schools could respond by offering accessible activities and listening to students about the support they need. Such action would expand choices rather than guarantee identical results for everyone. Some people may argue that this approach weakens personal responsibility, but providing an opportunity does not force a student to use it. If schools and families worked together, more learners might be able to turn intentions into realistic routines. Overall, well-being is better understood as a shared task in which individual agency and supportive conditions reinforce each other.",
  mediaPostToEvaluate: {
    text: "My brilliant study routine works for everyone. I never waste a minute. Who would choose to fail? Follow my plan and you will always succeed.",
    tasks: [
      "Identify evaluative language (e.g., 'brilliant').",
      "Identify absolutes (e.g., 'works for everyone', 'never waste a minute', 'always succeed').",
      "Identify the rhetorical question ('Who would choose to fail?').",
      "Rewrite the post cautiously using hedging (e.g., 'This routine may help some students...')."
    ]
  },
  translationSentences: [
    { id: 1, direction: 'en-to-ar', text: "Schools can help students make informed choices.", model: "يمكن للمدارس مساعدة الطلاب على اتخاذ خيارات واعية." },
    { id: 2, direction: 'en-to-ar', text: "The student whose project won thanked her team.", model: "شكرت الطالبة التي فاز مشروعها فريقها." },
    { id: 3, direction: 'en-to-ar', text: "If we had checked the source, we would have noticed the error.", model: "لو كنا راجعنا المصدر، لكنا لاحظنا الخطأ." },
    { id: 4, direction: 'en-to-ar', text: "Some online posts may give an incomplete picture of daily life.", model: "قد تعطي بعض المنشورات على الإنترنت صورة غير مكتملة عن الحياة اليومية." },
    { id: 5, direction: 'en-to-ar', text: "Having read the report, Mona asked for more evidence.", model: "بعد قراءة التقرير، طلبت منى مزيداً من الأدلة." },
    { id: 6, direction: 'ar-to-en', text: "يحتاج هذا الادعاء إلى دليل واضح", model: "This claim needs clear evidence." },
    { id: 7, direction: 'ar-to-en', text: "هذه هي المكتبة التي نذاكر فيها", model: "This is the library where we study." },
    { id: 8, direction: 'ar-to-en', text: "إذا تحسنت الخدمات، فقد يستفيد بعض الطلاب", model: "If services improve, some students may benefit." },
    { id: 9, direction: 'ar-to-en', text: "التقرير الذي كتبته سلمى مفيد", model: "The report written by Salma is useful." },
    { id: 10, direction: 'ar-to-en', text: "يمكن أن تختلف احتياجات الدعم من طالب إلى آخر", model: "Support needs can vary from one student to another." }
  ]
};
