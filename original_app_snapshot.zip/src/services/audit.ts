import { UNIT_1_VOCABULARY } from '../data/vocabulary';
import { STORY_VOCABULARY_59 } from '../data/storyLexicon';
import { ALL_330_QUESTIONS, BANK_METADATA } from '../data/questions';
import { AUDIO_ITEMS } from '../data/audio';
import { READING_PASSAGES, GRAMMAR_REFERENCES } from '../data/references';
import { getTeacherApprovals, getTeacherCorrections } from './storage';

export interface AuditReport {
  timestamp: string;
  primaryVocabularyCount: number;
  expectedPrimaryVocabularyCount: 66;
  storyLexiconCount: number;
  expectedStoryLexiconCount: 59;
  totalQuestionsCount: number;
  expectedQuestionsCount: 330;
  bankCounts: Record<string, number>;
  expectedBankCount: 11;
  deterministicChoiceCount: number;
  expectedDeterministicChoiceCount: 169;
  guidedExactMatchCount: number;
  expectedGuidedExactMatchCount: 9;
  teacherReviewCount: number;
  expectedTeacherReviewCount: 152;
  duplicateQuestionIds: string[];
  duplicateVocabIds: string[];
  missingAnswerQuestions: string[];
  missingPassageReferences: string[];
  missingGrammarReferences: string[];
  audioFilesCount: number;
  audioItems: Array<{ id: string; filename: string; transcriptWords: number }>;
  teacherApprovedCount: number;
  teacherPendingApprovalCount: number;
  correctionsCount: number;
  isValid: boolean;
}

export function runImportAudit(): AuditReport {
  const approvals = getTeacherApprovals();
  const corrections = getTeacherCorrections();

  // Check vocab duplicates
  const vocabIdsSeen = new Set<string>();
  const duplicateVocabIds: string[] = [];
  UNIT_1_VOCABULARY.forEach(v => {
    if (vocabIdsSeen.has(v.id)) {
      duplicateVocabIds.push(v.id);
    }
    vocabIdsSeen.add(v.id);
  });

  // Check question duplicates & missing answers
  const qIdsSeen = new Set<string>();
  const duplicateQuestionIds: string[] = [];
  const missingAnswerQuestions: string[] = [];
  const missingPassageReferences: string[] = [];
  const missingGrammarReferences: string[] = [];

  const bankCounts: Record<string, number> = {};
  let deterministicCount = 0;
  let exactMatchCount = 0;
  let teacherReviewCount = 0;
  let approvedCount = 0;

  const validPassageIds = new Set(READING_PASSAGES.map(p => p.id));
  const validGrammarIds = new Set(GRAMMAR_REFERENCES.map(g => g.id));

  ALL_330_QUESTIONS.forEach(q => {
    // Duplicates
    if (qIdsSeen.has(q.id)) {
      duplicateQuestionIds.push(q.id);
    }
    qIdsSeen.add(q.id);

    // Bank counts
    bankCounts[q.bankId] = (bankCounts[q.bankId] || 0) + 1;

    // Missing answers
    if (!q.sourceAnswer || q.sourceAnswer.trim() === '') {
      missingAnswerQuestions.push(q.id);
    }

    // Grading counts
    if (q.grading === 'deterministic_choice') deterministicCount++;
    else if (q.grading === 'guided_exact_match') exactMatchCount++;
    else if (q.grading === 'teacher_review') teacherReviewCount++;

    // Approvals
    if (approvals[q.id]) {
      approvedCount++;
    }

    // Check references
    if (q.relatedPassageId && !validPassageIds.has(q.relatedPassageId)) {
      missingPassageReferences.push(`${q.id} -> ${q.relatedPassageId}`);
    }
    if (q.relatedGrammarId && !validGrammarIds.has(q.relatedGrammarId)) {
      missingGrammarReferences.push(`${q.id} -> ${q.relatedGrammarId}`);
    }
  });

  const audioSummary = AUDIO_ITEMS.map(a => ({
    id: a.id,
    filename: a.filename,
    transcriptWords: a.transcript.split(/\s+/).length
  }));

  const isValid =
    UNIT_1_VOCABULARY.length === 66 &&
    STORY_VOCABULARY_59.length === 59 &&
    ALL_330_QUESTIONS.length === 330 &&
    duplicateQuestionIds.length === 0 &&
    duplicateVocabIds.length === 0 &&
    missingAnswerQuestions.length === 0 &&
    AUDIO_ITEMS.length === 2 &&
    deterministicCount === 169 &&
    exactMatchCount === 9 &&
    teacherReviewCount === 152;

  return {
    timestamp: new Date().toISOString(),
    primaryVocabularyCount: UNIT_1_VOCABULARY.length,
    expectedPrimaryVocabularyCount: 66,
    storyLexiconCount: STORY_VOCABULARY_59.length,
    expectedStoryLexiconCount: 59,
    totalQuestionsCount: ALL_330_QUESTIONS.length,
    expectedQuestionsCount: 330,
    bankCounts,
    expectedBankCount: 11,
    deterministicChoiceCount: deterministicCount,
    expectedDeterministicChoiceCount: 169,
    guidedExactMatchCount: exactMatchCount,
    expectedGuidedExactMatchCount: 9,
    teacherReviewCount: teacherReviewCount,
    expectedTeacherReviewCount: 152,
    duplicateQuestionIds,
    duplicateVocabIds,
    missingAnswerQuestions,
    missingPassageReferences,
    missingGrammarReferences,
    audioFilesCount: AUDIO_ITEMS.length,
    audioItems: audioSummary,
    teacherApprovedCount: approvedCount,
    teacherPendingApprovalCount: ALL_330_QUESTIONS.length - approvedCount,
    correctionsCount: Object.keys(corrections).length,
    isValid
  };
}
