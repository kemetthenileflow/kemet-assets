import { StudentAttempt, WordProgress, ReportJob, QuestionItem } from '../types';
import { ALL_330_QUESTIONS } from '../data/questions';
import { UNIT_1_VOCABULARY } from '../data/vocabulary';
import { STORY_VOCABULARY_59 } from '../data/storyLexicon';
import { AUDIO_ITEMS } from '../data/audio';

const STORAGE_KEYS = {
  ATTEMPTS: 'kemet_student_attempts_v1',
  WORD_PROGRESS: 'kemet_word_progress_v1',
  TEACHER_APPROVALS: 'kemet_teacher_approvals_v1',
  TEACHER_CORRECTIONS: 'kemet_teacher_corrections_v1',
  TEACHER_REVIEWS: 'kemet_teacher_reviews_v1',
  USER_PROFILE: 'kemet_user_profile_v1',
  REPORT_JOBS: 'kemet_report_jobs_v1',
  CURRENT_LANGUAGE: 'kemet_lang_v1'
};

// Resilient memory cache fallback if localStorage is restricted inside iframes
const memoryStore = new Map<string, string>();

function safeGetItem(key: string): string | null {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const val = window.localStorage.getItem(key);
      if (val !== null) return val;
    }
  } catch {
    // Access denied / restricted iframe sandbox
  }
  return memoryStore.get(key) || null;
}

function safeSetItem(key: string, value: string): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(key, value);
    }
  } catch {
    // Access denied / restricted iframe sandbox
  }
  memoryStore.set(key, value);
}

export interface LocalUserProfile {
  uid: string;
  displayName: string;
  role: 'student' | 'teacher';
  email?: string;
  isSynced: boolean;
  joinedAt: string;
}

export function getLocalUserProfile(): LocalUserProfile {
  const raw = safeGetItem(STORAGE_KEYS.USER_PROFILE);
  if (raw) {
    try {
      return JSON.parse(raw);
    } catch {
      // fallback
    }
  }
  const defaultProfile: LocalUserProfile = {
    uid: 'local-user-' + Math.random().toString(36).substring(2, 9),
    displayName: 'Student Learner',
    role: 'student',
    email: '',
    isSynced: false,
    joinedAt: new Date().toISOString()
  };
  safeSetItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(defaultProfile));
  return defaultProfile;
}

export function saveLocalUserProfile(profile: LocalUserProfile) {
  safeSetItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
}

export function getStoredAttempts(): StudentAttempt[] {
  const raw = safeGetItem(STORAGE_KEYS.ATTEMPTS);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveAttempt(attempt: StudentAttempt): { isNew: boolean } {
  const attempts = getStoredAttempts();
  // Idempotency: check if attempt with exact same id exists
  const existingIndex = attempts.findIndex(a => a.id === attempt.id);
  if (existingIndex >= 0) {
    attempts[existingIndex] = attempt;
    safeSetItem(STORAGE_KEYS.ATTEMPTS, JSON.stringify(attempts));
    return { isNew: false };
  } else {
    attempts.push(attempt);
    safeSetItem(STORAGE_KEYS.ATTEMPTS, JSON.stringify(attempts));
    return { isNew: true };
  }
}

export function getWordProgress(): Record<string, WordProgress> {
  const raw = safeGetItem(STORAGE_KEYS.WORD_PROGRESS);
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

export function updateWordProgress(vocabId: string, updater: (prev: WordProgress) => WordProgress) {
  const map = getWordProgress();
  const current = map[vocabId] || {
    vocabularyId: vocabId,
    status: 'New',
    revealsCount: 0,
    arabicRevealsCount: 0,
    typingAttempts: 0,
    successfulTypingCount: 0
  };
  map[vocabId] = updater(current);
  safeSetItem(STORAGE_KEYS.WORD_PROGRESS, JSON.stringify(map));
  return map[vocabId];
}

export function getTeacherApprovals(): Record<string, boolean> {
  const raw = safeGetItem(STORAGE_KEYS.TEACHER_APPROVALS);
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

export function setTeacherApproval(questionId: string, approved: boolean) {
  const approvals = getTeacherApprovals();
  approvals[questionId] = approved;
  safeSetItem(STORAGE_KEYS.TEACHER_APPROVALS, JSON.stringify(approvals));
}

export function approveAllQuestions() {
  const approvals: Record<string, boolean> = {};
  ALL_330_QUESTIONS.forEach(q => {
    approvals[q.id] = true;
  });
  safeSetItem(STORAGE_KEYS.TEACHER_APPROVALS, JSON.stringify(approvals));
}

export interface QuestionCorrection {
  questionId: string;
  version: number;
  correctedAnswer: string;
  rationale: string;
  updatedAt: string;
}

export function getTeacherCorrections(): Record<string, QuestionCorrection> {
  const raw = safeGetItem(STORAGE_KEYS.TEACHER_CORRECTIONS);
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

export function saveTeacherCorrection(correction: QuestionCorrection) {
  const corrections = getTeacherCorrections();
  corrections[correction.questionId] = correction;
  safeSetItem(STORAGE_KEYS.TEACHER_CORRECTIONS, JSON.stringify(corrections));
}

export function getStoredReportJobs(): ReportJob[] {
  const raw = safeGetItem(STORAGE_KEYS.REPORT_JOBS);
  if (!raw) {
    const initialJob: ReportJob = {
      id: 'job-default',
      recipientEmail: 'Kemetthenileflow@gmail.com',
      scheduledTime: '21:00 Daily',
      status: 'Not configured',
      timezone: 'Africa/Cairo',
      learnerCount: 0,
      objectiveNumerator: 0,
      objectiveDenominator: 0,
      pendingReviewsCount: 0,
      lastProviderResponse: 'Email service adapter not configured. Real sends require verified provider.'
    };
    safeSetItem(STORAGE_KEYS.REPORT_JOBS, JSON.stringify([initialJob]));
    return [initialJob];
  }
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveReportJob(job: ReportJob) {
  const jobs = getStoredReportJobs();
  const idx = jobs.findIndex(j => j.id === job.id);
  if (idx >= 0) {
    jobs[idx] = job;
  } else {
    jobs.unshift(job);
  }
  safeSetItem(STORAGE_KEYS.REPORT_JOBS, JSON.stringify(jobs));
}

/**
 * Formula injection sanitizer for CSV exports
 * Escapes characters =, +, -, @, tab, return with single quote
 */
export function sanitizeForCSV(val: string | number | undefined | null): string {
  if (val === undefined || val === null) return '';
  const str = String(val).trim();
  if (/^[=+\-@\t\r]/.test(str)) {
    return `'${str.replace(/"/g, '""')}`;
  }
  return str.replace(/"/g, '""');
}

export function exportAttemptsToCSV(attempts: StudentAttempt[]): string {
  const headers = [
    'Attempt ID',
    'Student UID',
    'Student Name',
    'Question or Vocab ID',
    'Bank/Mode',
    'Difficulty Route',
    'First Response',
    'Submitted Response',
    'Objective Outcome',
    'First Attempt (Single Count)',
    'Hint Count',
    'Reveal Used',
    'Transcript Used',
    'Active Duration (s)',
    'Teacher Review Status',
    'Teacher Score',
    'Teacher Feedback',
    'Submitted At (Cairo Time)'
  ];

  const rows = attempts.map(att => {
    const durationSec = Math.round(att.activeDurationMs / 1000);
    const cairoTime = new Date(att.submittedAt).toLocaleString('en-US', { timeZone: 'Africa/Cairo' });
    return [
      `"${sanitizeForCSV(att.id)}"`,
      `"${sanitizeForCSV(att.uid)}"`,
      `"${sanitizeForCSV(att.studentName)}"`,
      `"${sanitizeForCSV(att.questionId || att.vocabularyId || '')}"`,
      `"${sanitizeForCSV(att.gameMode)}"`,
      `"${sanitizeForCSV(att.difficultyRoute)}"`,
      `"${sanitizeForCSV(att.firstResponse)}"`,
      `"${sanitizeForCSV(att.submittedResponse)}"`,
      `"${sanitizeForCSV(att.objectiveOutcome || 'n/a')}"`,
      `"${att.isFirstAttempt ? 'Yes' : 'No'}"`,
      `"${att.hintCount}"`,
      `"${att.revealUsed ? 'Yes' : 'No'}"`,
      `"${att.transcriptUsed ? 'Yes' : 'No'}"`,
      `"${durationSec}"`,
      `"${sanitizeForCSV(att.teacherReviewStatus)}"`,
      `"${att.teacherRubricScore !== undefined ? att.teacherRubricScore : ''}"`,
      `"${sanitizeForCSV(att.teacherFeedback || '')}"`,
      `"${sanitizeForCSV(cairoTime)}"`
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\r\n');
}
