export type DifficultyLevel = 'Foundation' | 'Apply' | 'Challenge' | 'Supported practice';

export type GradingType = 'deterministic_choice' | 'guided_exact_match' | 'teacher_review';

export interface VocabularyItem {
  id: string; // VOC-001 ... VOC-066
  word: string;
  englishMeaning: string;
  arabicMeaning: string;
  partOfSpeech: string;
  ipa: string;
  example: string;
  synonym: string;
  antonymContrast: string;
  groupIndex: number; // 0..10 (6 words per group)
  teacherApproved?: boolean;
}

export interface StoryVocabularyItem {
  id: string; // STORY-VOC-001 ... STORY-VOC-059
  word: string;
  meaning: string;
  storyContext: string;
  sourcePdfPage: number;
}

export interface QuestionOption {
  id: string; // 'A', 'B', 'C', 'D'
  text: string;
}

export interface QuestionItem {
  id: string; // V1-01 ... N1-30
  bankId: 'V1' | 'V2' | 'R1' | 'R2' | 'P1' | 'C1' | 'C2' | 'S1' | 'L1' | 'D1' | 'N1';
  level: DifficultyLevel;
  prompt: string;
  options?: QuestionOption[];
  sourceAnswer: string;
  correctOptionId?: string;
  explanation: string;
  grading: GradingType;
  relatedPassageId?: string; // 'A1', 'A2', 'A3', 'B1', 'B2', 'B3', 'STORY-CH1'
  relatedGrammarId?: string; // 'GRAM-42' ... 'GRAM-53'
  relatedAudioId?: string; // 'REC-01', 'REC-04'
  approvedByTeacher?: boolean;
  teacherCorrection?: {
    version: number;
    correctedAnswer: string;
    rationale: string;
    updatedAt: string;
  };
}

export interface ReadingPassage {
  id: string;
  title: string;
  cluster: 'A' | 'B' | 'STORY';
  paragraphs: string[];
  disclaimer?: string;
}

export interface GrammarReference {
  id: string; // GRAM-42 ... GRAM-53
  title: string;
  category: 'Relative Clauses' | 'Participles' | 'Conditionals';
  levelTag: string;
  englishRules: string[];
  arabicRules: string[];
  examples: Array<{ en: string; note?: string }>;
}

export interface AudioItem {
  id: 'REC-01' | 'REC-04';
  title: string;
  filename: string;
  durationSeconds: number;
  transcript: string;
  speaker: string;
  disclaimer: string;
}

export type WordRecallStatus = 'New' | 'Practising' | 'Recall confirmed' | 'Review due';

export interface WordProgress {
  vocabularyId: string;
  status: WordRecallStatus;
  revealsCount: number;
  arabicRevealsCount: number;
  typingAttempts: number;
  successfulTypingCount: number;
  lastPractisedAt?: string;
  nextReviewAt?: string;
}

export interface StudentAttempt {
  id: string;
  uid: string;
  studentName: string;
  sessionId: string;
  contentVersion: string;
  questionId?: string;
  vocabularyId?: string;
  gameMode: string;
  difficultyRoute: DifficultyLevel;
  firstResponse: string;
  submittedResponse: string;
  submittedAt: string;
  objectiveOutcome?: 'correct' | 'incorrect' | 'pending';
  isFirstAttempt: boolean;
  hintCount: number;
  revealUsed: boolean;
  transcriptUsed: boolean;
  retryCount: number;
  activeDurationMs: number;
  selectedEvidence?: string;
  teacherReviewStatus: 'none' | 'pending' | 'reviewed';
  teacherRubricScore?: number;
  teacherFeedback?: string;
}

export interface ReportJob {
  id: string;
  recipientEmail: string;
  scheduledTime: string;
  status: 'Not configured' | 'Ready' | 'Queued' | 'Sent' | 'Failed';
  timezone: string; // 'Africa/Cairo'
  learnerCount: number;
  objectiveNumerator: number;
  objectiveDenominator: number;
  pendingReviewsCount: number;
  lastProviderResponse?: string;
}
