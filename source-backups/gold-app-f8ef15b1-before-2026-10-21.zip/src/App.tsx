import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { DesignSystemStyleGuide } from './components/DesignSystemStyleGuide';
import { HieroglyphDecipherer } from './components/HieroglyphDecipherer';
import { RoyalCartoucheCreator } from './components/RoyalCartoucheCreator';
import { ScribeAcademy } from './components/ScribeAcademy';
import { ArtifactGallery } from './components/ArtifactGallery';
import { KemetButton } from './components/ui/KemetButton';
import { ScarabIcon, AnkhIcon, EyeOfHorusIcon, CartoucheIcon, PapyrusScrollIcon } from './components/ui/EgyptianIcons';
import { playGoldChime } from './utils/audio';

export default function App() {
  const [activeTab, setActiveTab] = useState<'styleguide' | 'decipherer' | 'cartouche' | 'academy' | 'artifacts'>('styleguide');
  const [isRtl, setIsRtl] = useState(false);
  const [isDark, setIsDark] = useState(false);
  const [cartoucheTransferName, setCartoucheTransferName] = useState('RAMSES');

  useEffect(() => {
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = isRtl ? 'ar' : 'en';
  }, [isRtl]);

  const handleSendToCartouche = (name: string) => {
    setCartoucheTransferName(name.toUpperCase());
    setActiveTab('cartouche');
    playGoldChime(1.2);
  };

  return (
    <div className={`min-h-screen flex flex-col ${isDark ? 'dark papyrus-dark-texture text-stone-100' : 'papyrus-texture text-[#3E2723]'}`}>
      {/* Top Bar Header (3-Zone Contract) */}
      <Header
        activeTab={activeTab}
        setActiveTab={(tab) => setActiveTab(tab as typeof activeTab)}
        isRtl={isRtl}
        setIsRtl={setIsRtl}
        isDark={isDark}
        setIsDark={setIsDark}
      />

      {/* Hero Exhibition Banner (Curatorial Marquee) */}
      <section className="relative overflow-hidden border-b border-[#D1B894] dark:border-stone-800 bg-gradient-to-b from-[#EBDDC6]/80 via-[#F4EFEA]/40 to-transparent dark:from-stone-900/60 dark:to-transparent py-10 lg:py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="space-y-4 max-w-2xl text-center lg:text-start">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#B8860B]/15 border border-[#B8860B]/30 text-xs font-serif font-bold text-[#8C6207] dark:text-[#FFD700] uppercase tracking-wider">
                <AnkhIcon size={14} tone="gold" />
                <span>{isRtl ? 'بوابة الحضارة واللغة المصرية القديمة' : 'Museum Scribe Academy & Inscription Portal'}</span>
              </div>

              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-serif font-extrabold tracking-tight text-[#3E2723] dark:text-[#FFD700] leading-tight">
                {isRtl ? 'كيمت: إتقان اللغة الفرعونية ونظام الذهب الملكي' : 'KEMET: Ancient Scribe Master & Gold 3D System'}
              </h1>

              <p className="text-sm sm:text-base text-[#6D4C41] dark:text-stone-300 font-sans leading-relaxed">
                {isRtl
                  ? 'اكتشف روعة النقوش الهيروغليفية، واصنع خرطوشك الملكي بحواف الذهب المشطوفة، وتعرف على نظام الأزرار الفرعونية ثلاثية الأبعاد الفاخرة.'
                  : 'Experience authentic Egyptian epigraphy, formulate royal cartouches in sacred gold relief, and explore the museum-grade luxury 3D button and icon architecture.'}
              </p>

              {/* Primary Call to Actions */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3.5 pt-2">
                <KemetButton
                  variant="gold-primary"
                  size="lg"
                  icon={<ScarabIcon size={20} tone="dark" />}
                  onClick={() => {
                    setActiveTab('styleguide');
                    playGoldChime(1.0);
                  }}
                >
                  {isRtl ? 'استعراض نظام الذهب 3D' : 'Explore Gold 3D System'}
                </KemetButton>

                <KemetButton
                  variant="turquoise-primary"
                  size="lg"
                  icon={<CartoucheIcon size={20} tone="currentColor" />}
                  onClick={() => {
                    setActiveTab('cartouche');
                    playGoldChime(1.15);
                  }}
                >
                  {isRtl ? 'صياغة الخرطوش' : 'Forge Royal Cartouche'}
                </KemetButton>

                <KemetButton
                  variant="gold-secondary"
                  size="lg"
                  icon={<PapyrusScrollIcon size={18} tone="gold" />}
                  onClick={() => {
                    setActiveTab('decipherer');
                    playGoldChime(0.9);
                  }}
                >
                  {isRtl ? 'فك شفرة الحروف' : 'Decipher Hieroglyphs'}
                </KemetButton>
              </div>
            </div>

            {/* Dimensional Sacred Gold Amulet Feature Card */}
            <div className="shrink-0 w-full max-w-sm">
              <div className="kemet-royal-card dark:kemet-royal-card-dark p-6 space-y-4 relative">
                <div className="flex items-center justify-between border-b border-[#B8860B]/20 pb-3">
                  <span className="text-xs font-serif font-bold uppercase tracking-wider text-[#8C6207] dark:text-[#FFD700]">
                    {isRtl ? 'تميمة الحماية الملكية' : 'Royal Protection Amulet'}
                  </span>
                  <span className="font-mono text-xs text-[#8C6207] dark:text-[#FFD700] px-2 py-0.5 rounded bg-[#FFD700]/20">
                    𓋹 𓍑 𓋴
                  </span>
                </div>

                <div className="flex items-center gap-4 py-1">
                  <div className="w-16 h-16 rounded-2xl gold-medallion flex items-center justify-center shrink-0 text-3xl shadow-lg">
                    <EyeOfHorusIcon size={34} tone="dark" />
                  </div>
                  <div>
                    <h4 className="font-serif font-bold text-base text-[#3E2723] dark:text-white">
                      {isRtl ? 'عين حورس (واجات)' : 'Wedjat (Eye of Horus)'}
                    </h4>
                    <p className="text-xs text-[#6D4C41] dark:text-stone-300">
                      {isRtl ? 'رمز الكمال والشفاء والحماية الكونية' : 'Symbol of wholeness, cosmic balance, and protection'}
                    </p>
                  </div>
                </div>

                <div className="pt-2 border-t border-[#D1B894]/40 flex items-center justify-between text-xs text-[#6D4C41] dark:text-stone-400">
                  <span>{isRtl ? 'الحالة الفيزيائية: ذهب عيار 24' : 'Surface: 24K Gold Bevel'}</span>
                  <span className="font-semibold text-emerald-600 dark:text-emerald-400">✓ WCAG AA</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8">
        {activeTab === 'styleguide' && <DesignSystemStyleGuide isRtl={isRtl} />}
        {activeTab === 'decipherer' && <HieroglyphDecipherer isRtl={isRtl} onSendToCartouche={handleSendToCartouche} />}
        {activeTab === 'cartouche' && <RoyalCartoucheCreator isRtl={isRtl} initialName={cartoucheTransferName} />}
        {activeTab === 'academy' && <ScribeAcademy isRtl={isRtl} />}
        {activeTab === 'artifacts' && <ArtifactGallery isRtl={isRtl} />}
      </main>

      {/* Footer */}
      <Footer isRtl={isRtl} onNavigate={(tab) => setActiveTab(tab as typeof activeTab)} />
    </div>
  );
}
