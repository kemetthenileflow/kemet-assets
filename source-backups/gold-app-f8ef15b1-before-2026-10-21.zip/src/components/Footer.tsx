import React from 'react';
import { AnkhIcon, EyeOfHorusIcon, FeatherOfMaatIcon } from './ui/EgyptianIcons';

interface Props {
  isRtl?: boolean;
  onNavigate?: (tab: string) => void;
}

export const Footer: React.FC<Props> = ({ isRtl = false, onNavigate }) => {
  return (
    <footer className="w-full bg-[#EBDDC6]/70 dark:bg-[#141210] border-t border-[#D1B894] dark:border-stone-800 py-10 mt-16 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Brand lockup */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full gold-medallion flex items-center justify-center">
              <AnkhIcon size={16} tone="dark" />
            </div>
            <div>
              <span className="font-serif font-black tracking-widest text-[#3E2723] dark:text-[#FFD700] text-sm">
                KEMET MASTER
              </span>
              <span className="text-xs text-[#6D4C41] dark:text-stone-400 block font-serif">
                {isRtl ? 'أكاديمية الحضارة واللغة المصرية القديمة' : 'Ancient Egyptian Epigraphy & Design System'}
              </span>
            </div>
          </div>

          {/* Quick Curatorial Links */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-xs font-serif text-[#6D4C41] dark:text-stone-300">
            <button 
              type="button" 
              onClick={() => onNavigate && onNavigate('styleguide')} 
              className="hover:text-[#B8860B] transition-colors cursor-pointer"
            >
              {isRtl ? 'دليل نظام الذهب 3D' : 'Gold 3D System'}
            </button>
            <button 
              type="button" 
              onClick={() => onNavigate && onNavigate('decipherer')} 
              className="hover:text-[#B8860B] transition-colors cursor-pointer"
            >
              {isRtl ? 'مترجم الهيروغليفية' : 'Hieroglyph Decipherer'}
            </button>
            <button 
              type="button" 
              onClick={() => onNavigate && onNavigate('cartouche')} 
              className="hover:text-[#B8860B] transition-colors cursor-pointer"
            >
              {isRtl ? 'الخرطوش الملكي' : 'Cartouche Forge'}
            </button>
            <button 
              type="button" 
              onClick={() => onNavigate && onNavigate('artifacts')} 
              className="hover:text-[#B8860B] transition-colors cursor-pointer"
            >
              {isRtl ? 'خزانة الآثار' : 'Museum Relics'}
            </button>
          </div>

          {/* Curatorial Attribution */}
          <div className="text-xs text-[#8C6207] dark:text-stone-400 font-serif text-center md:text-end">
            <div>Gardiner Sign Index · British Museum EA24</div>
            <div className="text-[11px] text-[#6D4C41] dark:text-stone-500 mt-0.5">
              {isRtl ? 'صُنع بعناية توثيقية وفق مقتنيات المتاحف العالمية' : 'Crafted with authentic Egyptian curatorial standards'}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
